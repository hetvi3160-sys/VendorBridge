import { useState } from 'react';
import { useAppData } from '../context/AppDataContext';
import { useAuth } from '../context/AuthContext';
import Badge from '../components/Badge';
import Modal from '../components/Modal';
import { formatCurrency, formatDate, formatDateTime } from '../utils/helpers';
import { CheckCircle, XCircle, Clock, Search, Filter, ClipboardList } from 'lucide-react';

const TYPE_COLORS = {
  'Quotation Acceptance': { bg: 'var(--accent-glow)', color: 'var(--accent-light)', icon: '📋' },
  'New Vendor Registration': { bg: 'rgba(6,182,212,0.1)', color: 'var(--cyan)', icon: '🏢' },
  'Purchase Order': { bg: 'rgba(16,185,129,0.1)', color: 'var(--success)', icon: '🛒' },
  'Budget Exception': { bg: 'rgba(245,158,11,0.1)', color: 'var(--warning)', icon: '⚠️' },
};

export default function Approvals() {
  const { approvals, addToast, addLog, createPOFromQuotation, updateApproval, quotations, rfqs, vendors } = useAppData();
  const { currentUser } = useAuth();
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [selected, setSelected] = useState(null);
  const [remarks, setRemarks] = useState('');

  const filtered = approvals.filter(a => {
    const matchSearch = a.refTitle.toLowerCase().includes(search.toLowerCase()) ||
      a.type.toLowerCase().includes(search.toLowerCase());
    const matchStatus = statusFilter === 'all' || a.status === statusFilter;
    return matchSearch && matchStatus;
  });

  const handleApprove = async () => {
    const updated = {
      ...selected,
      status: 'approved',
      remarks,
      resolvedAt: new Date().toISOString().split('T')[0],
      resolvedBy: currentUser.id,
    };
    await updateApproval(selected.id, updated);
    addLog(currentUser.id, currentUser.name, 'Approved', 'Approval', selected.id, selected.refTitle);

    // Auto-generate PO if it's a quotation acceptance
    if (selected.type === 'Quotation' || selected.type === 'Quotation Acceptance') {
      const quote = quotations.find(q => q.id === selected.refId);
      const rfq = quote ? rfqs.find(r => r.id === quote.rfqId) : null;
      const vendor = quote ? vendors.find(v => v.id === quote.vendorId) : null;
      if (quote && rfq && vendor) {
        const po = await createPOFromQuotation(quote, rfq, vendor);
        if (po) addToast(`Approved! Purchase Order ${po.poNumber} generated automatically.`);
        else addToast('Approval granted successfully.');
      } else {
        addToast('Approval granted successfully.');
      }
    } else {
      addToast('Approval granted successfully.');
    }
    setSelected(null);
    setRemarks('');
  };

  const handleReject = async () => {
    if (!remarks.trim()) { addToast('Please add remarks before rejecting.', 'warning'); return; }
    const updated = {
      ...selected,
      status: 'rejected',
      remarks,
      resolvedAt: new Date().toISOString().split('T')[0],
      resolvedBy: currentUser.id,
    };
    await updateApproval(selected.id, updated);
    addLog(currentUser.id, currentUser.name, 'Rejected', 'Approval', selected.id, selected.refTitle);
    addToast('Approval rejected.', 'error');
    setSelected(null);
    setRemarks('');
  };

  const pending = approvals.filter(a => a.status === 'pending').length;
  const approved = approvals.filter(a => a.status === 'approved').length;
  const rejected = approvals.filter(a => a.status === 'rejected').length;

  return (
    <div className="animate-fade">
      <div className="page-header">
        <div>
          <h1 className="page-title">Approval Workflows</h1>
          <p className="page-subtitle">{approvals.length} total · {pending} pending · {approved} approved · {rejected} rejected</p>
        </div>
      </div>

      {/* Stats Row */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 16, marginBottom: 24 }}>
        {[
          { label: 'Pending', value: pending, color: 'var(--warning)', bg: 'var(--warning-bg)', icon: <Clock size={20} /> },
          { label: 'Approved', value: approved, color: 'var(--success)', bg: 'var(--success-bg)', icon: <CheckCircle size={20} /> },
          { label: 'Rejected', value: rejected, color: 'var(--danger)', bg: 'var(--danger-bg)', icon: <XCircle size={20} /> },
        ].map(s => (
          <div key={s.label} className="card" style={{ display: 'flex', alignItems: 'center', gap: 14, cursor: 'pointer' }}
            onClick={() => setStatusFilter(s.label.toLowerCase())}
          >
            <div style={{ width: 44, height: 44, borderRadius: 10, background: s.bg, color: s.color, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              {s.icon}
            </div>
            <div>
              <div style={{ fontSize: 26, fontWeight: 800, color: 'var(--text-primary)' }}>{s.value}</div>
              <div style={{ fontSize: 13, color: 'var(--text-muted)' }}>{s.label}</div>
            </div>
          </div>
        ))}
      </div>

      {/* Filters */}
      <div className="search-bar">
        <div className="search-input-wrap" style={{ flex: 2 }}>
          <Search size={16} />
          <input className="search-input" placeholder="Search approvals…" value={search} onChange={e => setSearch(e.target.value)} />
        </div>
        <select className="filter-select" value={statusFilter} onChange={e => setStatusFilter(e.target.value)}>
          {['all', 'pending', 'approved', 'rejected'].map(s => (
            <option key={s} value={s}>{s === 'all' ? 'All Statuses' : s.charAt(0).toUpperCase() + s.slice(1)}</option>
          ))}
        </select>
      </div>

      {/* List */}
      <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
        {filtered.map(ap => {
          const meta = TYPE_COLORS[ap.type] || { bg: 'var(--bg-elevated)', color: 'var(--text-secondary)', icon: '📄' };
          return (
            <div key={ap.id} className="card"
              style={{ cursor: 'pointer', transition: 'var(--transition)', display: 'flex', alignItems: 'center', gap: 16 }}
              onClick={() => { setSelected(ap); setRemarks(ap.remarks || ''); }}
              onMouseEnter={e => { e.currentTarget.style.borderColor = 'rgba(99,102,241,0.3)'; e.currentTarget.style.transform = 'translateX(4px)'; }}
              onMouseLeave={e => { e.currentTarget.style.borderColor = 'var(--border)'; e.currentTarget.style.transform = ''; }}
            >
              <div style={{ width: 46, height: 46, borderRadius: 12, background: meta.bg, color: meta.color, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 20, flexShrink: 0 }}>
                {meta.icon}
              </div>

              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 4 }}>
                  <span style={{ fontSize: 15, fontWeight: 700, color: 'var(--text-primary)', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{ap.refTitle}</span>
                  <Badge status={ap.status} />
                </div>
                <div style={{ fontSize: 12, color: 'var(--text-muted)' }}>
                  <span style={{ color: meta.color, fontWeight: 600 }}>{ap.type}</span>
                  {' · '}Requested by <strong style={{ color: 'var(--text-secondary)' }}>{ap.requestedByName}</strong>
                  {' · '}{formatDate(ap.createdAt)}
                </div>
              </div>

              <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-end', gap: 6, flexShrink: 0 }}>
                {ap.amount > 0 && <span style={{ fontSize: 16, fontWeight: 800, color: 'var(--text-primary)' }}>{formatCurrency(ap.amount)}</span>}
                {ap.status === 'pending' && currentUser.role === 'admin' && (
                  <div style={{ display: 'flex', gap: 6 }}>
                    <button className="btn btn-success btn-sm" onClick={e => { e.stopPropagation(); setSelected(ap); setRemarks(''); }}>
                      Review
                    </button>
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {filtered.length === 0 && (
        <div className="empty-state">
          <ClipboardList size={40} style={{ margin: '0 auto 12px', opacity: 0.3 }} />
          <h3>No approvals found</h3>
          <p>Approval requests will appear here</p>
        </div>
      )}

      {/* Detail Modal */}
      <Modal open={!!selected} onClose={() => { setSelected(null); setRemarks(''); }} title="Approval Request" size=""
        footer={selected?.status === 'pending' && currentUser.role === 'admin' ? (
          <>
            <button className="btn btn-ghost" onClick={() => { setSelected(null); setRemarks(''); }}>Cancel</button>
            <button className="btn btn-danger" onClick={handleReject}><XCircle size={14} /> Reject</button>
            <button className="btn btn-success" onClick={handleApprove}><CheckCircle size={14} /> Approve</button>
          </>
        ) : (
          <button className="btn btn-ghost" onClick={() => setSelected(null)}>Close</button>
        )}
      >
        {selected && (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
              {[
                { label: 'Type', value: selected.type },
                { label: 'Requested By', value: selected.requestedByName },
                { label: 'Date', value: formatDate(selected.createdAt) },
                { label: 'Amount', value: selected.amount > 0 ? formatCurrency(selected.amount) : '—' },
                { label: 'Status', value: <Badge status={selected.status} /> },
                ...(selected.resolvedAt ? [{ label: 'Resolved', value: formatDate(selected.resolvedAt) }] : []),
              ].map(item => (
                <div key={item.label} style={{ background: 'var(--bg-elevated)', padding: '12px 14px', borderRadius: 10, border: '1px solid var(--border)' }}>
                  <div style={{ fontSize: 11, color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.8px', fontWeight: 600, marginBottom: 4 }}>{item.label}</div>
                  <div style={{ fontSize: 14, fontWeight: 600, color: 'var(--text-primary)' }}>{item.value}</div>
                </div>
              ))}
            </div>

            <div>
              <label className="form-label" style={{ marginBottom: 6, display: 'block' }}>
                Remarks {selected.status === 'pending' ? '(required for rejection)' : ''}
              </label>
              {selected.status === 'pending' && currentUser.role === 'admin' ? (
                <textarea
                  className="form-input"
                  rows={3}
                  value={remarks}
                  onChange={e => setRemarks(e.target.value)}
                  placeholder="Add remarks or notes about this approval decision…"
                />
              ) : (
                <div style={{ padding: '12px 14px', background: 'var(--bg-elevated)', borderRadius: 10, border: '1px solid var(--border)', fontSize: 14, color: selected.remarks ? 'var(--text-primary)' : 'var(--text-muted)', fontStyle: selected.remarks ? 'normal' : 'italic' }}>
                  {selected.remarks || 'No remarks added.'}
                </div>
              )}
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
}
