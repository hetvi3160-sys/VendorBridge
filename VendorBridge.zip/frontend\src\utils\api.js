// Centralized API client for VendorBridge backend

const API_BASE = '/api';

const getToken = () => localStorage.getItem('vb_token');

const headers = () => ({
  'Content-Type': 'application/json',
  ...(getToken() ? { Authorization: `Bearer ${getToken()}` } : {}),
});

const handleResponse = async (res) => {
  const data = await res.json();
  if (!res.ok) {
    if (res.status === 401 || res.status === 403) {
      localStorage.removeItem('vb_token');
      localStorage.removeItem('vb_user');
      window.location.href = '/login';
    }
    throw new Error(data.error || 'API request failed');
  }
  return data;
};

const api = {
  // ── Auth ──
  login: (email, password) =>
    fetch(`${API_BASE}/auth/login`, { method: 'POST', headers: headers(), body: JSON.stringify({ email, password }) }).then(handleResponse),
  register: (name, email, password, role) =>
    fetch(`${API_BASE}/auth/register`, { method: 'POST', headers: headers(), body: JSON.stringify({ name, email, password, role }) }).then(handleResponse),
  getMe: () =>
    fetch(`${API_BASE}/auth/me`, { headers: headers() }).then(handleResponse),

  // ── Vendors ──
  getVendors: () => fetch(`${API_BASE}/vendors`, { headers: headers() }).then(handleResponse),
  getVendor: (id) => fetch(`${API_BASE}/vendors/${id}`, { headers: headers() }).then(handleResponse),
  createVendor: (data) => fetch(`${API_BASE}/vendors`, { method: 'POST', headers: headers(), body: JSON.stringify(data) }).then(handleResponse),
  updateVendor: (id, data) => fetch(`${API_BASE}/vendors/${id}`, { method: 'PUT', headers: headers(), body: JSON.stringify(data) }).then(handleResponse),

  // ── RFQs ──
  getRfqs: () => fetch(`${API_BASE}/rfqs`, { headers: headers() }).then(handleResponse),
  getRfq: (id) => fetch(`${API_BASE}/rfqs/${id}`, { headers: headers() }).then(handleResponse),
  createRfq: (data) => fetch(`${API_BASE}/rfqs`, { method: 'POST', headers: headers(), body: JSON.stringify(data) }).then(handleResponse),
  updateRfq: (id, data) => fetch(`${API_BASE}/rfqs/${id}`, { method: 'PUT', headers: headers(), body: JSON.stringify(data) }).then(handleResponse),

  // ── Quotations ──
  getQuotations: () => fetch(`${API_BASE}/quotations`, { headers: headers() }).then(handleResponse),
  createQuotation: (data) => fetch(`${API_BASE}/quotations`, { method: 'POST', headers: headers(), body: JSON.stringify(data) }).then(handleResponse),
  updateQuotation: (id, data) => fetch(`${API_BASE}/quotations/${id}`, { method: 'PUT', headers: headers(), body: JSON.stringify(data) }).then(handleResponse),

  // ── Approvals ──
  getApprovals: () => fetch(`${API_BASE}/approvals`, { headers: headers() }).then(handleResponse),
  createApproval: (data) => fetch(`${API_BASE}/approvals`, { method: 'POST', headers: headers(), body: JSON.stringify(data) }).then(handleResponse),
  updateApproval: (id, data) => fetch(`${API_BASE}/approvals/${id}`, { method: 'PUT', headers: headers(), body: JSON.stringify(data) }).then(handleResponse),

  // ── Purchase Orders ──
  getPurchaseOrders: () => fetch(`${API_BASE}/purchase-orders`, { headers: headers() }).then(handleResponse),
  getPurchaseOrder: (id) => fetch(`${API_BASE}/purchase-orders/${id}`, { headers: headers() }).then(handleResponse),
  createPurchaseOrder: (data) => fetch(`${API_BASE}/purchase-orders`, { method: 'POST', headers: headers(), body: JSON.stringify(data) }).then(handleResponse),
  updatePurchaseOrder: (id, data) => fetch(`${API_BASE}/purchase-orders/${id}`, { method: 'PUT', headers: headers(), body: JSON.stringify(data) }).then(handleResponse),

  // ── Invoices ──
  getInvoices: () => fetch(`${API_BASE}/invoices`, { headers: headers() }).then(handleResponse),
  getInvoice: (id) => fetch(`${API_BASE}/invoices/${id}`, { headers: headers() }).then(handleResponse),
  createInvoice: (data) => fetch(`${API_BASE}/invoices`, { method: 'POST', headers: headers(), body: JSON.stringify(data) }).then(handleResponse),
  updateInvoice: (id, data) => fetch(`${API_BASE}/invoices/${id}`, { method: 'PUT', headers: headers(), body: JSON.stringify(data) }).then(handleResponse),

  // ── Audit Logs ──
  getAuditLogs: () => fetch(`${API_BASE}/audit-logs`, { headers: headers() }).then(handleResponse),
  createAuditLog: (data) => fetch(`${API_BASE}/audit-logs`, { method: 'POST', headers: headers(), body: JSON.stringify(data) }).then(handleResponse),

  // ── Analytics ──
  getDashboardAnalytics: () => fetch(`${API_BASE}/analytics/dashboard`, { headers: headers() }).then(handleResponse),
};

export default api;
