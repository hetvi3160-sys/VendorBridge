import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAppData } from '../../context/AppDataContext';
import Badge from '../../components/Badge';
import { formatDate } from '../../utils/helpers';
import { Plus, Search, FileText, Eye, GitBranch } from 'lucide-react';

const STATUSES = ['all', 'draft', 'active', 'closed'];

export default function RFQList() {
  const { rfqs, quotations } = useAppData();
  const navigate = useNavigate();
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');

  const filtered = rfqs.filter(r => {
    const matchSearch = r.title.toLowerCase().includes(search.toLowerCase()) || r.rfqNumber.toLowerCase().includes(search.toLowerCase());
    const matchStatus = statusFilter === 'all' || r.status === statusFilter;
    return matchSearch && matchStatus;
  });

  const getQuoteCount = (rfqId) => quotations.filter(q => q.rfqId === rfqId).length;

  return (
    <div className="animate-fade">
      <div className="page-header">
        <div>
          <h1 className="page-title">Request for Quotations</h1>
          <p className="page-subtitle">{rfqs.length} total RFQs · {rfqs.filter(r => r.status === 'active').length} active</p>
        </div>
        <button className="btn btn-primary" onClick={() => navigate('/rfq/create')}>
          <Plus size={16} /> Create RFQ
        </button>
      </div>

      <div className="search-bar">
        <div className="search-input-wrap" style={{ flex: 2 }}>
          <Search size={16} />
          <input className="search-input" placeholder="Search by title or RFQ number…" value={search} onChange={e => setSearch(e.target.value)} />
        </div>
        <select className="filter-select" value={statusFilter} onChange={e => setStatusFilter(e.target.value)}>
          {STATUSES.map(s => <option key={s} value={s}>{s === 'all' ? 'All Statuses' : s.charAt(0).toUpperCase() + s.slice(1)}</option>)}
        </select>
      </div>

      {/* Cards Grid */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(340px, 1fr))', gap: 20 }}>
        {filtered.map(rfq => {
          const quoteCount = getQuoteCount(rfq.id);
          return (
            <div key={rfq.id} className="card" style={{ cursor: 'pointer' }}
              onClick={() => navigate(`/rfq/${rfq.id}`)}
              onMouseEnter={e => { e.currentTarget.style.transform = 'translateY(-3px)'; e.currentTarget.style.boxShadow = '0 12px 40px rgba(0,0,0,0.4)'; }}
              onMouseLeave={e => { e.currentTarget.style.transform = ''; e.currentTarget.style.boxShadow = ''; }}
            >
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 14 }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                  <div style={{ width: 40, height: 40, borderRadius: 10, background: 'var(--accent-glow)', color: 'var(--accent-light)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                    <FileText size={18} />
                  </div>
                  <div>
                    <div style={{ fontSize: 11, color: 'var(--text-muted)', fontWeight: 600, letterSpacing: '0.8px', textTransform: 'uppercase' }}>{rfq.rfqNumber}</div>
                    <div style={{ fontSize: 15, fontWeight: 700, color: 'var(--text-primary)' }}>{rfq.title}</div>
                  </div>
                </div>
                <Badge status={rfq.status} />
              </div>

              <p style={{ fontSize: 13, color: 'var(--text-muted)', marginBottom: 16, lineHeight: 1.6 }}>
                {rfq.description?.slice(0, 90)}{rfq.description?.length > 90 ? '…' : ''}
              </p>

              <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', marginBottom: 16 }}>
                {rfq.products.slice(0, 3).map((p, i) => (
                  <span key={i} style={{ padding: '3px 10px', borderRadius: 999, background: 'var(--bg-elevated)', border: '1px solid var(--border)', fontSize: 12, color: 'var(--text-secondary)' }}>
                    {p.name}
                  </span>
                ))}
                {rfq.products.length > 3 && <span style={{ padding: '3px 10px', borderRadius: 999, background: 'var(--bg-elevated)', border: '1px solid var(--border)', fontSize: 12, color: 'var(--text-muted)' }}>+{rfq.products.length - 3} more</span>}
              </div>

              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', paddingTop: 14, borderTop: '1px solid var(--border)' }}>
                <div style={{ display: 'flex', gap: 16 }}>
                  <div style={{ fontSize: 12, color: 'var(--text-muted)' }}>
                    <span style={{ fontWeight: 700, color: 'var(--text-primary)' }}>{rfq.vendors?.length || 0}</span> vendors
                  </div>
                  <div style={{ fontSize: 12, color: 'var(--text-muted)' }}>
                    <span style={{ fontWeight: 700, color: quoteCount > 0 ? 'var(--accent-light)' : 'var(--text-primary)' }}>{quoteCount}</span> quotes
                  </div>
                </div>
                <div style={{ fontSize: 12, color: 'var(--text-muted)' }}>
                  Due {formatDate(rfq.deadline)}
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {filtered.length === 0 && (
        <div className="empty-state">
          <FileText size={40} style={{ margin: '0 auto 12px', opacity: 0.3 }} />
          <h3>No RFQs found</h3>
          <p>Create your first RFQ to get started</p>
        </div>
      )}
    </div>
  );
}
