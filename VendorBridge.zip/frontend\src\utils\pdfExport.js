import jsPDF from 'jspdf';
import { formatCurrency, formatDate } from './helpers';

export const downloadInvoicePDF = (invoice) => {
  const doc = new jsPDF();
  const blue = [99, 102, 241];
  const dark = [15, 23, 42];
  const gray = [100, 116, 139];

  // Header background
  doc.setFillColor(...blue);
  doc.rect(0, 0, 210, 35, 'F');

  // Logo text
  doc.setTextColor(255, 255, 255);
  doc.setFontSize(22);
  doc.setFont('helvetica', 'bold');
  doc.text('VendorBridge', 14, 18);
  doc.setFontSize(10);
  doc.setFont('helvetica', 'normal');
  doc.text('Procurement & Vendor Management ERP', 14, 27);

  // Invoice badge
  doc.setFontSize(14);
  doc.setFont('helvetica', 'bold');
  doc.text('TAX INVOICE', 150, 18);
  doc.setFontSize(10);
  doc.setFont('helvetica', 'normal');
  doc.text(invoice.invoiceNumber, 150, 27);

  // Meta
  doc.setTextColor(...dark);
  doc.setFontSize(9);
  doc.text(`Invoice Date: ${formatDate(invoice.issuedDate)}`, 14, 48);
  doc.text(`Due Date: ${formatDate(invoice.dueDate)}`, 14, 55);
  doc.text(`PO Reference: ${invoice.poNumber}`, 14, 62);

  // Vendor info
  doc.setFont('helvetica', 'bold');
  doc.text('Bill From:', 130, 48);
  doc.setFont('helvetica', 'normal');
  doc.text(invoice.vendorName, 130, 55);

  // Divider
  doc.setDrawColor(...blue);
  doc.setLineWidth(0.5);
  doc.line(14, 72, 196, 72);

  // Table header
  doc.setFillColor(...blue);
  doc.rect(14, 76, 182, 8, 'F');
  doc.setTextColor(255, 255, 255);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9);
  doc.text('Description', 18, 81.5);
  doc.text('Qty', 110, 81.5);
  doc.text('Unit Price', 130, 81.5);
  doc.text('Amount', 168, 81.5);

  // Table rows
  doc.setTextColor(...dark);
  doc.setFont('helvetica', 'normal');
  let y = 92;
  invoice.lineItems.forEach((item, i) => {
    if (i % 2 === 0) {
      doc.setFillColor(243, 244, 246);
      doc.rect(14, y - 5, 182, 8, 'F');
    }
    doc.text(item.description, 18, y);
    doc.text(String(item.quantity), 110, y);
    doc.text(formatCurrency(item.unitPrice), 130, y);
    doc.text(formatCurrency(item.amount), 168, y);
    y += 10;
  });

  // Tax summary
  y += 5;
  doc.setDrawColor(...gray);
  doc.line(120, y, 196, y);
  y += 8;
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(...gray);
  doc.text('Subtotal:', 130, y); doc.setTextColor(...dark); doc.text(formatCurrency(invoice.subtotal), 168, y); y += 7;
  if (invoice.cgst > 0) {
    doc.setTextColor(...gray); doc.text('CGST (9%):', 130, y); doc.setTextColor(...dark); doc.text(formatCurrency(invoice.cgst), 168, y); y += 7;
    doc.setTextColor(...gray); doc.text('SGST (9%):', 130, y); doc.setTextColor(...dark); doc.text(formatCurrency(invoice.sgst), 168, y); y += 7;
  }
  if (invoice.igst > 0) {
    doc.setTextColor(...gray); doc.text('IGST (18%):', 130, y); doc.setTextColor(...dark); doc.text(formatCurrency(invoice.igst), 168, y); y += 7;
  }

  // Total
  doc.setFillColor(...blue);
  doc.rect(120, y, 76, 10, 'F');
  doc.setTextColor(255, 255, 255);
  doc.setFont('helvetica', 'bold');
  doc.text('TOTAL:', 130, y + 7);
  doc.text(formatCurrency(invoice.total), 168, y + 7);

  // Footer
  doc.setTextColor(...gray);
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8);
  doc.text('Thank you for your business. This is a computer-generated invoice.', 14, 280);
  doc.text('VendorBridge ERP | procurement@vendorbridge.com', 14, 285);

  doc.save(`${invoice.invoiceNumber}.pdf`);
};

export const downloadPOPDF = (po) => {
  const doc = new jsPDF();
  const blue = [99, 102, 241];
  const dark = [15, 23, 42];
  const gray = [100, 116, 139];

  doc.setFillColor(...blue);
  doc.rect(0, 0, 210, 35, 'F');
  doc.setTextColor(255, 255, 255);
  doc.setFontSize(22);
  doc.setFont('helvetica', 'bold');
  doc.text('VendorBridge', 14, 18);
  doc.setFontSize(10);
  doc.setFont('helvetica', 'normal');
  doc.text('Procurement & Vendor Management ERP', 14, 27);
  doc.setFontSize(14);
  doc.setFont('helvetica', 'bold');
  doc.text('PURCHASE ORDER', 140, 18);
  doc.setFontSize(10);
  doc.setFont('helvetica', 'normal');
  doc.text(po.poNumber, 140, 27);

  doc.setTextColor(...dark);
  doc.setFontSize(9);
  doc.text(`Date: ${formatDate(po.createdAt)}`, 14, 48);
  doc.text(`Delivery Date: ${formatDate(po.deliveryDate)}`, 14, 55);
  doc.text(`Terms: ${po.terms}`, 14, 62);
  doc.setFont('helvetica', 'bold');
  doc.text('Vendor:', 130, 48);
  doc.setFont('helvetica', 'normal');
  doc.text(po.vendorName, 130, 55);

  doc.setFillColor(...blue);
  doc.rect(14, 76, 182, 8, 'F');
  doc.setTextColor(255, 255, 255);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9);
  doc.text('Description', 18, 81.5);
  doc.text('Qty', 110, 81.5);
  doc.text('Unit Price', 130, 81.5);
  doc.text('Amount', 168, 81.5);

  doc.setTextColor(...dark);
  doc.setFont('helvetica', 'normal');
  let y = 92;
  po.lineItems.forEach((item, i) => {
    if (i % 2 === 0) { doc.setFillColor(243, 244, 246); doc.rect(14, y - 5, 182, 8, 'F'); }
    doc.text(item.description, 18, y);
    doc.text(String(item.quantity), 110, y);
    doc.text(formatCurrency(item.unitPrice), 130, y);
    doc.text(formatCurrency(item.amount), 168, y);
    y += 10;
  });

  y += 10;
  doc.setFillColor(...blue);
  doc.rect(120, y, 76, 10, 'F');
  doc.setTextColor(255, 255, 255);
  doc.setFont('helvetica', 'bold');
  doc.text('TOTAL:', 130, y + 7);
  doc.text(formatCurrency(po.total), 168, y + 7);

  doc.setTextColor(...gray);
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8);
  doc.text('This is an official Purchase Order from VendorBridge ERP.', 14, 280);
  doc.save(`${po.poNumber}.pdf`);
};
