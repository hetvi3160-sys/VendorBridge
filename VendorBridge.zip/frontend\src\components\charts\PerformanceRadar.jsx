import { RadarChart, Radar, PolarGrid, PolarAngleAxis, ResponsiveContainer, Tooltip, Legend } from 'recharts';
import { vendorPerformance } from '../../utils/mockData';

const COLORS = ['#6366f1', '#06b6d4', '#10b981'];

const radarData = ['delivery', 'quality', 'price', 'responsiveness', 'compliance'].map(key => ({
  metric: key.charAt(0).toUpperCase() + key.slice(1),
  ...Object.fromEntries(vendorPerformance.map(v => [v.vendor.split(' ')[0], v[key]])),
}));

export default function PerformanceRadar() {
  return (
    <ResponsiveContainer width="100%" height="100%">
      <RadarChart data={radarData} margin={{ top: 10, right: 30, bottom: 10, left: 30 }}>
        <PolarGrid stroke="rgba(99,102,241,0.15)" />
        <PolarAngleAxis dataKey="metric" tick={{ fill: '#94a3b8', fontSize: 12 }} />
        {vendorPerformance.map((v, i) => (
          <Radar
            key={v.vendor}
            name={v.vendor}
            dataKey={v.vendor.split(' ')[0]}
            stroke={COLORS[i]}
            fill={COLORS[i]}
            fillOpacity={0.12}
            strokeWidth={2}
          />
        ))}
        <Tooltip
          contentStyle={{ background: '#141c35', border: '1px solid rgba(99,102,241,0.3)', borderRadius: 10, fontSize: 12 }}
          labelStyle={{ color: '#94a3b8' }}
          itemStyle={{ color: '#f1f5f9' }}
        />
        <Legend
          iconType="circle"
          iconSize={8}
          formatter={(value) => <span style={{ color: '#94a3b8', fontSize: 12 }}>{value}</span>}
        />
      </RadarChart>
    </ResponsiveContainer>
  );
}
