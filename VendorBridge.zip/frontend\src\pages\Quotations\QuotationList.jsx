import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAppData } from '../../context/AppDataContext';
import Badge from '../../components/Badge';
import { formatCurrency, formatDate } from '../../utils/helpers';
import { Search, GitBranch, MessageSquare } from 'lucide-react';

export default function QuotationList() {
  const { quotations, rfqs, vendors } = useAppData();
  const navigate = useNavigate();
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');

  const enriched = quotations.map(q => ({
    ...q,
    rfq: rfqs.find(r => r.id === q.rfqId),
    vendor: vendors.find(v => v.id === q.vendorId),
  }));

  const filtered = enriched.filter(q => {
    const matchSearch = q.rfq?.title.toLowerCase().includes(search.toLowerCase()) ||
      q.vendor?.name.toLowerCase().includes(search.toLowerCase());
    const matchStatus = statusFilter === 'all' || q.status === statusFilter;
    return matchSearch && matchStatus;
  });

  return (
    <div className="animate-fade">
      <div className="page-header">
        <div>
          <h1 className="page-title">Quotations</h1>
          <p className="page-subtitle">{quotations.length} quotations · {quotations.filter(q => q.status === 'pending').length} pending review</p>
        </div>
      </div>

      <div className="search-bar">
        <div className="search-input-wrap" style={{ flex: 2 }}>
          <Search size={16} />
          <input className="search-input" placeholder="Search by RFQ title or vendor…" value={search} onChange={e => setSearch(e.target.value)} />
        </div>
        <select className="filter-select" value={statusFilter} onChange={e => setStatusFilter(e.target.value)}>
          {['all', 'pending', 'accepted', 'rejected'].map(s => (
            <option key={s} value={s}>{s === 'all' ? 'All Statuses' : s.charAt(0).toUpperCase() + s.slice(1)}</option>
          ))}
        </select>
      </div>

      <div className="table-wrap">
        <table>
          <thead>
            <tr>
              <th>Vendor</th>
              <th>RFQ</th>
              <th>Total Amount</th>
              <th>Delivery (Days)</th>
              <th>Validity</th>
              <th>Submitted</th>
              <th>Status</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {filtered.map(q => (
              <tr key={q.id}>
                <td>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                    <div style={{ width: 30, height: 30, borderRadius: 7, background: 'linear-gradient(135deg, var(--accent), var(--cyan))', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 11, fontWeight: 700, color: 'white', flexShrink: 0 }}>
                      {q.vendor?.name.slice(0, 2).toUpperCase()}
                    </div>
                    <div>
                      <div style={{ fontSize: 13, fontWeight: 600, color: 'var(--text-primary)' }}>{q.vendor?.name}</div>
                    </div>
                  </div>
                </td>
                <td>
                  <div style={{ fontSize: 13, color: 'var(--accent-light)', cursor: 'pointer', fontWeight: 500 }}
                    onClick={() => navigate(`/rfq/${q.rfqId}`)}>
                    {q.rfq?.rfqNumber}
                  </div>
                  <div style={{ fontSize: 12, color: 'var(--text-muted)' }}>{q.rfq?.title?.slice(0, 35)}…</div>
                </td>
                <td style={{ fontWeight: 700, color: 'var(--text-primary)' }}>{formatCurrency(q.totalAmount)}</td>
                <td>{q.deliveryDays} days</td>
                <td>{q.validity} days</td>
                <td>{formatDate(q.submittedAt)}</td>
                <td><Badge status={q.status} /></td>
                <td>
                  {q.rfq && (
                    <button className="btn btn-ghost btn-sm" onClick={() => navigate(`/quotations/compare/${q.rfqId}`)}>
                      <GitBranch size={13} /> Compare
                    </button>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {filtered.length === 0 && (
        <div className="empty-state">
          <MessageSquare size={40} style={{ margin: '0 auto 12px', opacity: 0.3 }} />
          <h3>No quotations found</h3>
          <p>Quotations will appear here once vendors respond to RFQs</p>
        </div>
      )}
    </div>
  );
}
