const fs = require('fs');
const path = require('path');
const { db, initDB } = require('./db');

console.log('Initializing Database...');
initDB();

// Read and convert ES module mockData to CommonJS
const mockDataPath = path.join(__dirname, '../src/utils/mockData.js');
let mockDataContent = fs.readFileSync(mockDataPath, 'utf8');
mockDataContent = mockDataContent.replace(/export const/g, 'const');
mockDataContent += `\nmodule.exports = { users, vendors, rfqs, quotations, approvals, purchaseOrders, invoices, auditLogs, monthlySpend, vendorStatusData, vendorPerformance };`;

const tempFilePath = path.join(__dirname, 'tempMockData.js');
fs.writeFileSync(tempFilePath, mockDataContent);
const mockData = require('./tempMockData');

console.log('Seeding data...');

try {
  // Clear all tables
  db.exec('DELETE FROM invoice_line_items');
  db.exec('DELETE FROM invoices');
  db.exec('DELETE FROM po_line_items');
  db.exec('DELETE FROM purchase_orders');
  db.exec('DELETE FROM approvals');
  db.exec('DELETE FROM quotation_items');
  db.exec('DELETE FROM quotations');
  db.exec('DELETE FROM rfq_vendors');
  db.exec('DELETE FROM rfq_items');
  db.exec('DELETE FROM rfqs');
  db.exec('DELETE FROM audit_logs');
  db.exec('DELETE FROM vendors');
  db.exec('DELETE FROM users');

  // ── Users ──
  const insertUser = db.prepare('INSERT INTO users (id, name, email, password, role, avatar, department) VALUES (?, ?, ?, ?, ?, ?, ?)');
  for (const u of mockData.users) {
    insertUser.run(u.id, u.name, u.email, u.password, u.role, u.avatar, u.department);
  }
  console.log(`  ✓ ${mockData.users.length} users seeded`);

  // ── Vendors ──
  const insertVendor = db.prepare('INSERT INTO vendors (id, name, gstNumber, category, contactPerson, email, phone, status, performanceScore, city, state, bankAccount, joiningDate, totalOrders, totalValue) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)');
  for (const v of mockData.vendors) {
    insertVendor.run(v.id, v.name, v.gstNumber, v.category, v.contactPerson, v.email, v.phone, v.status, v.performanceScore, v.city, v.state, v.bankAccount, v.joiningDate, v.totalOrders, v.totalValue);
  }
  console.log(`  ✓ ${mockData.vendors.length} vendors seeded`);

  // ── RFQs ──
  const insertRfq = db.prepare('INSERT INTO rfqs (id, rfqNumber, title, description, deadline, status, createdBy, createdAt, budget) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)');
  const insertRfqItem = db.prepare('INSERT INTO rfq_items (rfqId, name, quantity, unit) VALUES (?, ?, ?, ?)');
  const insertRfqVendor = db.prepare('INSERT INTO rfq_vendors (rfqId, vendorId) VALUES (?, ?)');
  for (const r of mockData.rfqs) {
    insertRfq.run(r.id, r.rfqNumber, r.title, r.description, r.deadline, r.status, r.createdBy, r.createdAt, r.budget);
    for (const item of r.products) {
      insertRfqItem.run(r.id, item.name, item.quantity, item.unit);
    }
    if (r.vendors) {
      for (const vId of r.vendors) {
        insertRfqVendor.run(r.id, vId);
      }
    }
  }
  console.log(`  ✓ ${mockData.rfqs.length} RFQs seeded`);

  // ── Quotations ──
  const insertQuotation = db.prepare('INSERT INTO quotations (id, rfqId, vendorId, deliveryDays, totalAmount, status, submittedAt, validity, notes) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)');
  const insertQuotationItem = db.prepare('INSERT INTO quotation_items (quotationId, product, unitPrice, quantity) VALUES (?, ?, ?, ?)');
  for (const q of mockData.quotations) {
    insertQuotation.run(q.id, q.rfqId, q.vendorId, q.deliveryDays, q.totalAmount, q.status, q.submittedAt, q.validity, q.notes);
    for (const up of q.unitPrices) {
      insertQuotationItem.run(q.id, up.product, up.unitPrice, up.quantity);
    }
  }
  console.log(`  ✓ ${mockData.quotations.length} quotations seeded`);

  // ── Approvals ──
  const insertApproval = db.prepare('INSERT INTO approvals (id, type, refId, refTitle, requestedBy, requestedByName, amount, status, remarks, createdAt, resolvedAt, resolvedBy) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)');
  for (const a of mockData.approvals) {
    insertApproval.run(a.id, a.type, a.refId, a.refTitle, a.requestedBy, a.requestedByName, a.amount, a.status, a.remarks, a.createdAt, a.resolvedAt, a.resolvedBy);
  }
  console.log(`  ✓ ${mockData.approvals.length} approvals seeded`);

  // ── Purchase Orders ──
  const insertPO = db.prepare('INSERT INTO purchase_orders (id, poNumber, rfqId, quotationId, vendorId, vendorName, subtotal, cgst, sgst, igst, total, status, deliveryDate, createdAt, createdBy, terms) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)');
  const insertPOItem = db.prepare('INSERT INTO po_line_items (poId, description, quantity, unitPrice, amount) VALUES (?, ?, ?, ?, ?)');
  for (const po of mockData.purchaseOrders) {
    insertPO.run(po.id, po.poNumber, po.rfqId, po.quotationId, po.vendorId, po.vendorName, po.subtotal, po.cgst, po.sgst, po.igst, po.total, po.status, po.deliveryDate, po.createdAt, po.createdBy, po.terms);
    for (const item of po.lineItems) {
      insertPOItem.run(po.id, item.description, item.quantity, item.unitPrice, item.amount);
    }
  }
  console.log(`  ✓ ${mockData.purchaseOrders.length} purchase orders seeded`);

  // ── Invoices ──
  const insertInvoice = db.prepare('INSERT INTO invoices (id, invoiceNumber, poId, poNumber, vendorId, vendorName, subtotal, cgst, sgst, igst, total, status, dueDate, issuedDate, paidDate) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)');
  const insertInvItem = db.prepare('INSERT INTO invoice_line_items (invoiceId, description, quantity, unitPrice, amount) VALUES (?, ?, ?, ?, ?)');
  for (const inv of mockData.invoices) {
    insertInvoice.run(inv.id, inv.invoiceNumber, inv.poId, inv.poNumber, inv.vendorId, inv.vendorName, inv.subtotal, inv.cgst, inv.sgst, inv.igst, inv.total, inv.status, inv.dueDate, inv.issuedDate, inv.paidDate);
    for (const item of inv.lineItems) {
      insertInvItem.run(inv.id, item.description, item.quantity, item.unitPrice, item.amount);
    }
  }
  console.log(`  ✓ ${mockData.invoices.length} invoices seeded`);

  // ── Audit Logs ──
  const insertLog = db.prepare('INSERT INTO audit_logs (id, userId, userName, action, entityType, entityId, entityTitle, timestamp, ipAddress) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)');
  for (const al of mockData.auditLogs) {
    insertLog.run(al.id, al.userId, al.userName, al.action, al.entityType, al.entityId, al.entityTitle, al.timestamp, al.ipAddress);
  }
  console.log(`  ✓ ${mockData.auditLogs.length} audit logs seeded`);

  console.log('\n✅ Seeding complete!');
} catch (error) {
  console.error('Error during seeding:', error);
} finally {
  fs.unlinkSync(tempFilePath);
}
