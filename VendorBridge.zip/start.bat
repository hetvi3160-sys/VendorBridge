@echo off
title VendorBridge Start Script

echo ==============================================
echo        Starting VendorBridge Services
echo ==============================================

echo [1/2] Starting Backend Server...
start "VendorBridge Backend" cmd /k "cd backend && node server.js"

echo [2/2] Starting Frontend Server...
start "VendorBridge Frontend" cmd /k "cd frontend && npm run dev"

echo.
echo Both services have been launched in separate windows!
echo - Frontend: http://localhost:5173
echo - Backend:  http://localhost:3000
echo.
pause
