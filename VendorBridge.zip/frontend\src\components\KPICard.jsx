import { TrendingUp, TrendingDown } from 'lucide-react';

export default function KPICard({ title, value, change, changeType = 'up', icon, accent = '#6366f1', bg = 'rgba(99,102,241,0.1)' }) {
  return (
    <div className="kpi-card">
      <div style={{ position: 'absolute', top: 0, left: 0, right: 0, height: 2, background: `linear-gradient(90deg, ${accent}, transparent)`, borderRadius: '12px 12px 0 0' }} />
      <div className="kpi-icon" style={{ background: bg, color: accent }}>
        {icon}
      </div>
      <div className="kpi-value">{value}</div>
      <div className="kpi-label">{title}</div>
      {change && (
        <div className={`kpi-change ${changeType}`}>
          {changeType === 'up' ? <TrendingUp size={13} /> : <TrendingDown size={13} />}
          {change}
        </div>
      )}
    </div>
  );
}
