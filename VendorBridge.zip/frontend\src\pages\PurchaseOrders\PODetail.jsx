import { useParams, useNavigate } from 'react-router-dom';
import { useAppData } from '../../context/AppDataContext';
import { useAuth } from '../../context/AuthContext';
import Badge from '../../components/Badge';
import { formatCurrency, formatDate } from '../../utils/helpers';
import { downloadPOPDF } from '../../utils/pdfExport';
import { ArrowLeft, Download, FileText, Printer, ChevronRight } from 'lucide-react';

export default function PODetail() {
  const { id } = useParams();
  const { purchaseOrders, invoices, addToast, addLog, createInvoiceFromPO, updatePO } = useAppData();
  const { currentUser } = useAuth();
  const navigate = useNavigate();

  const po = purchaseOrders.find(p => p.id === id);
  if (!po) return <div style={{ padding: 40, color: 'var(--text-muted)' }}>Purchase Order not found.</div>;

  const existingInvoice = invoices.find(i => i.poId === id);
  const gst = (po.cgst || 0) + (po.sgst || 0) + (po.igst || 0);

  const handleGenerateInvoice = async () => {
    const inv = await createInvoiceFromPO(po);
    if (inv) {
      addLog(currentUser.id, currentUser.name, 'Generated Invoice', 'Invoice', inv.id, inv.invoiceNumber);
      addToast(`Invoice ${inv.invoiceNumber} generated successfully!`);
      navigate(`/invoices/${inv.id}`);
    }
  };

  const handleStatusUpdate = async (newStatus) => {
    await updatePO(po.id, { ...po, status: newStatus });
    addToast(`PO status updated to ${newStatus}`);
  };

  const handlePrint = () => window.print();

  return (
    <div className="animate-fade">
      {/* Header */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 14, marginBottom: 28 }}>
        <button className="btn btn-ghost btn-sm" onClick={() => navigate('/purchase-orders')}>
          <ArrowLeft size={15} /> Back
        </button>
        <div style={{ flex: 1 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <h1 className="page-title">{po.poNumber}</h1>
            <Badge status={po.status} />
          </div>
          <p className="page-subtitle">Created {formatDate(po.createdAt)} · Delivery by {formatDate(po.deliveryDate)}</p>
        </div>
        <div style={{ display: 'flex', gap: 10 }} className="no-print">
          <button className="btn btn-ghost btn-sm" onClick={handlePrint}>
            <Printer size={14} /> Print
          </button>
          <button className="btn btn-secondary btn-sm" onClick={() => downloadPOPDF(po)}>
            <Download size={14} /> Download PDF
          </button>
          {po.status === 'delivered' && !existingInvoice && (
            <button className="btn btn-primary btn-sm" onClick={handleGenerateInvoice}>
              <FileText size={14} /> Generate Invoice
            </button>
          )}
          {existingInvoice && (
            <button className="btn btn-success btn-sm" onClick={() => navigate(`/invoices/${existingInvoice.id}`)}>
              <ChevronRight size={14} /> View Invoice
            </button>
          )}
        </div>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 340px', gap: 24 }}>
        {/* Left: PO Document */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
          {/* PO Header Card */}
          <div className="card" style={{ background: 'linear-gradient(135deg, rgba(99,102,241,0.08), rgba(6,182,212,0.04))', borderColor: 'rgba(99,102,241,0.2)' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 24 }}>
              <div>
                <div style={{ fontSize: 22, fontWeight: 800, background: 'linear-gradient(135deg, var(--accent-light), var(--cyan))', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent' }}>
                  ⬡ VendorBridge
                </div>
                <div style={{ fontSize: 11, color: 'var(--text-muted)', marginTop: 2, letterSpacing: '1px', textTransform: 'uppercase' }}>
                  Procurement & Vendor Management ERP
                </div>
              </div>
              <div style={{ textAlign: 'right' }}>
                <div style={{ fontSize: 11, color: 'var(--text-muted)', letterSpacing: '1px', textTransform: 'uppercase', fontWeight: 600 }}>Purchase Order</div>
                <div style={{ fontSize: 20, fontWeight: 800, color: 'var(--text-primary)', fontFamily: 'monospace' }}>{po.poNumber}</div>
              </div>
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 16 }}>
              {[
                { label: 'Vendor', value: po.vendorName },
                { label: 'Date', value: formatDate(po.createdAt) },
                { label: 'Delivery Date', value: formatDate(po.deliveryDate) },
                { label: 'Payment Terms', value: po.terms },
                { label: 'Status', value: <Badge status={po.status} /> },
              ].map(item => (
                <div key={item.label}>
                  <div style={{ fontSize: 11, color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.8px', fontWeight: 600, marginBottom: 4 }}>{item.label}</div>
                  <div style={{ fontSize: 14, fontWeight: 600, color: 'var(--text-primary)' }}>{item.value}</div>
                </div>
              ))}
            </div>
          </div>

          {/* Line Items */}
          <div className="card">
            <div className="card-title" style={{ marginBottom: 16 }}>Line Items</div>
            <div className="table-wrap">
              <table>
                <thead>
                  <tr>
                    <th>#</th>
                    <th>Description</th>
                    <th>Qty</th>
                    <th>Unit Price</th>
                    <th>Amount</th>
                  </tr>
                </thead>
                <tbody>
                  {po.lineItems.map((item, i) => (
                    <tr key={i}>
                      <td style={{ color: 'var(--text-muted)', width: 40 }}>{i + 1}</td>
                      <td className="td-primary">{item.description}</td>
                      <td>{item.quantity}</td>
                      <td>{formatCurrency(item.unitPrice)}</td>
                      <td style={{ fontWeight: 700, color: 'var(--text-primary)' }}>{formatCurrency(item.amount)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Tax Summary */}
            <div style={{ display: 'flex', justifyContent: 'flex-end', marginTop: 20 }}>
              <div style={{ width: 280, display: 'flex', flexDirection: 'column', gap: 8 }}>
                {[
                  { label: 'Subtotal', value: formatCurrency(po.subtotal) },
                  ...(po.cgst > 0 ? [{ label: 'CGST (9%)', value: formatCurrency(po.cgst) }] : []),
                  ...(po.sgst > 0 ? [{ label: 'SGST (9%)', value: formatCurrency(po.sgst) }] : []),
                  ...(po.igst > 0 ? [{ label: 'IGST (18%)', value: formatCurrency(po.igst) }] : []),
                ].map(row => (
                  <div key={row.label} style={{ display: 'flex', justifyContent: 'space-between', padding: '8px 14px', fontSize: 14 }}>
                    <span style={{ color: 'var(--text-muted)' }}>{row.label}</span>
                    <span style={{ color: 'var(--text-secondary)', fontWeight: 500 }}>{row.value}</span>
                  </div>
                ))}
                <div style={{ display: 'flex', justifyContent: 'space-between', padding: '12px 14px', background: 'var(--accent-glow)', border: '1px solid var(--border-strong)', borderRadius: 10 }}>
                  <span style={{ fontWeight: 700, color: 'var(--text-primary)' }}>Total</span>
                  <span style={{ fontWeight: 800, fontSize: 18, color: 'var(--accent-light)' }}>{formatCurrency(po.total)}</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Right Panel */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
          {/* Actions */}
          <div className="card no-print">
            <div className="card-title" style={{ marginBottom: 16 }}>Update Status</div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
              {['draft', 'confirmed', 'delivered', 'cancelled'].map(s => (
                <button key={s} className={`btn btn-sm ${po.status === s ? 'btn-primary' : 'btn-ghost'}`}
                  style={{ justifyContent: 'flex-start', textTransform: 'capitalize' }}
                  onClick={() => handleStatusUpdate(s)}
                >
                  {po.status === s && '● '}{s}
                </button>
              ))}
            </div>
          </div>

          {/* Invoice Status */}
          <div className="card">
            <div className="card-title" style={{ marginBottom: 12 }}>Invoice</div>
            {existingInvoice ? (
              <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
                <div style={{ padding: '12px 14px', background: 'var(--success-bg)', border: '1px solid rgba(16,185,129,0.3)', borderRadius: 10 }}>
                  <div style={{ fontSize: 13, fontWeight: 700, color: 'var(--success)' }}>{existingInvoice.invoiceNumber}</div>
                  <div style={{ fontSize: 12, color: 'var(--text-muted)', marginTop: 2 }}>
                    {formatDate(existingInvoice.issuedDate)} · <Badge status={existingInvoice.status} />
                  </div>
                </div>
                <button className="btn btn-ghost btn-sm w-full" style={{ justifyContent: 'center' }}
                  onClick={() => navigate(`/invoices/${existingInvoice.id}`)}>
                  View Invoice
                </button>
              </div>
            ) : (
              <div style={{ textAlign: 'center', padding: '16px 0' }}>
                <div style={{ fontSize: 13, color: 'var(--text-muted)', marginBottom: 12 }}>
                  {po.status === 'delivered' ? 'Ready to generate invoice.' : 'Mark PO as delivered to generate invoice.'}
                </div>
                {po.status === 'delivered' && (
                  <button className="btn btn-primary btn-sm w-full" style={{ justifyContent: 'center' }} onClick={handleGenerateInvoice}>
                    <FileText size={14} /> Generate Invoice
                  </button>
                )}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
