import { useParams, useNavigate } from 'react-router-dom';
import { useAppData } from '../../context/AppDataContext';
import { useAuth } from '../../context/AuthContext';
import Badge from '../../components/Badge';
import { formatCurrency, formatDate } from '../../utils/helpers';
import { downloadInvoicePDF } from '../../utils/pdfExport';
import { ArrowLeft, Download, Printer, Mail, CheckCircle } from 'lucide-react';

export default function InvoiceDetail() {
  const { id } = useParams();
  const { invoices, addToast, addLog, updateInvoice } = useAppData();
  const { currentUser } = useAuth();
  const navigate = useNavigate();

  const invoice = invoices.find(i => i.id === id);
  if (!invoice) return <div style={{ padding: 40, color: 'var(--text-muted)' }}>Invoice not found.</div>;

  const gst = (invoice.cgst || 0) + (invoice.sgst || 0) + (invoice.igst || 0);

  const handleMarkPaid = async () => {
    await updateInvoice(invoice.id, { ...invoice, status: 'paid', paidDate: new Date().toISOString().split('T')[0] });
    addLog(currentUser.id, currentUser.name, 'Marked Invoice Paid', 'Invoice', invoice.id, invoice.invoiceNumber);
    addToast(`Invoice ${invoice.invoiceNumber} marked as paid!`);
  };

  const handleEmail = () => {
    addToast(`Invoice ${invoice.invoiceNumber} sent to ${invoice.vendorName} via email.`, 'info');
  };

  const handlePrint = () => window.print();

  return (
    <div className="animate-fade">
      {/* Actions Bar */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 14, marginBottom: 28 }} className="no-print">
        <button className="btn btn-ghost btn-sm" onClick={() => navigate('/invoices')}>
          <ArrowLeft size={15} /> Back
        </button>
        <div style={{ flex: 1 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <h1 className="page-title">{invoice.invoiceNumber}</h1>
            <Badge status={invoice.status} />
          </div>
          <p className="page-subtitle">PO Ref: {invoice.poNumber} · Due {formatDate(invoice.dueDate)}</p>
        </div>
        <div style={{ display: 'flex', gap: 10 }}>
          <button className="btn btn-ghost btn-sm" onClick={handlePrint}>
            <Printer size={14} /> Print
          </button>
          <button className="btn btn-ghost btn-sm" onClick={handleEmail}>
            <Mail size={14} /> Email
          </button>
          <button className="btn btn-secondary btn-sm" onClick={() => downloadInvoicePDF(invoice)}>
            <Download size={14} /> Download PDF
          </button>
          {invoice.status === 'pending' && (
            <button className="btn btn-success btn-sm" onClick={handleMarkPaid}>
              <CheckCircle size={14} /> Mark as Paid
            </button>
          )}
        </div>
      </div>

      {/* Invoice Document */}
      <div className="card" style={{ maxWidth: 860, margin: '0 auto' }}>
        {/* Invoice Header */}
        <div style={{ background: 'linear-gradient(135deg, #6366f1, #4338ca)', borderRadius: 12, padding: '28px 32px', marginBottom: 32, display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
          <div>
            <div style={{ fontSize: 24, fontWeight: 800, color: 'white', letterSpacing: '-0.5px' }}>⬡ VendorBridge</div>
            <div style={{ fontSize: 12, color: 'rgba(255,255,255,0.7)', marginTop: 4, letterSpacing: '1px', textTransform: 'uppercase' }}>
              Procurement & Vendor Management ERP
            </div>
          </div>
          <div style={{ textAlign: 'right' }}>
            <div style={{ fontSize: 12, color: 'rgba(255,255,255,0.7)', letterSpacing: '1px', textTransform: 'uppercase', fontWeight: 600, marginBottom: 4 }}>Tax Invoice</div>
            <div style={{ fontSize: 22, fontWeight: 800, color: 'white', fontFamily: 'monospace' }}>{invoice.invoiceNumber}</div>
          </div>
        </div>

        {/* Meta Info */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 24, marginBottom: 32 }}>
          <div>
            <div style={{ fontSize: 11, color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.8px', fontWeight: 600, marginBottom: 8 }}>Bill From</div>
            <div style={{ fontSize: 16, fontWeight: 700, color: 'var(--text-primary)', marginBottom: 4 }}>{invoice.vendorName}</div>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
            {[
              { label: 'Invoice Date', value: formatDate(invoice.issuedDate) },
              { label: 'Due Date', value: formatDate(invoice.dueDate) },
              { label: 'PO Reference', value: invoice.poNumber },
              { label: 'Paid Date', value: invoice.paidDate ? formatDate(invoice.paidDate) : '—' },
            ].map(item => (
              <div key={item.label}>
                <div style={{ fontSize: 11, color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.8px', fontWeight: 600, marginBottom: 2 }}>{item.label}</div>
                <div style={{ fontSize: 13, fontWeight: 600, color: 'var(--text-primary)', fontFamily: item.label === 'PO Reference' ? 'monospace' : 'inherit' }}>{item.value}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Line Items Table */}
        <div style={{ marginBottom: 24 }}>
          <div className="table-wrap">
            <table>
              <thead>
                <tr>
                  <th>#</th>
                  <th>Description</th>
                  <th>Qty</th>
                  <th>Unit Price</th>
                  <th style={{ textAlign: 'right' }}>Amount</th>
                </tr>
              </thead>
              <tbody>
                {invoice.lineItems.map((item, i) => (
                  <tr key={i}>
                    <td style={{ color: 'var(--text-muted)', width: 40 }}>{i + 1}</td>
                    <td className="td-primary">{item.description}</td>
                    <td>{item.quantity}</td>
                    <td>{formatCurrency(item.unitPrice)}</td>
                    <td style={{ textAlign: 'right', fontWeight: 700, color: 'var(--text-primary)' }}>{formatCurrency(item.amount)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Tax & Total Summary */}
        <div style={{ display: 'flex', justifyContent: 'flex-end' }}>
          <div style={{ width: 320, display: 'flex', flexDirection: 'column', gap: 0, border: '1px solid var(--border)', borderRadius: 12, overflow: 'hidden' }}>
            {[
              { label: 'Subtotal', value: formatCurrency(invoice.subtotal), primary: false },
              ...(invoice.cgst > 0 ? [
                { label: 'CGST (9%)', value: formatCurrency(invoice.cgst), primary: false },
                { label: 'SGST (9%)', value: formatCurrency(invoice.sgst), primary: false },
              ] : []),
              ...(invoice.igst > 0 ? [{ label: 'IGST (18%)', value: formatCurrency(invoice.igst), primary: false }] : []),
            ].map(row => (
              <div key={row.label} style={{ display: 'flex', justifyContent: 'space-between', padding: '12px 18px', borderBottom: '1px solid var(--border)', background: 'var(--bg-elevated)' }}>
                <span style={{ fontSize: 14, color: 'var(--text-muted)' }}>{row.label}</span>
                <span style={{ fontSize: 14, color: 'var(--text-secondary)', fontWeight: 500 }}>{row.value}</span>
              </div>
            ))}
            <div style={{ display: 'flex', justifyContent: 'space-between', padding: '16px 18px', background: 'linear-gradient(135deg, rgba(99,102,241,0.15), rgba(6,182,212,0.08))', borderTop: '2px solid var(--border-strong)' }}>
              <span style={{ fontSize: 16, fontWeight: 800, color: 'var(--text-primary)' }}>Total</span>
              <span style={{ fontSize: 22, fontWeight: 800, color: 'var(--accent-light)' }}>{formatCurrency(invoice.total)}</span>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div style={{ marginTop: 32, paddingTop: 20, borderTop: '1px solid var(--border)', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <div style={{ fontSize: 12, color: 'var(--text-muted)' }}>
            Thank you for your business. This is a computer-generated invoice.
          </div>
          <Badge status={invoice.status} />
        </div>
      </div>
    </div>
  );
}
