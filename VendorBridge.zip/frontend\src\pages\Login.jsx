import { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { useAppData } from '../context/AppDataContext';
import { Eye, EyeOff, Shield, ShoppingBag, Truck, Briefcase } from 'lucide-react';

const ROLES = [
  { id: 'admin',       label: 'Admin',       icon: <Shield size={20} />,     hint: 'admin@vendorbridge.com / admin123',       sub: 'Manage users & vendors' },
  { id: 'procurement', label: 'Procurement', icon: <ShoppingBag size={20} />, hint: 'procurement@vendorbridge.com / proc123',   sub: 'Create RFQs & invoices' },
  { id: 'manager',     label: 'Manager',     icon: <Briefcase size={20} />,   hint: 'manager@vendorbridge.com / manager123',   sub: 'Approve & monitor' },
  { id: 'vendor',      label: 'Vendor',      icon: <Truck size={20} />,       hint: 'vendor@vendorbridge.com / vendor123',     sub: 'Submit quotations' },
];

export default function Login() {
  const [email, setEmail] = useState('admin@vendorbridge.com');
  const [password, setPassword] = useState('admin123');
  const [showPw, setShowPw] = useState(false);
  const [selectedRole, setSelectedRole] = useState('admin');
  const [showForgot, setShowForgot] = useState(false);
  const [forgotEmail, setForgotEmail] = useState('');
  const { login, error } = useAuth();
  const { addToast } = useAppData();
  const navigate = useNavigate();

  const handleForgotSubmit = (e) => {
    e.preventDefault();
    addToast(`Password reset link sent to ${forgotEmail}`, 'success');
    setShowForgot(false);
    setForgotEmail('');
  };

  const handleRoleSelect = (role) => {
    setSelectedRole(role.id);
    const hint = role.hint.split(' / ');
    setEmail(hint[0]);
    setPassword(hint[1]);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const success = await login(email, password);
    if (success) navigate('/dashboard');
  };

  return (
    <div className="auth-split-container">
      {/* Left side: Graphic */}
      <div className="auth-graphic-side">
        <div className="auth-graphic-pattern" />
        <div className="auth-graphic-content">
          <div className="auth-graphic-title">⬡ VendorBridge</div>
          <p className="auth-graphic-text">
            Digitize and streamline your procurement operations. Centralized vendor communication, RFQ tracking, automated PO & Invoice handling, and real-time analytics.
          </p>
        </div>
      </div>

      {/* Right side: Form */}
      <div className="auth-form-side">
        <div className="auth-bg-glow auth-bg-glow-1" />
        <div className="auth-bg-glow auth-bg-glow-2" />

        <div className="auth-card">
          <div className="auth-logo">
            <div className="auth-logo-text">⬡ VendorBridge</div>
            <div className="auth-logo-sub">Procurement & Vendor Management ERP</div>
          </div>

          <h1 className="auth-title">Welcome back</h1>
          <p className="auth-subtitle">Sign in to your account to continue</p>

          <div className="role-selector" style={{ gridTemplateColumns: '1fr 1fr', gap: 10 }}>
            {ROLES.map(role => (
              <button
                key={role.id}
                type="button"
                className={`role-btn ${selectedRole === role.id ? 'selected' : ''}`}
                onClick={() => handleRoleSelect(role)}
                style={{ flexDirection: 'column', alignItems: 'center', gap: 6, padding: '14px 10px' }}
              >
                <span className="role-btn-icon">{role.icon}</span>
                <span style={{ fontWeight: 700, fontSize: 13 }}>{role.label}</span>
                <span style={{ fontSize: 11, color: selectedRole === role.id ? 'rgba(255,255,255,0.7)' : 'var(--text-muted)', lineHeight: 1.3 }}>{role.sub}</span>
              </button>
            ))}
          </div>

          <form className="auth-form" onSubmit={handleSubmit}>
            <div className="form-group">
              <label className="form-label">Email Address</label>
              <input
                className="form-input"
                type="email"
                value={email}
                onChange={e => setEmail(e.target.value)}
                placeholder="Enter your email"
                required
              />
            </div>

            <div className="form-group">
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <label className="form-label">Password</label>
                <button
                  type="button"
                  className="auth-link"
                  style={{ fontSize: 12, background: 'none', border: 'none', padding: 0, cursor: 'pointer' }}
                  onClick={() => setShowForgot(true)}
                >
                  Forgot password?
                </button>
              </div>
              <div style={{ position: 'relative' }}>
                <input
                  className="form-input"
                  type={showPw ? 'text' : 'password'}
                  value={password}
                  onChange={e => setPassword(e.target.value)}
                  placeholder="Enter your password"
                  style={{ paddingRight: 44 }}
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowPw(!showPw)}
                  style={{ position: 'absolute', right: 12, top: '50%', transform: 'translateY(-50%)', background: 'none', color: 'var(--text-muted)', display: 'flex', border: 'none', cursor: 'pointer' }}
                >
                  {showPw ? <EyeOff size={16} /> : <Eye size={16} />}
                </button>
              </div>
            </div>

            {error && <p className="form-error" style={{ textAlign: 'center' }}>{error}</p>}

            <button type="submit" className="btn btn-primary w-full" style={{ justifyContent: 'center', marginTop: 4 }}>
              Sign In
            </button>

            <p style={{ textAlign: 'center', fontSize: 13, color: 'var(--text-muted)', marginTop: 8 }}>
              Don't have an account?{' '}
              <Link to="/signup" className="auth-link">Create one</Link>
            </p>
          </form>
        </div>
      </div>

      {/* Forgot Password Modal */}
      {showForgot && (
        <div style={{ position: 'fixed', inset: 0, zIndex: 1000, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 20 }}>
          <div style={{ position: 'absolute', inset: 0, background: 'rgba(0,0,0,0.6)', backdropFilter: 'blur(4px)' }} onClick={() => setShowForgot(false)} />
          <div className="card" style={{ position: 'relative', width: '100%', maxWidth: 400, zIndex: 1, padding: 24, boxShadow: '0 20px 50px rgba(0,0,0,0.5)' }}>
            <h3 style={{ fontSize: 18, fontWeight: 700, marginBottom: 8, color: 'var(--text-primary)' }}>Reset Password</h3>
            <p style={{ fontSize: 13, color: 'var(--text-muted)', marginBottom: 20 }}>Enter your email address and we'll send you a link to reset your password.</p>
            <form onSubmit={handleForgotSubmit}>
              <div className="form-group" style={{ marginBottom: 20 }}>
                <label className="form-label">Email Address</label>
                <input
                  type="email"
                  className="form-input"
                  required
                  placeholder="name@company.com"
                  value={forgotEmail}
                  onChange={e => setForgotEmail(e.target.value)}
                />
              </div>
              <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 10 }}>
                <button type="button" className="btn btn-ghost" onClick={() => setShowForgot(false)}>Cancel</button>
                <button type="submit" className="btn btn-primary">Send Reset Link</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
