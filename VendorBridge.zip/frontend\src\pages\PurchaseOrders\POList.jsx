import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAppData } from '../../context/AppDataContext';
import { useAuth } from '../../context/AuthContext';
import Badge from '../../components/Badge';
import { formatCurrency, formatDate } from '../../utils/helpers';
import { Search, ShoppingCart, Plus } from 'lucide-react';

export default function POList() {
  const { purchaseOrders } = useAppData();
  const navigate = useNavigate();
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');

  const filtered = purchaseOrders.filter(p => {
    const matchSearch = p.poNumber.toLowerCase().includes(search.toLowerCase()) ||
      p.vendorName.toLowerCase().includes(search.toLowerCase());
    const matchStatus = statusFilter === 'all' || p.status === statusFilter;
    return matchSearch && matchStatus;
  });

  const totalValue = purchaseOrders.reduce((s, p) => s + p.total, 0);

  return (
    <div className="animate-fade">
      <div className="page-header">
        <div>
          <h1 className="page-title">Purchase Orders</h1>
          <p className="page-subtitle">{purchaseOrders.length} orders · Total value {formatCurrency(totalValue)}</p>
        </div>
      </div>

      {/* Quick Stats */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 16, marginBottom: 24 }}>
        {['draft', 'confirmed', 'delivered', 'cancelled'].map(status => {
          const count = purchaseOrders.filter(p => p.status === status).length;
          const colors = { draft: 'var(--text-muted)', confirmed: 'var(--accent-light)', delivered: 'var(--success)', cancelled: 'var(--danger)' };
          return (
            <div key={status} className="card" style={{ cursor: 'pointer', textAlign: 'center', padding: '16px' }}
              onClick={() => setStatusFilter(status)}>
              <div style={{ fontSize: 28, fontWeight: 800, color: colors[status] }}>{count}</div>
              <div style={{ fontSize: 12, color: 'var(--text-muted)', textTransform: 'capitalize', marginTop: 4 }}>{status}</div>
            </div>
          );
        })}
      </div>

      <div className="search-bar">
        <div className="search-input-wrap" style={{ flex: 2 }}>
          <Search size={16} />
          <input className="search-input" placeholder="Search by PO number or vendor…" value={search} onChange={e => setSearch(e.target.value)} />
        </div>
        <select className="filter-select" value={statusFilter} onChange={e => setStatusFilter(e.target.value)}>
          {['all', 'draft', 'confirmed', 'delivered', 'cancelled'].map(s => (
            <option key={s} value={s}>{s === 'all' ? 'All Statuses' : s.charAt(0).toUpperCase() + s.slice(1)}</option>
          ))}
        </select>
      </div>

      <div className="table-wrap">
        <table>
          <thead>
            <tr>
              <th>PO Number</th>
              <th>Vendor</th>
              <th>Created</th>
              <th>Delivery Date</th>
              <th>Subtotal</th>
              <th>GST</th>
              <th>Total</th>
              <th>Status</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            {filtered.map(po => (
              <tr key={po.id} style={{ cursor: 'pointer' }} onClick={() => navigate(`/purchase-orders/${po.id}`)}>
                <td>
                  <span style={{ fontFamily: 'monospace', fontSize: 13, color: 'var(--accent-light)', fontWeight: 600 }}>{po.poNumber}</span>
                </td>
                <td className="td-primary">{po.vendorName}</td>
                <td>{formatDate(po.createdAt)}</td>
                <td>{formatDate(po.deliveryDate)}</td>
                <td>{formatCurrency(po.subtotal)}</td>
                <td>{formatCurrency((po.cgst || 0) + (po.sgst || 0) + (po.igst || 0))}</td>
                <td style={{ fontWeight: 800, fontSize: 15, color: 'var(--text-primary)' }}>{formatCurrency(po.total)}</td>
                <td><Badge status={po.status} /></td>
                <td>
                  <button className="btn btn-ghost btn-sm" onClick={e => { e.stopPropagation(); navigate(`/purchase-orders/${po.id}`); }}>
                    View
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {filtered.length === 0 && (
        <div className="empty-state">
          <ShoppingCart size={40} style={{ margin: '0 auto 12px', opacity: 0.3 }} />
          <h3>No purchase orders found</h3>
          <p>Accept a quotation to auto-generate a PO</p>
        </div>
      )}
    </div>
  );
}
