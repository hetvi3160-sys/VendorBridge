const Database = require('better-sqlite3');
const path = require('path');

const db = new Database(path.join(__dirname, 'database.sqlite'));

db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

const initDB = () => {
  // Users
  db.exec(`
    CREATE TABLE IF NOT EXISTS users (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      email TEXT UNIQUE NOT NULL,
      password TEXT NOT NULL,
      role TEXT NOT NULL,
      avatar TEXT,
      department TEXT
    )
  `);

  // Vendors
  db.exec(`
    CREATE TABLE IF NOT EXISTS vendors (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      gstNumber TEXT,
      category TEXT,
      contactPerson TEXT,
      email TEXT,
      phone TEXT,
      status TEXT DEFAULT 'pending',
      performanceScore INTEGER DEFAULT 0,
      city TEXT,
      state TEXT,
      bankAccount TEXT,
      joiningDate TEXT,
      totalOrders INTEGER DEFAULT 0,
      totalValue REAL DEFAULT 0
    )
  `);

  // RFQs
  db.exec(`
    CREATE TABLE IF NOT EXISTS rfqs (
      id TEXT PRIMARY KEY,
      rfqNumber TEXT UNIQUE NOT NULL,
      title TEXT NOT NULL,
      description TEXT,
      deadline TEXT,
      status TEXT DEFAULT 'draft',
      createdBy TEXT,
      createdAt TEXT,
      budget REAL DEFAULT 0,
      FOREIGN KEY (createdBy) REFERENCES users(id)
    )
  `);

  // RFQ Items
  db.exec(`
    CREATE TABLE IF NOT EXISTS rfq_items (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      rfqId TEXT NOT NULL,
      name TEXT NOT NULL,
      quantity INTEGER NOT NULL,
      unit TEXT NOT NULL,
      FOREIGN KEY (rfqId) REFERENCES rfqs(id) ON DELETE CASCADE
    )
  `);

  // RFQ-Vendor mapping
  db.exec(`
    CREATE TABLE IF NOT EXISTS rfq_vendors (
      rfqId TEXT NOT NULL,
      vendorId TEXT NOT NULL,
      PRIMARY KEY (rfqId, vendorId),
      FOREIGN KEY (rfqId) REFERENCES rfqs(id) ON DELETE CASCADE,
      FOREIGN KEY (vendorId) REFERENCES vendors(id) ON DELETE CASCADE
    )
  `);

  // Quotations
  db.exec(`
    CREATE TABLE IF NOT EXISTS quotations (
      id TEXT PRIMARY KEY,
      rfqId TEXT NOT NULL,
      vendorId TEXT NOT NULL,
      deliveryDays INTEGER DEFAULT 0,
      totalAmount REAL DEFAULT 0,
      status TEXT DEFAULT 'pending',
      submittedAt TEXT,
      validity INTEGER DEFAULT 30,
      notes TEXT,
      FOREIGN KEY (rfqId) REFERENCES rfqs(id),
      FOREIGN KEY (vendorId) REFERENCES vendors(id)
    )
  `);

  // Quotation line items
  db.exec(`
    CREATE TABLE IF NOT EXISTS quotation_items (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      quotationId TEXT NOT NULL,
      product TEXT NOT NULL,
      unitPrice REAL NOT NULL,
      quantity INTEGER NOT NULL,
      FOREIGN KEY (quotationId) REFERENCES quotations(id) ON DELETE CASCADE
    )
  `);

  // Approvals
  db.exec(`
    CREATE TABLE IF NOT EXISTS approvals (
      id TEXT PRIMARY KEY,
      type TEXT NOT NULL,
      refId TEXT,
      refTitle TEXT,
      requestedBy TEXT,
      requestedByName TEXT,
      amount REAL DEFAULT 0,
      status TEXT DEFAULT 'pending',
      remarks TEXT,
      createdAt TEXT,
      resolvedAt TEXT,
      resolvedBy TEXT,
      FOREIGN KEY (requestedBy) REFERENCES users(id)
    )
  `);

  // Purchase Orders
  db.exec(`
    CREATE TABLE IF NOT EXISTS purchase_orders (
      id TEXT PRIMARY KEY,
      poNumber TEXT UNIQUE NOT NULL,
      rfqId TEXT,
      quotationId TEXT,
      vendorId TEXT,
      vendorName TEXT,
      subtotal REAL DEFAULT 0,
      cgst REAL DEFAULT 0,
      sgst REAL DEFAULT 0,
      igst REAL DEFAULT 0,
      total REAL DEFAULT 0,
      status TEXT DEFAULT 'confirmed',
      deliveryDate TEXT,
      createdAt TEXT,
      createdBy TEXT,
      terms TEXT,
      FOREIGN KEY (rfqId) REFERENCES rfqs(id),
      FOREIGN KEY (vendorId) REFERENCES vendors(id)
    )
  `);

  // PO Line Items
  db.exec(`
    CREATE TABLE IF NOT EXISTS po_line_items (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      poId TEXT NOT NULL,
      description TEXT NOT NULL,
      quantity INTEGER NOT NULL,
      unitPrice REAL NOT NULL,
      amount REAL NOT NULL,
      FOREIGN KEY (poId) REFERENCES purchase_orders(id) ON DELETE CASCADE
    )
  `);

  // Invoices
  db.exec(`
    CREATE TABLE IF NOT EXISTS invoices (
      id TEXT PRIMARY KEY,
      invoiceNumber TEXT UNIQUE NOT NULL,
      poId TEXT,
      poNumber TEXT,
      vendorId TEXT,
      vendorName TEXT,
      subtotal REAL DEFAULT 0,
      cgst REAL DEFAULT 0,
      sgst REAL DEFAULT 0,
      igst REAL DEFAULT 0,
      total REAL DEFAULT 0,
      status TEXT DEFAULT 'pending',
      dueDate TEXT,
      issuedDate TEXT,
      paidDate TEXT,
      FOREIGN KEY (poId) REFERENCES purchase_orders(id),
      FOREIGN KEY (vendorId) REFERENCES vendors(id)
    )
  `);

  // Invoice Line Items
  db.exec(`
    CREATE TABLE IF NOT EXISTS invoice_line_items (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      invoiceId TEXT NOT NULL,
      description TEXT NOT NULL,
      quantity INTEGER NOT NULL,
      unitPrice REAL NOT NULL,
      amount REAL NOT NULL,
      FOREIGN KEY (invoiceId) REFERENCES invoices(id) ON DELETE CASCADE
    )
  `);

  // Audit Logs
  db.exec(`
    CREATE TABLE IF NOT EXISTS audit_logs (
      id TEXT PRIMARY KEY,
      userId TEXT,
      userName TEXT,
      action TEXT NOT NULL,
      entityType TEXT,
      entityId TEXT,
      entityTitle TEXT,
      timestamp TEXT,
      ipAddress TEXT
    )
  `);

  console.log('Database initialized successfully.');
};

module.exports = { db, initDB };
