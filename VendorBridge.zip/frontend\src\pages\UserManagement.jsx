import { useState } from 'react';
import { useAuth, ROLE_PERMISSIONS } from '../context/AuthContext';
import { users } from '../utils/mockData';
import Modal from '../components/Modal';
import Badge from '../components/Badge';
import { Search, Plus, UserCheck, UserX, Shield, ShoppingBag, Truck, Briefcase, Users } from 'lucide-react';

const ROLE_ICONS = {
  admin: <Shield size={14} />,
  procurement: <ShoppingBag size={14} />,
  manager: <Briefcase size={14} />,
  vendor: <Truck size={14} />,
};

const ROLE_COLORS = {
  admin:       { bg: 'rgba(99,102,241,0.15)', color: 'var(--accent-light)' },
  procurement: { bg: 'rgba(6,182,212,0.15)',  color: 'var(--cyan)' },
  vendor:      { bg: 'rgba(16,185,129,0.15)', color: 'var(--success)' },
  manager:     { bg: 'rgba(245,158,11,0.15)', color: 'var(--warning)' },
};

export default function UserManagement() {
  const { can, currentUser } = useAuth();
  const [allUsers, setAllUsers] = useState([...users]);
  const [search, setSearch] = useState('');
  const [roleFilter, setRoleFilter] = useState('all');
  const [addModal, setAddModal] = useState(false);
  const [permModal, setPermModal] = useState(null); // selected user for permissions view
  const [form, setForm] = useState({ name: '', email: '', password: '', role: 'procurement', department: '' });

  if (!can('canManageUsers')) {
    return (
      <div style={{ padding: 60, textAlign: 'center', color: 'var(--text-muted)' }}>
        <Shield size={48} style={{ margin: '0 auto 16px', opacity: 0.3 }} />
        <h2 style={{ color: 'var(--text-secondary)', marginBottom: 8 }}>Access Restricted</h2>
        <p>Only Admins can manage users.</p>
      </div>
    );
  }

  const filtered = allUsers.filter(u => {
    const matchSearch = u.name.toLowerCase().includes(search.toLowerCase()) ||
      u.email.toLowerCase().includes(search.toLowerCase());
    const matchRole = roleFilter === 'all' || u.role === roleFilter;
    return matchSearch && matchRole;
  });

  const handleAdd = (e) => {
    e.preventDefault();
    const newUser = {
      id: `u${Date.now()}`,
      ...form,
      avatar: form.name.slice(0, 2).toUpperCase(),
      status: 'active',
    };
    users.push(newUser);
    setAllUsers([...users]);
    setAddModal(false);
    setForm({ name: '', email: '', password: '', role: 'procurement', department: '' });
  };

  const handleToggleStatus = (userId) => {
    const idx = users.findIndex(u => u.id === userId);
    if (idx !== -1) {
      users[idx] = { ...users[idx], status: users[idx].status === 'inactive' ? 'active' : 'inactive' };
      setAllUsers([...users]);
    }
  };

  const roleStats = Object.keys(ROLE_PERMISSIONS).map(role => ({
    role,
    label: ROLE_PERMISSIONS[role].label,
    count: allUsers.filter(u => u.role === role).length,
    ...ROLE_COLORS[role],
  }));

  return (
    <div className="animate-fade">
      <div className="page-header">
        <div>
          <h1 className="page-title">User Management</h1>
          <p className="page-subtitle">{allUsers.length} total users across {Object.keys(ROLE_PERMISSIONS).length} roles</p>
        </div>
        <button className="btn btn-primary" onClick={() => setAddModal(true)}>
          <Plus size={16} /> Add User
        </button>
      </div>

      {/* Role Stats */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 16, marginBottom: 28 }}>
        {roleStats.map(s => (
          <div key={s.role} className="card" style={{ padding: '18px 20px', cursor: 'pointer' }}
            onClick={() => setRoleFilter(s.role === roleFilter ? 'all' : s.role)}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 12 }}>
              <div style={{ width: 38, height: 38, borderRadius: 10, background: s.bg, color: s.color, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                {ROLE_ICONS[s.role]}
              </div>
              <div style={{ fontSize: 24, fontWeight: 800, color: 'var(--text-primary)', lineHeight: 1 }}>{s.count}</div>
            </div>
            <div style={{ fontSize: 13, fontWeight: 600, color: s.color }}>{s.label}</div>
            <div style={{ fontSize: 11, color: 'var(--text-muted)', marginTop: 2 }}>
              {Object.entries(ROLE_PERMISSIONS[s.role]).filter(([k,v]) => v === true && k !== 'canViewAllData').slice(0, 2).map(([k]) =>
                k.replace('can','').replace(/([A-Z])/g,' $1').trim()
              ).join(', ')}…
            </div>
          </div>
        ))}
      </div>

      {/* Search */}
      <div className="search-bar">
        <div className="search-input-wrap" style={{ flex: 2 }}>
          <Search size={16} />
          <input className="search-input" placeholder="Search by name or email…" value={search} onChange={e => setSearch(e.target.value)} />
        </div>
        <select className="filter-select" value={roleFilter} onChange={e => setRoleFilter(e.target.value)}>
          <option value="all">All Roles</option>
          {Object.entries(ROLE_PERMISSIONS).map(([k, v]) => <option key={k} value={k}>{v.label}</option>)}
        </select>
      </div>

      {/* Users Table */}
      <div className="table-wrap">
        <table>
          <thead>
            <tr>
              <th>User</th>
              <th>Email</th>
              <th>Role</th>
              <th>Department</th>
              <th>Permissions</th>
              <th>Status</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            {filtered.map(u => {
              const perms = ROLE_PERMISSIONS[u.role];
              const activePerms = Object.entries(perms || {}).filter(([k,v]) => v === true && !['canViewAllData'].includes(k));
              const isCurrentUser = u.id === currentUser?.id;
              const isActive = u.status !== 'inactive';
              const roleC = ROLE_COLORS[u.role] || ROLE_COLORS.admin;
              return (
                <tr key={u.id}>
                  <td>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                      <div style={{ width: 34, height: 34, borderRadius: 999, background: `linear-gradient(135deg, ${roleC.color}, var(--accent))`, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 12, fontWeight: 800, color: 'white', flexShrink: 0 }}>
                        {u.avatar}
                      </div>
                      <div>
                        <div style={{ fontWeight: 700, fontSize: 13, color: 'var(--text-primary)' }}>{u.name}</div>
                        {isCurrentUser && <div style={{ fontSize: 10, color: 'var(--accent-light)' }}>You</div>}
                      </div>
                    </div>
                  </td>
                  <td style={{ fontSize: 13, color: 'var(--text-muted)' }}>{u.email}</td>
                  <td>
                    <div style={{ display: 'inline-flex', alignItems: 'center', gap: 6, padding: '4px 10px', borderRadius: 20, fontSize: 12, fontWeight: 700, ...roleC }}>
                      {ROLE_ICONS[u.role]}
                      <span style={{ textTransform: 'capitalize' }}>{perms?.label || u.role}</span>
                    </div>
                  </td>
                  <td style={{ fontSize: 13, color: 'var(--text-secondary)' }}>{u.department}</td>
                  <td>
                    <div style={{ display: 'flex', gap: 4, flexWrap: 'wrap' }}>
                      {activePerms.slice(0, 3).map(([k]) => (
                        <span key={k} style={{ fontSize: 10, padding: '2px 7px', borderRadius: 999, background: 'var(--bg-elevated)', border: '1px solid var(--border)', color: 'var(--text-muted)', whiteSpace: 'nowrap' }}>
                          {k.replace('can','').replace(/([A-Z])/g,' $1').trim()}
                        </span>
                      ))}
                      {activePerms.length > 3 && (
                        <span style={{ fontSize: 10, padding: '2px 7px', borderRadius: 999, background: 'var(--bg-elevated)', border: '1px solid var(--border)', color: 'var(--text-muted)', cursor: 'pointer' }}
                          onClick={() => setPermModal(u)}>
                          +{activePerms.length - 3}
                        </span>
                      )}
                    </div>
                  </td>
                  <td>
                    <div style={{ display: 'inline-flex', alignItems: 'center', gap: 5, padding: '4px 10px', borderRadius: 20, fontSize: 12, fontWeight: 600,
                      background: isActive ? 'var(--success-bg)' : 'var(--danger-bg)',
                      color: isActive ? 'var(--success)' : 'var(--danger)',
                    }}>
                      <span style={{ width: 6, height: 6, borderRadius: '50%', background: 'currentColor' }} />
                      {isActive ? 'Active' : 'Inactive'}
                    </div>
                  </td>
                  <td>
                    {!isCurrentUser && (
                      <button
                        className={`btn btn-sm ${isActive ? 'btn-danger' : 'btn-success'}`}
                        onClick={() => handleToggleStatus(u.id)}
                        style={{ minWidth: 90 }}
                      >
                        {isActive ? <><UserX size={13} /> Deactivate</> : <><UserCheck size={13} /> Activate</>}
                      </button>
                    )}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {/* Add User Modal */}
      <Modal open={addModal} onClose={() => setAddModal(false)} title="Add New User" size="sm"
        footer={<>
          <button className="btn btn-ghost" onClick={() => setAddModal(false)}>Cancel</button>
          <button className="btn btn-primary" form="add-user-form" type="submit">Create User</button>
        </>}
      >
        <form id="add-user-form" onSubmit={handleAdd}>
          <div className="form-grid">
            <div className="form-group form-full">
              <label className="form-label">Full Name</label>
              <input className="form-input" required placeholder="e.g. Rahul Gupta" value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} />
            </div>
            <div className="form-group">
              <label className="form-label">Email</label>
              <input className="form-input" type="email" required placeholder="user@company.com" value={form.email} onChange={e => setForm(f => ({ ...f, email: e.target.value }))} />
            </div>
            <div className="form-group">
              <label className="form-label">Password</label>
              <input className="form-input" type="password" required minLength={6} placeholder="Min 6 chars" value={form.password} onChange={e => setForm(f => ({ ...f, password: e.target.value }))} />
            </div>
            <div className="form-group">
              <label className="form-label">Role</label>
              <select className="form-input" value={form.role} onChange={e => setForm(f => ({ ...f, role: e.target.value }))}>
                {Object.entries(ROLE_PERMISSIONS).map(([k,v]) => <option key={k} value={k}>{v.label}</option>)}
              </select>
            </div>
            <div className="form-group">
              <label className="form-label">Department</label>
              <input className="form-input" placeholder="e.g. Operations" value={form.department} onChange={e => setForm(f => ({ ...f, department: e.target.value }))} />
            </div>
          </div>
          {form.role && (
            <div style={{ marginTop: 16, padding: '12px 14px', background: 'var(--bg-elevated)', borderRadius: 10, border: '1px solid var(--border)' }}>
              <div style={{ fontSize: 12, fontWeight: 700, color: 'var(--text-muted)', marginBottom: 8, textTransform: 'uppercase', letterSpacing: '0.5px' }}>Permissions for {ROLE_PERMISSIONS[form.role]?.label}</div>
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6 }}>
                {Object.entries(ROLE_PERMISSIONS[form.role] || {}).filter(([k,v]) => v === true && k !== 'canViewAllData').map(([k]) => (
                  <span key={k} style={{ fontSize: 11, padding: '2px 8px', borderRadius: 999, background: 'var(--success-bg)', color: 'var(--success)', border: '1px solid rgba(16,185,129,0.3)' }}>
                    ✓ {k.replace('can','').replace(/([A-Z])/g,' $1').trim()}
                  </span>
                ))}
              </div>
            </div>
          )}
        </form>
      </Modal>

      {/* Permissions Detail Modal */}
      <Modal open={!!permModal} onClose={() => setPermModal(null)} title={`Permissions — ${permModal?.name}`} size="sm"
        footer={<button className="btn btn-ghost" onClick={() => setPermModal(null)}>Close</button>}
      >
        {permModal && (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
            {Object.entries(ROLE_PERMISSIONS[permModal.role] || {}).filter(([k]) => k !== 'canViewAllData').map(([k, v]) => (
              <div key={k} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '8px 12px', borderRadius: 8, background: 'var(--bg-elevated)' }}>
                <span style={{ fontSize: 13, color: 'var(--text-secondary)' }}>{k.replace('can','').replace(/([A-Z])/g,' $1').trim()}</span>
                <span style={{ fontSize: 12, fontWeight: 700, padding: '2px 10px', borderRadius: 20,
                  background: v ? 'var(--success-bg)' : 'var(--danger-bg)',
                  color: v ? 'var(--success)' : 'var(--danger)' }}>
                  {v ? '✓ Allowed' : '✗ Denied'}
                </span>
              </div>
            ))}
          </div>
        )}
      </Modal>
    </div>
  );
}
