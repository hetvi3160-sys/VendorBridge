export let EXCHANGE_RATE = 1.0;

export const setExchangeRate = (rate) => {
  EXCHANGE_RATE = rate;
};

export const formatCurrency = (amount) => {
  const converted = amount * EXCHANGE_RATE;
  return new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 0 }).format(converted);
};

export const formatDate = (dateStr) => {
  if (!dateStr) return '—';
  return new Date(dateStr).toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' });
};

export const formatDateTime = (dateStr) => {
  if (!dateStr) return '—';
  return new Date(dateStr).toLocaleString('en-IN', { day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' });
};

export const generatePONumber = () => {
  const year = new Date().getFullYear();
  const seq = String(Math.floor(Math.random() * 9000) + 1000);
  return `PO-${year}-${seq}`;
};

export const generateInvoiceNumber = () => {
  const year = new Date().getFullYear();
  const seq = String(Math.floor(Math.random() * 9000) + 1000);
  return `INV-${year}-${seq}`;
};

export const calculateTax = (subtotal, type = 'intra') => {
  const rate = 0.18;
  if (type === 'inter') {
    return { cgst: 0, sgst: 0, igst: Math.round(subtotal * rate), total: Math.round(subtotal * (1 + rate)) };
  }
  const half = Math.round(subtotal * rate * 0.5);
  return { cgst: half, sgst: half, igst: 0, total: Math.round(subtotal + half * 2) };
};

export const getStatusColor = (status) => {
  const map = {
    active: 'success', approved: 'success', paid: 'success', delivered: 'success', accepted: 'success',
    pending: 'warning', draft: 'default', confirmed: 'info',
    rejected: 'danger', inactive: 'default', cancelled: 'danger', blacklisted: 'danger', closed: 'default',
  };
  return map[status?.toLowerCase()] || 'default';
};

export const getRoleLabel = (role) => {
  const map = { admin: 'Administrator', procurement: 'Procurement Officer', vendor: 'Vendor' };
  return map[role] || role;
};

export const timeAgo = (dateStr) => {
  const diff = Date.now() - new Date(dateStr).getTime();
  const days = Math.floor(diff / 86400000);
  if (days === 0) return 'Today';
  if (days === 1) return 'Yesterday';
  if (days < 30) return `${days} days ago`;
  const months = Math.floor(days / 30);
  return `${months} month${months > 1 ? 's' : ''} ago`;
};

export const truncate = (str, len = 40) => str?.length > len ? str.slice(0, len) + '…' : str;
