import { createContext, useContext, useState, useEffect } from 'react';
import api from '../utils/api';

const AuthContext = createContext(null);

// ─── Role Permission Map ────────────────────────────────────────────────────
export const ROLE_PERMISSIONS = {
  admin: {
    label: 'Admin',
    canManageUsers: true,
    canManageVendors: true,
    canViewAnalytics: true,
    canCreateRFQ: false,
    canCompareQuotations: false,
    canGeneratePO: false,
    canGenerateInvoice: false,
    canSubmitQuotation: false,
    canTrackRFQ: true,
    canViewPO: true,
    canApprove: false,
    canMonitorWorkflows: true,
    canViewAllData: true,
  },
  procurement: {
    label: 'Procurement Officer',
    canManageUsers: false,
    canManageVendors: false,
    canViewAnalytics: false,
    canCreateRFQ: true,
    canCompareQuotations: true,
    canGeneratePO: true,
    canGenerateInvoice: true,
    canSubmitQuotation: false,
    canTrackRFQ: true,
    canViewPO: true,
    canApprove: false,
    canMonitorWorkflows: true,
    canViewAllData: true,
  },
  vendor: {
    label: 'Vendor',
    canManageUsers: false,
    canManageVendors: false,
    canViewAnalytics: false,
    canCreateRFQ: false,
    canCompareQuotations: false,
    canGeneratePO: false,
    canGenerateInvoice: false,
    canSubmitQuotation: true,
    canTrackRFQ: true,
    canViewPO: true,   // own POs only
    canApprove: false,
    canMonitorWorkflows: false,
    canViewAllData: false,
  },
  manager: {
    label: 'Manager / Approver',
    canManageUsers: false,
    canManageVendors: false,
    canViewAnalytics: true,
    canCreateRFQ: false,
    canCompareQuotations: true,   // read-only view
    canGeneratePO: false,
    canGenerateInvoice: false,
    canSubmitQuotation: false,
    canTrackRFQ: true,
    canViewPO: true,
    canApprove: true,
    canMonitorWorkflows: true,
    canViewAllData: true,
  },
};

export function AuthProvider({ children }) {
  const [currentUser, setCurrentUser] = useState(null);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(true);

  // On mount, check if token exists and restore session
  useEffect(() => {
    const token = localStorage.getItem('vb_token');
    const savedUser = localStorage.getItem('vb_user');
    if (token && savedUser) {
      try {
        setCurrentUser(JSON.parse(savedUser));
      } catch {
        localStorage.removeItem('vb_token');
        localStorage.removeItem('vb_user');
      }
    }
    setLoading(false);
  }, []);

  const login = async (email, password) => {
    try {
      setError('');
      const data = await api.login(email, password);
      localStorage.setItem('vb_token', data.token);
      localStorage.setItem('vb_user', JSON.stringify(data.user));
      setCurrentUser(data.user);
      return true;
    } catch (err) {
      setError(err.message || 'Invalid email or password.');
      return false;
    }
  };

  const signup = async (name, email, password, role) => {
    try {
      setError('');
      const data = await api.register(name, email, password, role);
      localStorage.setItem('vb_token', data.token);
      localStorage.setItem('vb_user', JSON.stringify(data.user));
      setCurrentUser(data.user);
      return true;
    } catch (err) {
      setError(err.message || 'Registration failed.');
      return false;
    }
  };

  const logout = () => {
    localStorage.removeItem('vb_token');
    localStorage.removeItem('vb_user');
    setCurrentUser(null);
  };

  // Convenience helper – can('canApprove')
  const can = (permission) => {
    if (!currentUser) return false;
    return !!(ROLE_PERMISSIONS[currentUser.role]?.[permission]);
  };

  if (loading) {
    return <div style={{ display: 'flex', height: '100vh', alignItems: 'center', justifyContent: 'center', background: 'var(--bg-primary)', color: 'var(--text-muted)', fontSize: 14 }}>Loading...</div>;
  }

  return (
    <AuthContext.Provider value={{ currentUser, login, signup, logout, error, setError, can, ROLE_PERMISSIONS }}>
      {children}
    </AuthContext.Provider>
  );
}

export const useAuth = () => useContext(AuthContext);
