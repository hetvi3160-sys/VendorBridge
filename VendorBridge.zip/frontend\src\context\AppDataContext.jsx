import { createContext, useContext, useReducer, useEffect, useState } from 'react';
import api from '../utils/api';
import { generatePONumber, generateInvoiceNumber, setExchangeRate } from '../utils/helpers';

const AppDataContext = createContext(null);

const initialState = {
  vendors: [],
  rfqs: [],
  quotations: [],
  approvals: [],
  purchaseOrders: [],
  invoices: [],
  auditLogs: [],
  toasts: [],
  loading: true,
};

function reducer(state, action) {
  switch (action.type) {
    case 'SET_DATA':
      return { ...state, ...action.payload, loading: false };
    case 'SET_VENDORS':
      return { ...state, vendors: action.payload };
    case 'SET_RFQS':
      return { ...state, rfqs: action.payload };
    case 'SET_QUOTATIONS':
      return { ...state, quotations: action.payload };
    case 'SET_APPROVALS':
      return { ...state, approvals: action.payload };
    case 'SET_PURCHASE_ORDERS':
      return { ...state, purchaseOrders: action.payload };
    case 'SET_INVOICES':
      return { ...state, invoices: action.payload };
    case 'SET_AUDIT_LOGS':
      return { ...state, auditLogs: action.payload };
    case 'ADD_VENDOR':
      return { ...state, vendors: [...state.vendors, action.payload] };
    case 'UPDATE_VENDOR':
      return { ...state, vendors: state.vendors.map(v => v.id === action.payload.id ? action.payload : v) };
    case 'ADD_RFQ':
      return { ...state, rfqs: [...state.rfqs, action.payload] };
    case 'UPDATE_RFQ':
      return { ...state, rfqs: state.rfqs.map(r => r.id === action.payload.id ? action.payload : r) };
    case 'ADD_QUOTATION':
      return { ...state, quotations: [...state.quotations, action.payload] };
    case 'UPDATE_QUOTATION':
      return { ...state, quotations: state.quotations.map(q => q.id === action.payload.id ? action.payload : q) };
    case 'UPDATE_APPROVAL':
      return { ...state, approvals: state.approvals.map(a => a.id === action.payload.id ? action.payload : a) };
    case 'ADD_APPROVAL':
      return { ...state, approvals: [...state.approvals, action.payload] };
    case 'ADD_PO':
      return { ...state, purchaseOrders: [...state.purchaseOrders, action.payload] };
    case 'UPDATE_PO':
      return { ...state, purchaseOrders: state.purchaseOrders.map(p => p.id === action.payload.id ? action.payload : p) };
    case 'ADD_INVOICE':
      return { ...state, invoices: [...state.invoices, action.payload] };
    case 'UPDATE_INVOICE':
      return { ...state, invoices: state.invoices.map(i => i.id === action.payload.id ? action.payload : i) };
    case 'ADD_LOG':
      return { ...state, auditLogs: [action.payload, ...state.auditLogs] };
    case 'ADD_TOAST':
      return { ...state, toasts: [...state.toasts, action.payload] };
    case 'REMOVE_TOAST':
      return { ...state, toasts: state.toasts.filter(t => t.id !== action.payload) };
    default:
      return state;
  }
}

export function AppDataProvider({ children }) {
  const [state, dispatch] = useReducer(reducer, initialState);
  const [exchangeRate, setExchangeRateLocal] = useState(83.0);

  // Fetch exchange rate
  useEffect(() => {
    fetch('https://api.exchangerate-api.com/v4/latest/USD')
      .then(res => res.json())
      .then(data => {
        if (data?.rates?.INR) {
          setExchangeRateLocal(data.rates.INR);
          setExchangeRate(data.rates.INR);
        }
      })
      .catch(() => {
        // Use fallback rate
        setExchangeRate(83.0);
      });
  }, []);

  // Fetch all data from backend on mount
  useEffect(() => {
    const token = localStorage.getItem('vb_token');
    if (!token) {
      dispatch({ type: 'SET_DATA', payload: { loading: false } });
      return;
    }

    const fetchAll = async () => {
      try {
        const [vendors, rfqs, quotations, approvals, purchaseOrders, invoices, auditLogs] = await Promise.all([
          api.getVendors(),
          api.getRfqs(),
          api.getQuotations(),
          api.getApprovals(),
          api.getPurchaseOrders(),
          api.getInvoices(),
          api.getAuditLogs(),
        ]);
        dispatch({ type: 'SET_DATA', payload: { vendors, rfqs, quotations, approvals, purchaseOrders, invoices, auditLogs } });
      } catch (err) {
        console.error('Failed to fetch data:', err);
        dispatch({ type: 'SET_DATA', payload: { loading: false } });
      }
    };
    fetchAll();
  }, []);

  const addToast = (message, type = 'success') => {
    const id = Date.now();
    dispatch({ type: 'ADD_TOAST', payload: { id, message, type } });
    setTimeout(() => dispatch({ type: 'REMOVE_TOAST', payload: id }), 4000);
  };

  const addLog = async (userId, userName, action, entityType, entityId, entityTitle) => {
    const log = { userId, userName, action, entityType, entityId, entityTitle };
    try {
      await api.createAuditLog(log);
    } catch { /* silent fail for logging */ }
    dispatch({ type: 'ADD_LOG', payload: { id: `al${Date.now()}`, ...log, timestamp: new Date().toISOString(), ipAddress: '0.0.0.0' } });
  };

  const createPOFromQuotation = async (quotation, rfq, vendor) => {
    const lineItems = quotation.unitPrices.map(up => ({
      description: up.product,
      quantity: up.quantity,
      unitPrice: up.unitPrice,
      amount: up.quantity * up.unitPrice,
    }));
    const subtotal = lineItems.reduce((s, i) => s + i.amount, 0);
    const poData = {
      poNumber: generatePONumber(),
      rfqId: rfq.id,
      quotationId: quotation.id,
      vendorId: vendor.id,
      vendorName: vendor.name,
      lineItems,
      subtotal,
      cgst: Math.round(subtotal * 0.09),
      sgst: Math.round(subtotal * 0.09),
      igst: 0,
      total: Math.round(subtotal * 1.18),
      status: 'confirmed',
      deliveryDate: new Date(Date.now() + quotation.deliveryDays * 86400000).toISOString().split('T')[0],
      terms: 'Net 30',
    };
    try {
      const po = await api.createPurchaseOrder(poData);
      dispatch({ type: 'ADD_PO', payload: po });
      return po;
    } catch (err) {
      addToast(err.message, 'error');
      return null;
    }
  };

  const createInvoiceFromPO = async (po) => {
    const invData = {
      invoiceNumber: generateInvoiceNumber(),
      poId: po.id,
      poNumber: po.poNumber,
      vendorId: po.vendorId,
      vendorName: po.vendorName,
      lineItems: po.lineItems,
      subtotal: po.subtotal,
      cgst: po.cgst,
      sgst: po.sgst,
      igst: po.igst,
      total: po.total,
      status: 'pending',
      dueDate: new Date(Date.now() + 30 * 86400000).toISOString().split('T')[0],
    };
    try {
      const inv = await api.createInvoice(invData);
      dispatch({ type: 'ADD_INVOICE', payload: inv });
      return inv;
    } catch (err) {
      addToast(err.message, 'error');
      return null;
    }
  };

  // Refresh helpers for components that need to re-fetch after mutations
  const refreshVendors = async () => {
    try {
      const vendors = await api.getVendors();
      dispatch({ type: 'SET_VENDORS', payload: vendors });
    } catch { /* ignore */ }
  };

  const refreshRfqs = async () => {
    try {
      const rfqs = await api.getRfqs();
      dispatch({ type: 'SET_RFQS', payload: rfqs });
    } catch { /* ignore */ }
  };

  // ── Mutators ──
  const createVendor = async (data) => {
    try {
      const v = await api.createVendor(data);
      dispatch({ type: 'ADD_VENDOR', payload: v });
      return v;
    } catch (err) { addToast(err.message, 'error'); return null; }
  };
  const updateVendor = async (id, data) => {
    try {
      const v = await api.updateVendor(id, data);
      dispatch({ type: 'UPDATE_VENDOR', payload: v });
      return v;
    } catch (err) { addToast(err.message, 'error'); return null; }
  };

  const createRfq = async (data) => {
    try {
      const r = await api.createRfq(data);
      dispatch({ type: 'ADD_RFQ', payload: r });
      return r;
    } catch (err) { addToast(err.message, 'error'); return null; }
  };
  const updateRfq = async (id, data) => {
    try {
      const r = await api.updateRfq(id, data);
      dispatch({ type: 'UPDATE_RFQ', payload: r });
      return r;
    } catch (err) { addToast(err.message, 'error'); return null; }
  };

  const createQuotation = async (data) => {
    try {
      const q = await api.createQuotation(data);
      dispatch({ type: 'ADD_QUOTATION', payload: q });
      return q;
    } catch (err) { addToast(err.message, 'error'); return null; }
  };
  const updateQuotation = async (id, data) => {
    try {
      const q = await api.updateQuotation(id, data);
      dispatch({ type: 'UPDATE_QUOTATION', payload: q });
      return q;
    } catch (err) { addToast(err.message, 'error'); return null; }
  };

  const createApproval = async (data) => {
    try {
      const a = await api.createApproval(data);
      dispatch({ type: 'ADD_APPROVAL', payload: a });
      return a;
    } catch (err) { addToast(err.message, 'error'); return null; }
  };
  const updateApproval = async (id, data) => {
    try {
      const a = await api.updateApproval(id, data);
      dispatch({ type: 'UPDATE_APPROVAL', payload: a });
      return a;
    } catch (err) { addToast(err.message, 'error'); return null; }
  };

  const updatePO = async (id, data) => {
    try {
      const po = await api.updatePurchaseOrder(id, data);
      dispatch({ type: 'UPDATE_PO', payload: po });
      return po;
    } catch (err) { addToast(err.message, 'error'); return null; }
  };

  const updateInvoice = async (id, data) => {
    try {
      const inv = await api.updateInvoice(id, data);
      dispatch({ type: 'UPDATE_INVOICE', payload: inv });
      return inv;
    } catch (err) { addToast(err.message, 'error'); return null; }
  };

  return (
    <AppDataContext.Provider value={{
      ...state,
      exchangeRate,
      dispatch,
      addToast,
      addLog,
      createPOFromQuotation,
      createInvoiceFromPO,
      refreshVendors,
      refreshRfqs,
      createVendor, updateVendor,
      createRfq, updateRfq,
      createQuotation, updateQuotation,
      createApproval, updateApproval,
      updatePO, updateInvoice
    }}>
      {children}
    </AppDataContext.Provider>
  );
}

export const useAppData = () => useContext(AppDataContext);
