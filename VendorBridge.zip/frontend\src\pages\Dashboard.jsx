import { useNavigate, Link } from 'react-router-dom';
import { useAppData } from '../context/AppDataContext';
import { useAuth } from '../context/AuthContext';
import KPICard from '../components/KPICard';
import Badge from '../components/Badge';
import { formatCurrency, formatDate } from '../utils/helpers';
import {
  ClipboardList, Building2, FileText, ShoppingCart,
  CheckCircle, XCircle, Clock, ArrowRight
} from 'lucide-react';

export default function Dashboard() {
  const { vendors, rfqs, approvals, purchaseOrders, addToast, addLog, createPOFromQuotation, updateApproval, quotations } = useAppData();
  const { currentUser } = useAuth();
  const navigate = useNavigate();

  const pendingApprovals = approvals.filter(a => a.status === 'pending');
  const activeRFQs = rfqs.filter(r => r.status === 'active');
  const activeVendors = vendors.filter(v => v.status === 'active');
  const totalSpend = purchaseOrders.reduce((s, p) => s + p.total, 0);

  const handleQuickApprove = async (approval) => {
    const updated = {
      ...approval,
      status: 'approved',
      remarks: 'Quick approved from dashboard',
      resolvedAt: new Date().toISOString().split('T')[0],
      resolvedBy: currentUser.id,
    };
    await updateApproval(approval.id, updated);
    addLog(currentUser.id, currentUser.name, 'Approved', 'Approval', approval.id, approval.refTitle);

    if (approval.type === 'Quotation' || approval.type === 'Quotation Acceptance') {
      const quote = quotations.find(q => q.id === approval.refId);
      const rfq = quote ? rfqs.find(r => r.id === quote.rfqId) : null;
      const vendor = quote ? vendors.find(v => v.id === quote.vendorId) : null;
      if (quote && rfq && vendor) {
        const po = await createPOFromQuotation(quote, rfq, vendor);
        if (po) addToast(`Approved! Purchase Order ${po.poNumber} generated automatically.`);
        else addToast('Approval granted successfully.');
      } else {
        addToast('Approval granted successfully.');
      }
    } else {
      addToast('Approval granted successfully.');
    }
  };

  const handleQuickReject = async (approval) => {
    const updated = {
      ...approval,
      status: 'rejected',
      remarks: 'Quick rejected from dashboard',
      resolvedAt: new Date().toISOString().split('T')[0],
      resolvedBy: currentUser.id,
    };
    await updateApproval(approval.id, updated);
    addLog(currentUser.id, currentUser.name, 'Rejected', 'Approval', approval.id, approval.refTitle);
    addToast('Approval rejected.', 'error');
  };

  return (
    <div className="animate-fade">
      {/* Welcome Banner */}
      <div className="card-glass mb-6" style={{ padding: '24px 28px', marginBottom: 28, background: 'linear-gradient(135deg, rgba(99,102,241,0.12), rgba(6,182,212,0.08))', borderColor: 'rgba(99,102,241,0.25)' }}>
        <div className="flex items-center justify-between">
          <div>
            <h2 style={{ fontSize: 20, fontWeight: 700, marginBottom: 4 }}>
              Good morning, {currentUser?.name?.split(' ')[0]} 👋
            </h2>
            <p style={{ color: 'var(--text-muted)', fontSize: 14 }}>
              You have <strong style={{ color: 'var(--warning)' }}>{pendingApprovals.length} pending approvals</strong> and <strong style={{ color: 'var(--cyan)' }}>{activeRFQs.length} active RFQs</strong> today.
            </p>
          </div>
          {(currentUser.role === 'admin' || currentUser.role === 'procurement') && (
            <button className="btn btn-primary" onClick={() => navigate('/rfq/create')}>
              <FileText size={16} /> New RFQ
            </button>
          )}
        </div>
      </div>

      {/* KPI Cards */}
      <div className="kpi-grid" style={{ marginBottom: 28 }}>
        <KPICard
          title="Total Spend"
          value={formatCurrency(totalSpend)}
          change="Accrued PO Spend"
          changeType="up"
          icon={<ShoppingCart size={22} />}
          accent="#6366f1"
          bg="rgba(99,102,241,0.1)"
        />
        <KPICard
          title="Active Vendors"
          value={activeVendors.length}
          change="Registered partners"
          changeType="up"
          icon={<Building2 size={22} />}
          accent="#10b981"
          bg="rgba(16,185,129,0.1)"
        />
        <KPICard
          title="Pending Approvals"
          value={pendingApprovals.length}
          change="Action required"
          changeType="up"
          icon={<ClipboardList size={22} />}
          accent="#f59e0b"
          bg="rgba(245,158,11,0.1)"
        />
        <KPICard
          title="Active RFQs"
          value={activeRFQs.length}
          change="Open for quotation"
          changeType="up"
          icon={<FileText size={22} />}
          accent="#06b6d4"
          bg="rgba(6,182,212,0.1)"
        />
      </div>

      {/* Pending Approvals Section */}
      <div className="card mb-6" style={{ marginBottom: 28 }}>
        <div className="card-header" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 }}>
          <div>
            <div className="card-title">Pending Approvals</div>
            <div className="card-subtitle">Review and resolve active workflows</div>
          </div>
          <Link to="/approvals" style={{ display: 'flex', alignItems: 'center', gap: 4, fontSize: 13, color: 'var(--accent-light)' }}>
            View all <ArrowRight size={13} />
          </Link>
        </div>

        {pendingApprovals.length === 0 ? (
          <div className="empty-state" style={{ padding: '30px 0' }}>
            <CheckCircle size={32} style={{ margin: '0 auto 8px', color: 'var(--success)', opacity: 0.5 }} />
            <p>All caught up! No pending approvals.</p>
          </div>
        ) : (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
            {pendingApprovals.map(ap => (
              <div key={ap.id} style={{ display: 'flex', alignItems: 'center', gap: 16, padding: '14px 18px', background: 'var(--bg-elevated)', borderRadius: 10, border: '1px solid var(--border)' }}>
                <div style={{ width: 38, height: 38, borderRadius: 8, background: 'var(--warning-bg)', color: 'var(--warning)', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                  <Clock size={18} />
                </div>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ fontSize: 14, fontWeight: 700, color: 'var(--text-primary)', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{ap.refTitle}</div>
                  <div style={{ fontSize: 12, color: 'var(--text-muted)' }}>{ap.type} · Requested by {ap.requestedByName}</div>
                </div>
                {ap.amount > 0 && (
                  <div style={{ fontSize: 14, fontWeight: 800, color: 'var(--text-primary)', marginRight: 12 }}>
                    {formatCurrency(ap.amount)}
                  </div>
                )}
                {currentUser.role === 'admin' && (
                  <div style={{ display: 'flex', gap: 8 }} className="no-print">
                    <button className="btn btn-sm btn-success" onClick={() => handleQuickApprove(ap)} style={{ padding: '6px 12px' }}>
                      <CheckCircle size={14} style={{ marginRight: 4 }} /> Approve
                    </button>
                    <button className="btn btn-sm btn-danger" onClick={() => handleQuickReject(ap)} style={{ padding: '6px 12px' }}>
                      <XCircle size={14} style={{ marginRight: 4 }} /> Reject
                    </button>
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Side-by-Side Data Tables */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 24 }}>
        {/* Active RFQs Table */}
        <div className="card">
          <div className="card-header" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
            <div className="card-title">Active RFQs</div>
            <Link to="/rfq" style={{ display: 'flex', alignItems: 'center', gap: 4, fontSize: 13, color: 'var(--accent-light)' }}>
              All RFQs <ArrowRight size={13} />
            </Link>
          </div>
          <div className="table-wrap">
            <table style={{ width: '100%', borderCollapse: 'collapse' }}>
              <thead>
                <tr style={{ textAlign: 'left', borderBottom: '1px solid var(--border)' }}>
                  <th style={{ padding: '12px 8px', fontSize: 12, color: 'var(--text-muted)', fontWeight: 600 }}>Title</th>
                  <th style={{ padding: '12px 8px', fontSize: 12, color: 'var(--text-muted)', fontWeight: 600 }}>Deadline</th>
                  <th style={{ padding: '12px 8px', fontSize: 12, color: 'var(--text-muted)', fontWeight: 600 }}>Status</th>
                </tr>
              </thead>
              <tbody>
                {activeRFQs.slice(0, 5).map(rfq => (
                  <tr key={rfq.id} style={{ borderBottom: '1px solid var(--border)', cursor: 'pointer' }} onClick={() => navigate(`/rfq/${rfq.id}`)}>
                    <td style={{ padding: '12px 8px', fontSize: 13, fontWeight: 600, color: 'var(--text-primary)' }}>{rfq.title}</td>
                    <td style={{ padding: '12px 8px', fontSize: 13, color: 'var(--text-secondary)' }}>{formatDate(rfq.deadline)}</td>
                    <td style={{ padding: '12px 8px' }}><Badge status={rfq.status} /></td>
                  </tr>
                ))}
                {activeRFQs.length === 0 && (
                  <tr>
                    <td colSpan="3" style={{ textAlign: 'center', padding: 20, color: 'var(--text-muted)', fontSize: 13 }}>No active RFQs.</td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>

        {/* Recent Purchase Orders Table */}
        <div className="card">
          <div className="card-header" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
            <div className="card-title">Recent Purchase Orders</div>
            <Link to="/purchase-orders" style={{ display: 'flex', alignItems: 'center', gap: 4, fontSize: 13, color: 'var(--accent-light)' }}>
              All POs <ArrowRight size={13} />
            </Link>
          </div>
          <div className="table-wrap">
            <table style={{ width: '100%', borderCollapse: 'collapse' }}>
              <thead>
                <tr style={{ textAlign: 'left', borderBottom: '1px solid var(--border)' }}>
                  <th style={{ padding: '12px 8px', fontSize: 12, color: 'var(--text-muted)', fontWeight: 600 }}>PO Number</th>
                  <th style={{ padding: '12px 8px', fontSize: 12, color: 'var(--text-muted)', fontWeight: 600 }}>Vendor</th>
                  <th style={{ padding: '12px 8px', fontSize: 12, color: 'var(--text-muted)', fontWeight: 600 }}>Total</th>
                  <th style={{ padding: '12px 8px', fontSize: 12, color: 'var(--text-muted)', fontWeight: 600 }}>Status</th>
                </tr>
              </thead>
              <tbody>
                {purchaseOrders.slice(0, 5).map(po => (
                  <tr key={po.id} style={{ borderBottom: '1px solid var(--border)', cursor: 'pointer' }} onClick={() => navigate(`/purchase-orders/${po.id}`)}>
                    <td style={{ padding: '12px 8px', fontSize: 13, fontWeight: 700, color: 'var(--accent-light)', fontFamily: 'monospace' }}>{po.poNumber}</td>
                    <td style={{ padding: '12px 8px', fontSize: 13, color: 'var(--text-secondary)' }}>{po.vendorName}</td>
                    <td style={{ padding: '12px 8px', fontSize: 13, fontWeight: 600, color: 'var(--text-primary)' }}>{formatCurrency(po.total)}</td>
                    <td style={{ padding: '12px 8px' }}><Badge status={po.status} /></td>
                  </tr>
                ))}
                {purchaseOrders.length === 0 && (
                  <tr>
                    <td colSpan="4" style={{ textAlign: 'center', padding: 20, color: 'var(--text-muted)', fontSize: 13 }}>No purchase orders.</td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}

