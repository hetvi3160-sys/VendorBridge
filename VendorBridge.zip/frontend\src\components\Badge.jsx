import { getStatusColor } from '../utils/helpers';

export default function Badge({ status, label }) {
  const color = getStatusColor(status);
  return (
    <span className={`badge badge-${color}`}>
      {label || status}
    </span>
  );
}
