import { useState, useRef, useEffect } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { useAppData } from '../context/AppDataContext';
import { Bell, Settings, LogOut, User, ChevronDown, Clock, FileText, CheckCircle } from 'lucide-react';

const pageMeta = {
  '/dashboard': { title: 'Dashboard', subtitle: 'Overview of your procurement operations' },
  '/vendors': { title: 'Vendor Management', subtitle: 'Manage your vendor directory and relationships' },
  '/rfq': { title: 'Request for Quotation', subtitle: 'Create and track procurement requests' },
  '/rfq/create': { title: 'Create RFQ', subtitle: 'Initiate a new procurement request' },
  '/quotations': { title: 'Quotations', subtitle: 'Review and compare vendor quotations' },
  '/approvals': { title: 'Approvals', subtitle: 'Manage pending approval workflows' },
  '/purchase-orders': { title: 'Purchase Orders', subtitle: 'View and manage all purchase orders' },
  '/invoices': { title: 'Invoices', subtitle: 'Track and manage vendor invoices' },
  '/documents': { title: 'Document Management', subtitle: 'Centralized document hub' },
  '/reports': { title: 'Reports & Analytics', subtitle: 'Insights and vendor performance metrics' },
  '/activity': { title: 'Activity & Notifications', subtitle: 'Real-time alerts and full audit trail' },
  '/users': { title: 'User Management', subtitle: 'Manage user accounts, roles and permissions' },
};

export default function TopBar() {
  const location = useLocation();
  const navigate = useNavigate();
  const { currentUser, logout } = useAuth();
  const { approvals, invoices, rfqs } = useAppData();
  const [showNotifs, setShowNotifs] = useState(false);
  const [showUser, setShowUser] = useState(false);
  const notifsRef = useRef(null);
  const userRef = useRef(null);

  const pathKey = Object.keys(pageMeta).find(k => location.pathname === k || location.pathname.startsWith(k + '/'));
  const meta = pageMeta[pathKey] || { title: 'VendorBridge', subtitle: '' };

  // Build notification items
  const pendingApprovals = approvals.filter(a => a.status === 'pending');
  const pendingInvoices = invoices.filter(i => i.status === 'pending');
  const activeRFQs = rfqs.filter(r => r.status === 'active');

  const notifications = [
    ...pendingApprovals.slice(0, 3).map(a => ({
      id: `ap-${a.id}`, icon: <Clock size={14} />, color: 'var(--warning)',
      text: `Pending approval: ${a.refTitle}`,
      action: () => navigate('/approvals'),
    })),
    ...pendingInvoices.slice(0, 2).map(i => ({
      id: `inv-${i.id}`, icon: <FileText size={14} />, color: 'var(--accent-light)',
      text: `Invoice pending: ${i.invoiceNumber}`,
      action: () => navigate(`/invoices/${i.id}`),
    })),
    ...activeRFQs.slice(0, 2).map(r => ({
      id: `rfq-${r.id}`, icon: <CheckCircle size={14} />, color: 'var(--cyan)',
      text: `Active RFQ: ${r.rfqNumber}`,
      action: () => navigate(`/rfq/${r.id}`),
    })),
  ];

  const unreadCount = notifications.length;

  // Close dropdowns on outside click
  useEffect(() => {
    const handler = (e) => {
      if (notifsRef.current && !notifsRef.current.contains(e.target)) setShowNotifs(false);
      if (userRef.current && !userRef.current.contains(e.target)) setShowUser(false);
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, []);

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  const roleColors = {
    admin: { bg: 'rgba(99,102,241,0.15)', color: 'var(--accent-light)' },
    procurement: { bg: 'rgba(6,182,212,0.15)', color: 'var(--cyan)' },
    vendor: { bg: 'rgba(16,185,129,0.15)', color: 'var(--success)' },
  };
  const roleMeta = roleColors[currentUser?.role] || roleColors.admin;

  return (
    <header className="topbar">
      <div>
        <div className="topbar-title">{meta.title}</div>
        {meta.subtitle && <div className="topbar-subtitle">{meta.subtitle}</div>}
      </div>

      <div className="topbar-actions">
        {/* Notifications Bell */}
        <div style={{ position: 'relative' }} ref={notifsRef}>
          <button
            className="topbar-btn"
            onClick={() => { setShowNotifs(v => !v); setShowUser(false); }}
            style={{ position: 'relative' }}
          >
            <Bell size={17} />
          </button>
          {unreadCount > 0 && (
            <span className="notification-dot" style={{ top: 6, right: 6 }}>{unreadCount > 9 ? '9+' : unreadCount}</span>
          )}

          {showNotifs && (
            <div style={{
              position: 'absolute', top: '110%', right: 0, width: 320, zIndex: 200,
              background: 'var(--bg-card)', border: '1px solid var(--border)', borderRadius: 14,
              boxShadow: '0 16px 40px rgba(0,0,0,0.5)',
            }}>
              <div style={{ padding: '14px 16px', borderBottom: '1px solid var(--border)', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <span style={{ fontWeight: 700, fontSize: 14 }}>Notifications</span>
                <span style={{ fontSize: 12, color: 'var(--warning)', fontWeight: 600 }}>{unreadCount} new</span>
              </div>
              <div style={{ maxHeight: 320, overflowY: 'auto' }}>
                {notifications.length === 0 ? (
                  <div style={{ padding: '24px 16px', textAlign: 'center', color: 'var(--text-muted)', fontSize: 13 }}>
                    All caught up! 🎉
                  </div>
                ) : (
                  notifications.map(n => (
                    <div key={n.id}
                      onClick={() => { n.action(); setShowNotifs(false); }}
                      style={{ display: 'flex', alignItems: 'flex-start', gap: 12, padding: '12px 16px', cursor: 'pointer', borderBottom: '1px solid var(--border)', transition: 'var(--transition)' }}
                      onMouseEnter={e => e.currentTarget.style.background = 'var(--bg-elevated)'}
                      onMouseLeave={e => e.currentTarget.style.background = 'transparent'}
                    >
                      <div style={{ width: 28, height: 28, borderRadius: 8, background: `${n.color}20`, color: n.color, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0, marginTop: 1 }}>
                        {n.icon}
                      </div>
                      <div style={{ flex: 1, fontSize: 13, color: 'var(--text-primary)', lineHeight: 1.5 }}>{n.text}</div>
                    </div>
                  ))
                )}
              </div>
              <div style={{ padding: '10px 16px', borderTop: '1px solid var(--border)' }}>
                <button onClick={() => { navigate('/reports'); setShowNotifs(false); }}
                  style={{ width: '100%', fontSize: 13, color: 'var(--accent-light)', background: 'none', border: 'none', cursor: 'pointer', textAlign: 'center', fontWeight: 600 }}>
                  View Activity Log →
                </button>
              </div>
            </div>
          )}
        </div>

        {/* User Profile Dropdown */}
        <div style={{ position: 'relative' }} ref={userRef}>
          <div
            onClick={() => { setShowUser(v => !v); setShowNotifs(false); }}
            style={{ display: 'flex', alignItems: 'center', gap: 8, cursor: 'pointer', padding: '6px 10px', borderRadius: 10, border: '1px solid var(--border)', background: 'var(--bg-elevated)', transition: 'var(--transition)' }}
            onMouseEnter={e => e.currentTarget.style.borderColor = 'var(--accent)'}
            onMouseLeave={e => e.currentTarget.style.borderColor = 'var(--border)'}
          >
            <div className="user-avatar" style={{ width: 30, height: 30, fontSize: 12 }}>
              {currentUser?.avatar || '??'}
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', lineHeight: 1.3 }}>
              <span style={{ fontSize: 13, fontWeight: 700, color: 'var(--text-primary)' }}>{currentUser?.name?.split(' ')[0]}</span>
              <span style={{ fontSize: 11, color: 'var(--text-muted)', textTransform: 'capitalize' }}>{currentUser?.role}</span>
            </div>
            <ChevronDown size={14} style={{ color: 'var(--text-muted)', transition: 'transform 0.2s', transform: showUser ? 'rotate(180deg)' : 'none' }} />
          </div>

          {showUser && (
            <div style={{
              position: 'absolute', top: '110%', right: 0, width: 220, zIndex: 200,
              background: 'var(--bg-card)', border: '1px solid var(--border)', borderRadius: 14,
              boxShadow: '0 16px 40px rgba(0,0,0,0.5)',
            }}>
              <div style={{ padding: '14px 16px', borderBottom: '1px solid var(--border)' }}>
                <div style={{ fontWeight: 700, fontSize: 14, color: 'var(--text-primary)' }}>{currentUser?.name}</div>
                <div style={{ fontSize: 12, color: 'var(--text-muted)', marginTop: 2 }}>{currentUser?.email}</div>
                <div style={{ marginTop: 8, display: 'inline-flex', padding: '3px 10px', borderRadius: 20, fontSize: 11, fontWeight: 700, textTransform: 'capitalize', ...roleMeta }}>
                  {currentUser?.role}
                </div>
              </div>
              <div style={{ padding: 8 }}>
                <button
                  onClick={handleLogout}
                  style={{ width: '100%', display: 'flex', alignItems: 'center', gap: 10, padding: '9px 12px', borderRadius: 8, fontSize: 13, color: 'var(--danger)', background: 'none', border: 'none', cursor: 'pointer', fontWeight: 600, transition: 'var(--transition)' }}
                  onMouseEnter={e => e.currentTarget.style.background = 'var(--danger-bg)'}
                  onMouseLeave={e => e.currentTarget.style.background = 'transparent'}
                >
                  <LogOut size={14} /> Sign Out
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </header>
  );
}
