import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './context/AuthContext';
import { AppDataProvider } from './context/AppDataContext';
import Sidebar from './components/Sidebar';
import TopBar from './components/TopBar';
import Toast from './components/Toast';
import Login from './pages/Login';
import Signup from './pages/Signup';
import Dashboard from './pages/Dashboard';
import VendorList from './pages/Vendors/VendorList';
import VendorDetail from './pages/Vendors/VendorDetail';
import RFQList from './pages/RFQ/RFQList';
import RFQCreate from './pages/RFQ/RFQCreate';
import RFQDetail from './pages/RFQ/RFQDetail';
import QuotationList from './pages/Quotations/QuotationList';
import QuotationCompare from './pages/Quotations/QuotationCompare';
import Approvals from './pages/Approvals';
import POList from './pages/PurchaseOrders/POList';
import PODetail from './pages/PurchaseOrders/PODetail';
import InvoiceList from './pages/Invoices/InvoiceList';
import InvoiceDetail from './pages/Invoices/InvoiceDetail';
import Documents from './pages/Documents';
import Reports from './pages/Reports';
import ActivityLogs from './pages/ActivityLogs';
import UserManagement from './pages/UserManagement';

function PrivateRoute({ children }) {
  const { currentUser } = useAuth();
  return currentUser ? children : <Navigate to="/login" replace />;
}

function AppLayout({ children }) {
  return (
    <div className="app-layout">
      <Sidebar />
      <div className="main-content">
        <TopBar />
        <div className="page-content">
          {children}
        </div>
      </div>
      <Toast />
    </div>
  );
}

function App() {
  return (
    <BrowserRouter>
      <AuthProvider>
        <AppDataProvider>
          <Routes>
            <Route path="/login" element={<Login />} />
            <Route path="/signup" element={<Signup />} />
            <Route path="/" element={<Navigate to="/dashboard" replace />} />
            <Route path="/dashboard" element={<PrivateRoute><AppLayout><Dashboard /></AppLayout></PrivateRoute>} />
            <Route path="/vendors" element={<PrivateRoute><AppLayout><VendorList /></AppLayout></PrivateRoute>} />
            <Route path="/vendors/:id" element={<PrivateRoute><AppLayout><VendorDetail /></AppLayout></PrivateRoute>} />
            <Route path="/rfq" element={<PrivateRoute><AppLayout><RFQList /></AppLayout></PrivateRoute>} />
            <Route path="/rfq/create" element={<PrivateRoute><AppLayout><RFQCreate /></AppLayout></PrivateRoute>} />
            <Route path="/rfq/:id" element={<PrivateRoute><AppLayout><RFQDetail /></AppLayout></PrivateRoute>} />
            <Route path="/quotations" element={<PrivateRoute><AppLayout><QuotationList /></AppLayout></PrivateRoute>} />
            <Route path="/quotations/compare/:rfqId" element={<PrivateRoute><AppLayout><QuotationCompare /></AppLayout></PrivateRoute>} />
            <Route path="/approvals" element={<PrivateRoute><AppLayout><Approvals /></AppLayout></PrivateRoute>} />
            <Route path="/purchase-orders" element={<PrivateRoute><AppLayout><POList /></AppLayout></PrivateRoute>} />
            <Route path="/purchase-orders/:id" element={<PrivateRoute><AppLayout><PODetail /></AppLayout></PrivateRoute>} />
            <Route path="/invoices" element={<PrivateRoute><AppLayout><InvoiceList /></AppLayout></PrivateRoute>} />
            <Route path="/invoices/:id" element={<PrivateRoute><AppLayout><InvoiceDetail /></AppLayout></PrivateRoute>} />
            <Route path="/documents" element={<PrivateRoute><AppLayout><Documents /></AppLayout></PrivateRoute>} />
            <Route path="/reports" element={<PrivateRoute><AppLayout><Reports /></AppLayout></PrivateRoute>} />
            <Route path="/activity" element={<PrivateRoute><AppLayout><ActivityLogs /></AppLayout></PrivateRoute>} />
            <Route path="/users" element={<PrivateRoute><AppLayout><UserManagement /></AppLayout></PrivateRoute>} />
            <Route path="*" element={<Navigate to="/dashboard" replace />} />
          </Routes>
        </AppDataProvider>
      </AuthProvider>
    </BrowserRouter>
  );
}

export default App;
