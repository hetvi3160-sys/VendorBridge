import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAppData } from '../context/AppDataContext';
import { formatDate, formatDateTime, timeAgo } from '../utils/helpers';
import Badge from '../components/Badge';
import { formatCurrency } from '../utils/helpers';
import {
  Bell, Clock, CheckCircle, XCircle, AlertCircle,
  FileText, ShoppingCart, Building2, Search, Filter,
  ArrowRight, Package
} from 'lucide-react';

const TYPE_META = {
  'RFQ': { icon: <FileText size={14} />, color: 'var(--accent-light)', bg: 'var(--accent-glow)' },
  'Quotation': { icon: <Package size={14} />, color: 'var(--cyan)', bg: 'rgba(6,182,212,0.12)' },
  'Approval': { icon: <CheckCircle size={14} />, color: 'var(--success)', bg: 'var(--success-bg)' },
  'PurchaseOrder': { icon: <ShoppingCart size={14} />, color: 'var(--warning)', bg: 'var(--warning-bg)' },
  'Invoice': { icon: <FileText size={14} />, color: 'var(--danger)', bg: 'var(--danger-bg)' },
  'Vendor': { icon: <Building2 size={14} />, color: '#a78bfa', bg: 'rgba(167,139,250,0.1)' },
};

export default function ActivityLogs() {
  const { auditLogs, approvals, rfqs, invoices, purchaseOrders } = useAppData();
  const navigate = useNavigate();
  const [search, setSearch] = useState('');
  const [typeFilter, setTypeFilter] = useState('all');
  const [tab, setTab] = useState('logs'); // 'logs' | 'notifications'

  const filtered = auditLogs.filter(log => {
    const matchSearch = log.userName.toLowerCase().includes(search.toLowerCase()) ||
      log.action.toLowerCase().includes(search.toLowerCase()) ||
      log.entityTitle.toLowerCase().includes(search.toLowerCase());
    const matchType = typeFilter === 'all' || log.entityType === typeFilter;
    return matchSearch && matchType;
  });

  // Build notifications list
  const pendingApprovals = approvals.filter(a => a.status === 'pending');
  const pendingInvoices = invoices.filter(i => i.status === 'pending');
  const activeRFQs = rfqs.filter(r => r.status === 'active');
  const confirmedPOs = purchaseOrders.filter(p => p.status === 'confirmed');

  const notifications = [
    ...pendingApprovals.map(a => ({
      id: `ap-${a.id}`, type: 'approval', icon: <Clock size={16} />,
      color: 'var(--warning)', bg: 'var(--warning-bg)',
      title: `Approval Pending: ${a.refTitle}`,
      detail: `${a.type} · ${a.requestedByName} · ${formatDate(a.createdAt)}`,
      amount: a.amount > 0 ? formatCurrency(a.amount) : null,
      action: () => navigate('/approvals'),
      badge: 'pending',
    })),
    ...pendingInvoices.map(i => ({
      id: `inv-${i.id}`, type: 'invoice', icon: <FileText size={16} />,
      color: 'var(--danger)', bg: 'var(--danger-bg)',
      title: `Invoice Due: ${i.invoiceNumber}`,
      detail: `${i.vendorName} · Due ${formatDate(i.dueDate)}`,
      amount: formatCurrency(i.total),
      action: () => navigate(`/invoices/${i.id}`),
      badge: 'pending',
    })),
    ...activeRFQs.map(r => ({
      id: `rfq-${r.id}`, type: 'rfq', icon: <AlertCircle size={16} />,
      color: 'var(--accent-light)', bg: 'var(--accent-glow)',
      title: `Active RFQ: ${r.rfqNumber}`,
      detail: `${r.title} · Deadline ${formatDate(r.deadline)}`,
      amount: r.budget ? formatCurrency(r.budget) : null,
      action: () => navigate(`/rfq/${r.id}`),
      badge: 'active',
    })),
    ...confirmedPOs.map(p => ({
      id: `po-${p.id}`, type: 'po', icon: <ShoppingCart size={16} />,
      color: 'var(--cyan)', bg: 'rgba(6,182,212,0.12)',
      title: `Purchase Order Confirmed: ${p.poNumber}`,
      detail: `${p.vendorName} · Delivery ${formatDate(p.deliveryDate)}`,
      amount: formatCurrency(p.total),
      action: () => navigate(`/purchase-orders/${p.id}`),
      badge: 'confirmed',
    })),
  ];

  const entityTypes = ['all', 'RFQ', 'Quotation', 'Approval', 'PurchaseOrder', 'Invoice', 'Vendor'];

  return (
    <div className="animate-fade">
      <div className="page-header">
        <div>
          <h1 className="page-title">Activity Logs & Notifications</h1>
          <p className="page-subtitle">Real-time alerts, audit trails, and procurement updates</p>
        </div>
      </div>

      {/* Summary Cards */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: 16, marginBottom: 28 }}>
        {[
          { label: 'Pending Approvals', value: pendingApprovals.length, color: 'var(--warning)', bg: 'var(--warning-bg)', icon: <Clock size={20} />, action: () => navigate('/approvals') },
          { label: 'Active RFQs', value: activeRFQs.length, color: 'var(--accent-light)', bg: 'var(--accent-glow)', icon: <FileText size={20} />, action: () => navigate('/rfq') },
          { label: 'Pending Invoices', value: pendingInvoices.length, color: 'var(--danger)', bg: 'var(--danger-bg)', icon: <AlertCircle size={20} />, action: () => navigate('/invoices') },
          { label: 'Confirmed POs', value: confirmedPOs.length, color: 'var(--cyan)', bg: 'rgba(6,182,212,0.12)', icon: <ShoppingCart size={20} />, action: () => navigate('/purchase-orders') },
        ].map(s => (
          <div key={s.label} className="card" style={{ display: 'flex', alignItems: 'center', gap: 14, cursor: 'pointer', padding: '18px 20px' }}
            onClick={s.action}
            onMouseEnter={e => e.currentTarget.style.transform = 'translateY(-2px)'}
            onMouseLeave={e => e.currentTarget.style.transform = ''}
          >
            <div style={{ width: 44, height: 44, borderRadius: 10, background: s.bg, color: s.color, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              {s.icon}
            </div>
            <div>
              <div style={{ fontSize: 26, fontWeight: 800, color: 'var(--text-primary)', lineHeight: 1 }}>{s.value}</div>
              <div style={{ fontSize: 12, color: 'var(--text-muted)', marginTop: 3 }}>{s.label}</div>
            </div>
            <ArrowRight size={14} style={{ color: 'var(--text-muted)', marginLeft: 'auto' }} />
          </div>
        ))}
      </div>

      {/* Tabs */}
      <div style={{ display: 'flex', gap: 4, marginBottom: 20, background: 'var(--bg-elevated)', borderRadius: 10, padding: 4, border: '1px solid var(--border)', width: 'fit-content' }}>
        {[
          { key: 'notifications', label: `🔔 Notifications (${notifications.length})` },
          { key: 'logs', label: `📋 Audit Log (${auditLogs.length})` },
        ].map(t => (
          <button key={t.key} onClick={() => setTab(t.key)}
            style={{ padding: '8px 20px', borderRadius: 8, fontSize: 13, fontWeight: 700, border: 'none', cursor: 'pointer', transition: 'var(--transition)',
              background: tab === t.key ? 'var(--accent)' : 'transparent',
              color: tab === t.key ? 'white' : 'var(--text-muted)',
              boxShadow: tab === t.key ? '0 4px 12px var(--accent-glow)' : 'none',
            }}
          >
            {t.label}
          </button>
        ))}
      </div>

      {tab === 'notifications' ? (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
          {notifications.length === 0 ? (
            <div className="empty-state">
              <Bell size={40} style={{ margin: '0 auto 12px', opacity: 0.3 }} />
              <h3>All Caught Up!</h3>
              <p>No active notifications at this time.</p>
            </div>
          ) : (
            notifications.map(n => (
              <div key={n.id} className="card"
                style={{ display: 'flex', alignItems: 'center', gap: 16, cursor: 'pointer', transition: 'var(--transition)', padding: '16px 20px' }}
                onClick={n.action}
                onMouseEnter={e => { e.currentTarget.style.borderColor = n.color; e.currentTarget.style.transform = 'translateX(4px)'; }}
                onMouseLeave={e => { e.currentTarget.style.borderColor = 'var(--border)'; e.currentTarget.style.transform = ''; }}
              >
                <div style={{ width: 44, height: 44, borderRadius: 10, background: n.bg, color: n.color, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                  {n.icon}
                </div>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ fontSize: 14, fontWeight: 700, color: 'var(--text-primary)', marginBottom: 3 }}>{n.title}</div>
                  <div style={{ fontSize: 12, color: 'var(--text-muted)' }}>{n.detail}</div>
                </div>
                {n.amount && <div style={{ fontSize: 15, fontWeight: 800, color: 'var(--text-primary)', flexShrink: 0 }}>{n.amount}</div>}
                <Badge status={n.badge} />
                <ArrowRight size={15} style={{ color: 'var(--text-muted)', flexShrink: 0 }} />
              </div>
            ))
          )}
        </div>
      ) : (
        <>
          <div className="search-bar">
            <div className="search-input-wrap" style={{ flex: 2 }}>
              <Search size={16} />
              <input className="search-input" placeholder="Search by user, action, or entity…" value={search} onChange={e => setSearch(e.target.value)} />
            </div>
            <select className="filter-select" value={typeFilter} onChange={e => setTypeFilter(e.target.value)}>
              {entityTypes.map(t => (
                <option key={t} value={t}>{t === 'all' ? 'All Types' : t}</option>
              ))}
            </select>
          </div>

          <div className="card" style={{ padding: 0, overflow: 'hidden' }}>
            <div style={{ padding: '16px 20px', borderBottom: '1px solid var(--border)', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
              <div style={{ fontSize: 14, fontWeight: 700 }}>Audit Trail</div>
              <div style={{ fontSize: 13, color: 'var(--text-muted)' }}>{filtered.length} entries</div>
            </div>
            {filtered.length === 0 ? (
              <div className="empty-state">
                <AlertCircle size={40} style={{ margin: '0 auto 12px', opacity: 0.3 }} />
                <h3>No logs found</h3>
                <p>Try adjusting your search or filters.</p>
              </div>
            ) : (
              <div>
                {filtered.map((log, i) => {
                  const meta = TYPE_META[log.entityType] || { icon: <Bell size={14} />, color: 'var(--text-muted)', bg: 'var(--bg-elevated)' };
                  return (
                    <div key={log.id} style={{ display: 'flex', alignItems: 'center', gap: 14, padding: '14px 20px', borderBottom: i < filtered.length - 1 ? '1px solid var(--border)' : 'none', transition: 'var(--transition)' }}
                      onMouseEnter={e => e.currentTarget.style.background = 'var(--bg-elevated)'}
                      onMouseLeave={e => e.currentTarget.style.background = 'transparent'}
                    >
                      <div style={{ width: 36, height: 36, borderRadius: 8, background: meta.bg, color: meta.color, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                        {meta.icon}
                      </div>
                      <div style={{ width: 36, height: 36, borderRadius: '50%', background: 'var(--bg-elevated)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 12, fontWeight: 700, flexShrink: 0, color: 'var(--accent-light)' }}>
                        {log.userName.slice(0, 2).toUpperCase()}
                      </div>
                      <div style={{ flex: 1 }}>
                        <div style={{ fontSize: 13, color: 'var(--text-primary)' }}>
                          <span style={{ fontWeight: 700 }}>{log.userName}</span>
                          <span style={{ color: 'var(--text-muted)' }}> {log.action} </span>
                          <span style={{ color: meta.color, fontWeight: 600 }}>{log.entityTitle}</span>
                        </div>
                        <div style={{ fontSize: 12, color: 'var(--text-muted)', marginTop: 2 }}>
                          {log.entityType} · IP: {log.ipAddress}
                        </div>
                      </div>
                      <div style={{ textAlign: 'right', flexShrink: 0 }}>
                        <div style={{ fontSize: 12, color: 'var(--text-muted)' }}>{formatDate(log.timestamp)}</div>
                        <div style={{ fontSize: 11, color: 'var(--text-muted)', opacity: 0.7, marginTop: 2 }}>{timeAgo(log.timestamp)}</div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </>
      )}
    </div>
  );
}
