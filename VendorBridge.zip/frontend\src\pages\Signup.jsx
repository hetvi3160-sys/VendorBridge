import { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

export default function Signup() {
  const [form, setForm] = useState({ name: '', email: '', password: '', role: 'procurement' });
  const { signup, error } = useAuth();
  const navigate = useNavigate();

  const handleSubmit = (e) => {
    e.preventDefault();
    if (signup(form.name, form.email, form.password, form.role)) navigate('/dashboard');
  };

  const set = (k) => (e) => setForm(f => ({ ...f, [k]: e.target.value }));

  return (
    <div className="auth-split-container">
      {/* Left side: Graphic */}
      <div className="auth-graphic-side">
        <div className="auth-graphic-pattern" />
        <div className="auth-graphic-content">
          <div className="auth-graphic-title">⬡ VendorBridge</div>
          <p className="auth-graphic-text">
            Join our modern B2B procurement network. Easily register, submit competitive bids, track Purchase Orders, and dispatch invoices in minutes.
          </p>
        </div>
      </div>

      {/* Right side: Form */}
      <div className="auth-form-side">
        <div className="auth-bg-glow auth-bg-glow-1" />
        <div className="auth-bg-glow auth-bg-glow-2" />

        <div className="auth-card">
          <div className="auth-logo">
            <div className="auth-logo-text">⬡ VendorBridge</div>
            <div className="auth-logo-sub">Procurement & Vendor Management ERP</div>
          </div>

          <h1 className="auth-title">Create account</h1>
          <p className="auth-subtitle">Join VendorBridge to streamline your procurement</p>

          <form className="auth-form" onSubmit={handleSubmit}>
            <div className="form-group">
              <label className="form-label">Full Name</label>
              <input className="form-input" type="text" value={form.name} onChange={set('name')} placeholder="Enter your full name" required />
            </div>
            <div className="form-group">
              <label className="form-label">Email Address</label>
              <input className="form-input" type="email" value={form.email} onChange={set('email')} placeholder="Enter your email" required />
            </div>
            <div className="form-group">
              <label className="form-label">Password</label>
              <input className="form-input" type="password" value={form.password} onChange={set('password')} placeholder="Create a password" required />
            </div>
            <div className="form-group">
              <label className="form-label">Role</label>
              <select className="form-input" value={form.role} onChange={set('role')}>
                <option value="admin">Administrator</option>
                <option value="procurement">Procurement Officer</option>
                <option value="vendor">Vendor</option>
              </select>
            </div>

            {error && <p className="form-error" style={{ textAlign: 'center' }}>{error}</p>}

            <button type="submit" className="btn btn-primary w-full" style={{ justifyContent: 'center', marginTop: 4 }}>
              Create Account
            </button>

            <p style={{ textAlign: 'center', fontSize: 13, color: 'var(--text-muted)', marginTop: 8 }}>
              Already have an account? <Link to="/login" className="auth-link">Sign in</Link>
            </p>
          </form>
        </div>
      </div>
    </div>
  );
}
