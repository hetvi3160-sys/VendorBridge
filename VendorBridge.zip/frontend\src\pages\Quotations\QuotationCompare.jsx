import { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useAppData } from '../../context/AppDataContext';
import { useAuth } from '../../context/AuthContext';
import Badge from '../../components/Badge';
import { formatCurrency, formatDate } from '../../utils/helpers';
import { ArrowLeft, CheckCircle, XCircle, Trophy, Truck, DollarSign, Star, ArrowUpDown } from 'lucide-react';

function StarRating({ score }) {
  const stars = Math.round((score / 100) * 5);
  return (
    <div style={{ display: 'flex', gap: 2, alignItems: 'center', justifyContent: 'center' }}>
      {[1,2,3,4,5].map(i => (
        <Star key={i} size={14} style={{ color: i <= stars ? '#f59e0b' : 'var(--border-strong)', fill: i <= stars ? '#f59e0b' : 'transparent' }} />
      ))}
      <span style={{ fontSize: 12, color: 'var(--text-muted)', marginLeft: 4 }}>
        ({score > 0 ? `${score}/100` : 'N/A'})
      </span>
    </div>
  );
}

export default function QuotationCompare() {
  const { rfqId } = useParams();
  const { rfqs, quotations, vendors, addToast, addLog, updateQuotation, createApproval } = useAppData();
  const { currentUser } = useAuth();
  const navigate = useNavigate();
  const [sortBy, setSortBy] = useState('price');

  const rfq = rfqs.find(r => r.id === rfqId);
  const rfqQuotes = quotations.filter(q => q.rfqId === rfqId).map(q => ({
    ...q,
    vendor: vendors.find(v => v.id === q.vendorId),
  }));

  if (!rfq) return <div style={{ padding: 40, color: 'var(--text-muted)' }}>RFQ not found.</div>;
  if (rfqQuotes.length === 0) return <div style={{ padding: 40, color: 'var(--text-muted)' }}>No quotations to compare.</div>;

  const sortedQuotes = [...rfqQuotes].sort((a, b) => {
    if (sortBy === 'price') return a.totalAmount - b.totalAmount;
    if (sortBy === 'delivery') return a.deliveryDays - b.deliveryDays;
    if (sortBy === 'rating') return (b.vendor?.performanceScore || 0) - (a.vendor?.performanceScore || 0);
    return 0;
  });

  const lowestPrice = Math.min(...rfqQuotes.map(q => q.totalAmount));
  const fastestDelivery = Math.min(...rfqQuotes.map(q => q.deliveryDays));

  const getBestScore = (q) => {
    let score = 0;
    if (q.totalAmount === lowestPrice) score += 2;
    if (q.deliveryDays === fastestDelivery) score += 1;
    return score;
  };
  const bestQuote = rfqQuotes.reduce((best, q) => getBestScore(q) > getBestScore(best) ? q : best, rfqQuotes[0]);

  const handleAccept = async (quote) => {
    if (quote.totalAmount > rfq.budget && rfq.budget > 0) {
      // Create Approval Request
      const approval = {
        type: 'Quotation',
        refId: quote.id,
        refTitle: `Quote from ${vendors.find(v => v.id === quote.vendorId)?.name}`,
        requestedBy: currentUser.id,
        requestedByName: currentUser.name,
        amount: quote.totalAmount,
      };
      await createApproval(approval);
      addToast(`Quotation exceeds budget. Sent for Manager approval.`, 'info');
      addLog(currentUser.id, currentUser.name, 'Requested Approval for Quotation', 'Quotation', quote.id, quote.id);
    } else {
      // Direct Accept
      await updateQuotation(quote.id, { ...quote, status: 'accepted' });
      const others = rfqQuotes.filter(q => q.id !== quote.id);
      for (const q of others) {
        await updateQuotation(q.id, { ...q, status: 'rejected' });
      }
      addToast('Quotation accepted successfully', 'success');
      addLog(currentUser.id, currentUser.name, 'Accepted Quotation', 'Quotation', quote.id, quote.id);
    }
  };

  return (
    <div className="animate-fade">
      {/* Header */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 14, marginBottom: 28 }}>
        <button className="btn btn-ghost btn-sm" onClick={() => navigate(`/rfq/${rfqId}`)}>
          <ArrowLeft size={15} /> Back to RFQ
        </button>
        <div>
          <h1 className="page-title">Quotation Comparison</h1>
          <p className="page-subtitle">{rfq.rfqNumber} — {rfq.title}</p>
        </div>
      </div>

      {/* Summary Banner */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 16, marginBottom: 28 }}>
        {[
          { label: 'Quotations Received', value: rfqQuotes.length, icon: <CheckCircle size={18} />, color: 'var(--accent)' },
          { label: 'Lowest Price', value: formatCurrency(lowestPrice), icon: <DollarSign size={18} />, color: 'var(--success)' },
          { label: 'Fastest Delivery', value: `${fastestDelivery} days`, icon: <Truck size={18} />, color: 'var(--cyan)' },
        ].map(s => (
          <div key={s.label} className="card" style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
            <div style={{ width: 44, height: 44, borderRadius: 10, background: `${s.color}18`, color: s.color, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              {s.icon}
            </div>
            <div>
              <div style={{ fontSize: 11, color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.8px', fontWeight: 600 }}>{s.label}</div>
              <div style={{ fontSize: 20, fontWeight: 800, color: 'var(--text-primary)' }}>{s.value}</div>
            </div>
          </div>
        ))}
      </div>

      {/* Sort / Filter Controls */}
      <div className="search-bar" style={{ marginBottom: 20 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <ArrowUpDown size={15} style={{ color: 'var(--text-muted)' }} />
          <span style={{ fontSize: 13, color: 'var(--text-muted)', fontWeight: 600 }}>Sort by:</span>
        </div>
        {[
          { key: 'price', label: 'Lowest Price' },
          { key: 'delivery', label: 'Fastest Delivery' },
          { key: 'rating', label: 'Best Rating' },
        ].map(opt => (
          <button
            key={opt.key}
            className={`btn btn-sm ${sortBy === opt.key ? 'btn-primary' : 'btn-ghost'}`}
            onClick={() => setSortBy(opt.key)}
          >
            {opt.label}
          </button>
        ))}
      </div>

      {/* Side-by-Side Comparison TABLE */}
      <div className="card" style={{ marginBottom: 28, overflowX: 'auto' }}>
        <div style={{ fontSize: 14, fontWeight: 700, color: 'var(--text-primary)', marginBottom: 16 }}>
          📊 Side-by-Side Vendor Comparison
        </div>
        <table style={{ width: '100%', borderCollapse: 'collapse' }}>
          <thead>
            <tr style={{ borderBottom: '2px solid var(--border)' }}>
              <th style={{ padding: '12px 16px', fontSize: 12, color: 'var(--text-muted)', fontWeight: 600, textAlign: 'left', minWidth: 160 }}>Criteria</th>
              {sortedQuotes.map(q => {
                const isBest = q.id === bestQuote.id;
                return (
                  <th key={q.id} style={{ padding: '12px 16px', fontSize: 13, textAlign: 'center', minWidth: 180 }}>
                    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 6 }}>
                      {isBest && (
                        <div style={{ background: 'var(--success)', color: 'white', fontSize: 10, fontWeight: 700, padding: '2px 8px', borderRadius: 999, marginBottom: 4 }}>
                          <Trophy size={9} style={{ display: 'inline', marginRight: 3 }} />BEST VALUE
                        </div>
                      )}
                      <div style={{ width: 40, height: 40, borderRadius: 10, background: isBest ? 'rgba(16,185,129,0.2)' : 'linear-gradient(135deg, var(--accent), var(--cyan))', border: isBest ? '2px solid var(--success)' : 'none', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 13, fontWeight: 800, color: 'white' }}>
                        {q.vendor?.name.slice(0, 2).toUpperCase()}
                      </div>
                      <div style={{ fontSize: 13, fontWeight: 700, color: isBest ? 'var(--success)' : 'var(--text-primary)' }}>{q.vendor?.name}</div>
                    </div>
                  </th>
                );
              })}
            </tr>
          </thead>
          <tbody>
            {/* Total Price Row */}
            <tr style={{ borderBottom: '1px solid var(--border)' }}>
              <td style={{ padding: '14px 16px', fontSize: 13, color: 'var(--text-muted)', fontWeight: 600 }}>
                <DollarSign size={14} style={{ display: 'inline', marginRight: 6 }} />Total Price
              </td>
              {sortedQuotes.map(q => {
                const isLowest = q.totalAmount === lowestPrice;
                return (
                  <td key={q.id} style={{ padding: '14px 16px', textAlign: 'center', background: isLowest ? 'rgba(16,185,129,0.08)' : 'transparent' }}>
                    <div style={{ fontSize: 18, fontWeight: 800, color: isLowest ? 'var(--success)' : 'var(--text-primary)' }}>
                      {formatCurrency(q.totalAmount)}
                    </div>
                    {isLowest && <div style={{ fontSize: 11, color: 'var(--success)', fontWeight: 600, marginTop: 2 }}>✓ Lowest Price</div>}
                  </td>
                );
              })}
            </tr>

            {/* Delivery Timeline Row */}
            <tr style={{ borderBottom: '1px solid var(--border)' }}>
              <td style={{ padding: '14px 16px', fontSize: 13, color: 'var(--text-muted)', fontWeight: 600 }}>
                <Truck size={14} style={{ display: 'inline', marginRight: 6 }} />Delivery Timeline
              </td>
              {sortedQuotes.map(q => {
                const isFastest = q.deliveryDays === fastestDelivery;
                return (
                  <td key={q.id} style={{ padding: '14px 16px', textAlign: 'center', background: isFastest ? 'rgba(6,182,212,0.08)' : 'transparent' }}>
                    <div style={{ fontSize: 18, fontWeight: 800, color: isFastest ? 'var(--cyan)' : 'var(--text-primary)' }}>
                      {q.deliveryDays} days
                    </div>
                    {isFastest && <div style={{ fontSize: 11, color: 'var(--cyan)', fontWeight: 600, marginTop: 2 }}>✓ Fastest</div>}
                  </td>
                );
              })}
            </tr>

            {/* Vendor Rating Row */}
            <tr style={{ borderBottom: '1px solid var(--border)' }}>
              <td style={{ padding: '14px 16px', fontSize: 13, color: 'var(--text-muted)', fontWeight: 600 }}>
                <Star size={14} style={{ display: 'inline', marginRight: 6 }} />Vendor Rating
              </td>
              {sortedQuotes.map(q => (
                <td key={q.id} style={{ padding: '14px 16px', textAlign: 'center' }}>
                  <StarRating score={q.vendor?.performanceScore || 0} />
                </td>
              ))}
            </tr>

            {/* Validity Row */}
            <tr style={{ borderBottom: '1px solid var(--border)' }}>
              <td style={{ padding: '14px 16px', fontSize: 13, color: 'var(--text-muted)', fontWeight: 600 }}>Validity</td>
              {sortedQuotes.map(q => (
                <td key={q.id} style={{ padding: '14px 16px', textAlign: 'center', fontSize: 13, color: 'var(--text-secondary)' }}>
                  {q.validity} days
                </td>
              ))}
            </tr>

            {/* Submitted Date Row */}
            <tr style={{ borderBottom: '1px solid var(--border)' }}>
              <td style={{ padding: '14px 16px', fontSize: 13, color: 'var(--text-muted)', fontWeight: 600 }}>Submitted</td>
              {sortedQuotes.map(q => (
                <td key={q.id} style={{ padding: '14px 16px', textAlign: 'center', fontSize: 13, color: 'var(--text-secondary)' }}>
                  {formatDate(q.submittedAt)}
                </td>
              ))}
            </tr>

            {/* Notes Row */}
            <tr style={{ borderBottom: '1px solid var(--border)' }}>
              <td style={{ padding: '14px 16px', fontSize: 13, color: 'var(--text-muted)', fontWeight: 600 }}>Notes</td>
              {sortedQuotes.map(q => (
                <td key={q.id} style={{ padding: '14px 16px', textAlign: 'center', fontSize: 12, color: 'var(--text-muted)' }}>
                  {q.notes || '—'}
                </td>
              ))}
            </tr>

            {/* Status Row */}
            <tr style={{ borderBottom: '1px solid var(--border)' }}>
              <td style={{ padding: '14px 16px', fontSize: 13, color: 'var(--text-muted)', fontWeight: 600 }}>Status</td>
              {sortedQuotes.map(q => (
                <td key={q.id} style={{ padding: '14px 16px', textAlign: 'center' }}>
                  <Badge status={q.status} />
                </td>
              ))}
            </tr>

            {/* Action Row */}
            <tr>
              <td style={{ padding: '14px 16px', fontSize: 13, color: 'var(--text-muted)', fontWeight: 600 }}>Action</td>
              {sortedQuotes.map(q => {
                const isBest = q.id === bestQuote.id;
                return (
                  <td key={q.id} style={{ padding: '14px 16px', textAlign: 'center' }}>
                    {q.status === 'pending' ? (
                      <div style={{ display: 'flex', gap: 6, justifyContent: 'center' }}>
                        <button className={`btn btn-sm ${isBest ? 'btn-success' : 'btn-secondary'}`} onClick={() => handleAccept(q)}>
                          <CheckCircle size={13} /> Accept
                        </button>
                        <button className="btn btn-danger btn-sm" onClick={async () => {
                          await updateQuotation(q.id, { ...q, status: 'rejected' });
                          addToast('Quotation rejected');
                        }}>
                          <XCircle size={13} />
                        </button>
                      </div>
                    ) : (
                      <Badge status={q.status} />
                    )}
                  </td>
                );
              })}
            </tr>
          </tbody>
        </table>
      </div>

      {/* Products Table */}
      <div className="card">
        <div className="card-title" style={{ marginBottom: 16 }}>Products in this RFQ</div>
        <div className="table-wrap">
          <table>
            <thead>
              <tr>
                <th>Product</th>
                <th>Qty</th>
                <th>Unit</th>
                {sortedQuotes.map(q => <th key={q.id}>{q.vendor?.name} Unit Price</th>)}
              </tr>
            </thead>
            <tbody>
              {rfq.products.map((p, i) => (
                <tr key={i}>
                  <td className="td-primary">{p.name}</td>
                  <td>{p.quantity}</td>
                  <td>{p.unit}</td>
                  {sortedQuotes.map(q => {
                    const up = q.unitPrices?.find(u => u.product === p.name);
                    const allPrices = sortedQuotes.map(sq => sq.unitPrices?.find(u => u.product === p.name)?.unitPrice).filter(Boolean);
                    const minPrice = allPrices.length ? Math.min(...allPrices) : null;
                    const isMin = up && minPrice && up.unitPrice === minPrice;
                    return (
                      <td key={q.id} style={{ fontWeight: 600, color: isMin ? 'var(--success)' : 'var(--text-primary)', background: isMin ? 'rgba(16,185,129,0.06)' : 'transparent' }}>
                        {up ? formatCurrency(up.unitPrice) : '—'} {isMin && <span style={{ fontSize: 10 }}>✓</span>}
                      </td>
                    );
                  })}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
