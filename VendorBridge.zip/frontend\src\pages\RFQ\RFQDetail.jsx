import { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useAppData } from '../../context/AppDataContext';
import { useAuth } from '../../context/AuthContext';
import Badge from '../../components/Badge';
import { formatCurrency, formatDate } from '../../utils/helpers';
import { ArrowLeft, GitBranch, Users, Package, Calendar, DollarSign, Edit3, Send } from 'lucide-react';

export default function RFQDetail() {
  const { id } = useParams();
  const { rfqs, vendors, quotations, addToast, updateRfq, updateQuotation, createQuotation } = useAppData();
  const { currentUser } = useAuth();
  const navigate = useNavigate();

  const rfq = rfqs.find(r => r.id === id);
  if (!rfq) return <div style={{ padding: 40, color: 'var(--text-muted)' }}>RFQ not found.</div>;

  const rfqVendors = vendors.filter(v => rfq.vendors?.includes(v.id));
  const rfqQuotes = quotations.filter(q => q.rfqId === id);

  // Check if currentUser is a vendor and retrieve their vendor record
  const myVendor = vendors.find(v => v.name === currentUser?.name || v.email === currentUser?.email || (currentUser?.role === 'vendor' && v.id === 'v1'));
  const myVendorId = myVendor?.id;
  const existingQuote = quotations.find(q => q.rfqId === id && q.vendorId === myVendorId);

  const [deliveryDays, setDeliveryDays] = useState(existingQuote?.deliveryDays || 7);
  const [validity, setValidity] = useState(existingQuote?.validity || 30);
  const [notes, setNotes] = useState(existingQuote?.notes || '');
  const [unitPrices, setUnitPrices] = useState(
    rfq.products.reduce((acc, p) => {
      const existingPrice = existingQuote?.unitPrices?.find(up => up.product === p.name)?.unitPrice;
      acc[p.name] = existingPrice || '';
      return acc;
    }, {})
  );

  const handleClose = async () => {
    await updateRfq(rfq.id, { ...rfq, status: 'closed' });
    addToast('RFQ closed successfully');
  };

  const handleQuotationSubmit = async (e) => {
    e.preventDefault();
    const upArray = rfq.products.map(p => ({
      product: p.name,
      quantity: p.quantity,
      unitPrice: Number(unitPrices[p.name]) || 0,
    }));
    const totalAmount = upArray.reduce((sum, item) => sum + (item.quantity * item.unitPrice), 0);

    const payload = {
      rfqId: rfq.id,
      vendorId: myVendorId,
      unitPrices: upArray,
      deliveryDays: Number(deliveryDays),
      validity: Number(validity),
      notes,
      totalAmount,
      status: 'pending',
    };

    if (existingQuote) {
      await updateQuotation(existingQuote.id, payload);
      addToast('Quotation updated successfully');
    } else {
      await createQuotation(payload);
      addToast('Quotation submitted successfully');
    }
  };

  return (
    <div className="animate-fade">
      <div style={{ display: 'flex', alignItems: 'center', gap: 14, marginBottom: 28 }}>
        <button className="btn btn-ghost btn-sm" onClick={() => navigate('/rfq')}>
          <ArrowLeft size={15} /> Back
        </button>
        <div style={{ flex: 1 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <h1 className="page-title">{rfq.title}</h1>
            <Badge status={rfq.status} />
          </div>
          <p className="page-subtitle">{rfq.rfqNumber} · Created {formatDate(rfq.createdAt)}</p>
        </div>
        <div style={{ display: 'flex', gap: 10 }}>
          {rfqQuotes.length > 1 && (
            <button className="btn btn-primary btn-sm" onClick={() => navigate(`/quotations/compare/${id}`)}>
              <GitBranch size={14} /> Compare Quotes
            </button>
          )}
          {rfq.status === 'active' && (
            <button className="btn btn-secondary btn-sm" onClick={handleClose}>Close RFQ</button>
          )}
        </div>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: currentUser.role === 'vendor' ? '1fr' : '1fr 360px', gap: 24 }}>
        {/* Left */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
          {/* Info */}
          <div className="card">
            <div className="card-title" style={{ marginBottom: 16 }}>RFQ Information</div>
            <p style={{ fontSize: 14, color: 'var(--text-muted)', marginBottom: 20, lineHeight: 1.7 }}>{rfq.description}</p>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 16 }}>
              {[
                { icon: <Calendar size={16} />, label: 'Deadline', value: formatDate(rfq.deadline) },
                { icon: <Users size={16} />, label: 'Vendors Invited', value: rfqVendors.length },
                { icon: <DollarSign size={16} />, label: 'Budget', value: rfq.budget ? formatCurrency(rfq.budget) : 'Not set' },
              ].map(item => (
                <div key={item.label} style={{ background: 'var(--bg-elevated)', borderRadius: 10, padding: '14px 16px', border: '1px solid var(--border)' }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 8, color: 'var(--accent-light)', marginBottom: 8 }}>
                    {item.icon}
                    <span style={{ fontSize: 11, fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.8px', color: 'var(--text-muted)' }}>{item.label}</span>
                  </div>
                  <div style={{ fontSize: 16, fontWeight: 700, color: 'var(--text-primary)' }}>{item.value}</div>
                </div>
              ))}
            </div>
          </div>

          {/* Products */}
          <div className="card">
            <div className="card-title" style={{ marginBottom: 16 }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                <Package size={18} style={{ color: 'var(--accent-light)' }} />
                Products Required
              </div>
            </div>
            <div className="table-wrap">
              <table>
                <thead>
                  <tr><th>#</th><th>Product Name</th><th>Quantity</th><th>Unit</th></tr>
                </thead>
                <tbody>
                  {rfq.products.map((p, i) => (
                    <tr key={i}>
                      <td style={{ color: 'var(--text-muted)', width: 40 }}>{i + 1}</td>
                      <td className="td-primary">{p.name}</td>
                      <td>{p.quantity}</td>
                      <td>{p.unit}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Quotations / Vendor Submission Form */}
          {currentUser.role === 'vendor' ? (
            <div className="card">
              <div className="card-header" style={{ marginBottom: 20 }}>
                <div className="card-title" style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                  <Edit3 size={18} style={{ color: 'var(--accent-light)' }} />
                  {existingQuote ? 'Edit Your Quotation Response' : 'Submit Quotation Response'}
                </div>
                {existingQuote && (
                  <Badge status={existingQuote.status} label={existingQuote.status.toUpperCase()} />
                )}
              </div>

              {rfq.status !== 'active' ? (
                <p style={{ color: 'var(--text-muted)', fontSize: 13 }}>This RFQ is no longer active for responses.</p>
              ) : (
                <form onSubmit={handleQuotationSubmit} style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
                  <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
                    <div style={{ fontSize: 13, fontWeight: 600, color: 'var(--text-secondary)' }}>Item Pricing</div>
                    {rfq.products.map((p, idx) => (
                      <div key={idx} style={{ display: 'grid', gridTemplateColumns: '2fr 1fr 1fr', gap: 12, alignItems: 'center' }}>
                        <div style={{ fontSize: 13, color: 'var(--text-primary)' }}>{p.name} ({p.quantity} {p.unit})</div>
                        <div style={{ fontSize: 12, color: 'var(--text-muted)', textAlign: 'right' }}>Unit Price (₹)</div>
                        <input
                          type="number"
                          required
                          className="form-input"
                          placeholder="Price per unit"
                          value={unitPrices[p.name] || ''}
                          onChange={e => setUnitPrices(prev => ({ ...prev, [p.name]: e.target.value }))}
                        />
                      </div>
                    ))}
                  </div>

                  <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
                    <div className="form-group">
                      <label className="form-label">Delivery Timeline (Days) *</label>
                      <input
                        type="number"
                        required
                        className="form-input"
                        placeholder="e.g. 7"
                        value={deliveryDays}
                        onChange={e => setDeliveryDays(e.target.value)}
                      />
                    </div>
                    <div className="form-group">
                      <label className="form-label">Quote Validity (Days) *</label>
                      <input
                        type="number"
                        required
                        className="form-input"
                        placeholder="e.g. 30"
                        value={validity}
                        onChange={e => setValidity(e.target.value)}
                      />
                    </div>
                  </div>

                  <div className="form-group">
                    <label className="form-label">Vendor Remarks / Notes</label>
                    <textarea
                      className="form-input"
                      rows={3}
                      placeholder="Add terms, inclusions, discounts, warranty details…"
                      value={notes}
                      onChange={e => setNotes(e.target.value)}
                    />
                  </div>

                  <div style={{ display: 'flex', justifyContent: 'flex-end', marginTop: 10 }}>
                    <button type="submit" className="btn btn-primary">
                      <Send size={14} /> {existingQuote ? 'Update Quotation' : 'Submit Quotation'}
                    </button>
                  </div>
                </form>
              )}
            </div>
          ) : (
            <div className="card">
              <div className="card-header">
                <div className="card-title">Quotations Received ({rfqQuotes.length})</div>
                {rfqQuotes.length > 1 && (
                  <button className="btn btn-primary btn-sm" onClick={() => navigate(`/quotations/compare/${id}`)}>
                    <GitBranch size={13} /> Compare
                  </button>
                )}
              </div>
              {rfqQuotes.length === 0 ? (
                <p style={{ color: 'var(--text-muted)', fontSize: 13 }}>No quotations received yet.</p>
              ) : (
                <div className="table-wrap">
                  <table>
                    <thead>
                      <tr><th>Vendor</th><th>Total Amount</th><th>Delivery</th><th>Validity</th><th>Status</th></tr>
                    </thead>
                    <tbody>
                      {rfqQuotes.map(q => {
                        const vendor = vendors.find(v => v.id === q.vendorId);
                        return (
                          <tr key={q.id}>
                            <td className="td-primary">{vendor?.name || '—'}</td>
                            <td style={{ fontWeight: 700, color: 'var(--text-primary)' }}>{formatCurrency(q.totalAmount)}</td>
                            <td>{q.deliveryDays} days</td>
                            <td>{q.validity} days</td>
                            <td><Badge status={q.status} /></td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Right: Vendors */}
        {currentUser.role !== 'vendor' && (
          <div className="card" style={{ alignSelf: 'start' }}>
            <div className="card-title" style={{ marginBottom: 16 }}>Invited Vendors</div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
              {rfqVendors.map(v => {
                const quote = rfqQuotes.find(q => q.vendorId === v.id);
                return (
                  <div key={v.id} style={{ padding: '12px 14px', background: 'var(--bg-elevated)', borderRadius: 10, border: '1px solid var(--border)' }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: quote ? 8 : 0 }}>
                      <div style={{ width: 34, height: 34, borderRadius: 8, background: 'linear-gradient(135deg, var(--accent), var(--cyan))', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 12, fontWeight: 700, color: 'white' }}>
                        {v.name.slice(0, 2).toUpperCase()}
                      </div>
                      <div style={{ flex: 1 }}>
                        <div style={{ fontSize: 13, fontWeight: 600, color: 'var(--text-primary)' }}>{v.name}</div>
                        <div style={{ fontSize: 11, color: 'var(--text-muted)' }}>{v.category}</div>
                      </div>
                      <Badge status={quote ? quote.status : 'pending'} label={quote ? quote.status : 'awaiting'} />
                    </div>
                    {quote && (
                      <div style={{ paddingTop: 8, borderTop: '1px solid var(--border)', display: 'flex', justifyContent: 'space-between', fontSize: 12 }}>
                        <span style={{ color: 'var(--text-muted)' }}>Quoted</span>
                        <span style={{ fontWeight: 700, color: 'var(--accent-light)' }}>{formatCurrency(quote.totalAmount)}</span>
                      </div>
                    )}
                  </div>
                );
              })}
              {rfqVendors.length === 0 && <p style={{ fontSize: 13, color: 'var(--text-muted)' }}>No vendors invited.</p>}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
