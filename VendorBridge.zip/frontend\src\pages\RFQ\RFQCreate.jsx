import { useState, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAppData } from '../../context/AppDataContext';
import { useAuth } from '../../context/AuthContext';
import {
  ArrowLeft, ArrowRight, Plus, Trash2, Upload, FileText,
  CheckCircle, ClipboardList, Package, Send, Save, X, GripVertical
} from 'lucide-react';

const CATEGORIES = ['IT Equipment', 'Office Supplies', 'Raw Materials', 'Furniture', 'Services', 'Logistics', 'Other'];
const PRIORITIES  = ['Low', 'Medium', 'High', 'Critical'];
const UNITS       = ['Unit', 'Piece', 'Ream', 'Roll', 'Box', 'Kg', 'Litre', 'Set', 'Pack', 'Metre'];

const STEPS = [
  { num: 1, label: 'Basic Info',  icon: ClipboardList },
  { num: 2, label: 'Items',       icon: Package },
  { num: 3, label: 'Documents',   icon: FileText },
  { num: 4, label: 'Review',      icon: CheckCircle },
];

const emptyItem = { name: '', quantity: '', unit: 'Unit' };

export default function RFQCreate() {
  const { vendors, addToast, addLog, createRfq } = useAppData();
  const { currentUser } = useAuth();
  const navigate = useNavigate();
  const fileInputRef = useRef(null);
  const activeVendors = vendors.filter(v => v.status === 'active');

  const [step, setStep] = useState(1);
  const [form, setForm] = useState({
    title: '', category: 'IT Equipment', priority: 'Medium',
    deadline: '', requirements: '', budget: '',
  });
  const [items, setItems]               = useState([{ ...emptyItem }]);
  const [attachedFiles, setAttachedFiles] = useState([]);
  const [selectedVendors, setSelectedVendors] = useState([]);
  const [isDragging, setIsDragging]     = useState(false);

  /* ── helpers ─────────────────────────────────────────────────── */
  const set = (k) => (e) => setForm(f => ({ ...f, [k]: e.target.value }));

  const updateItem = (i, k, v) =>
    setItems(prev => prev.map((item, idx) => idx === i ? { ...item, [k]: v } : item));

  const removeItem = (i) =>
    setItems(prev => prev.length > 1 ? prev.filter((_, idx) => idx !== i) : prev);

  const toggleVendor = (id) =>
    setSelectedVendors(prev => prev.includes(id) ? prev.filter(v => v !== id) : [...prev, id]);

  /* ── file handling ──────────────────────────────────────────── */
  const addFiles = (fileList) => {
    const newFiles = Array.from(fileList).map(f => ({
      name: f.name,
      size: f.size,
      type: f.type,
    }));
    setAttachedFiles(prev => [...prev, ...newFiles]);
  };

  const handleDrop = (e) => {
    e.preventDefault();
    setIsDragging(false);
    if (e.dataTransfer.files?.length) addFiles(e.dataTransfer.files);
  };

  const handleDragOver = (e) => { e.preventDefault(); setIsDragging(true); };
  const handleDragLeave = ()  => setIsDragging(false);

  const formatFileSize = (bytes) => {
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1048576) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / 1048576).toFixed(1)} MB`;
  };

  /* ── submit ─────────────────────────────────────────────────── */
  const handleSubmit = async (asDraft) => {
    if (!form.title.trim()) { addToast('Please enter an RFQ name', 'error'); setStep(1); return; }
    if (!form.deadline)      { addToast('Please set a deadline', 'error'); setStep(1); return; }
    if (!items.some(i => i.name.trim())) { addToast('Add at least one item', 'error'); setStep(2); return; }

    const seq = String(Math.floor(Math.random() * 9000) + 1000);
    const rfqNumber = `RFQ-${new Date().getFullYear()}-${seq}`;
    const newRFQ = {
      rfqNumber,
      title: form.title,
      description: form.requirements,
      category: form.category,
      priority: form.priority,
      deadline: form.deadline,
      budget: form.budget ? Number(form.budget) : 0,
      status: asDraft ? 'draft' : 'active',
      products: items.filter(i => i.name.trim()).map(i => ({ ...i, quantity: Number(i.quantity) || 0 })),
      vendors: selectedVendors,
    };

    const created = await createRfq(newRFQ);
    if (created) {
      addLog(currentUser.id, currentUser.name, asDraft ? 'Saved Draft RFQ' : 'Created RFQ', 'RFQ', created.id, created.title);
      addToast(asDraft
        ? `Draft "${rfqNumber}" saved`
        : `RFQ "${rfqNumber}" submitted to ${selectedVendors.length} vendor(s)`);
      navigate('/rfq');
    }
  };

  /* ── step indicator ─────────────────────────────────────────── */
  const StepIndicator = () => (
    <div style={{
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      gap: 0, marginBottom: 32, padding: '0 40px',
    }}>
      {STEPS.map((s, i) => {
        const Icon = s.icon;
        const done    = step > s.num;
        const active  = step === s.num;
        const color   = done ? 'var(--success)' : active ? 'var(--accent)' : 'var(--border-strong)';
        const bg      = done ? 'rgba(16,185,129,0.15)' : active ? 'var(--accent-glow)' : 'var(--bg-elevated)';
        const txtColor = done || active ? 'var(--text-primary)' : 'var(--text-muted)';

        return (
          <div key={s.num} style={{ display: 'flex', alignItems: 'center', flex: i < STEPS.length - 1 ? 1 : 'none' }}>
            {/* Step circle */}
            <div
              onClick={() => setStep(s.num)}
              style={{
                display: 'flex', alignItems: 'center', gap: 10,
                cursor: 'pointer', transition: 'all 0.2s',
              }}
            >
              <div style={{
                width: 42, height: 42, borderRadius: 12,
                background: bg, border: `2px solid ${color}`,
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                transition: 'all 0.3s', boxShadow: active ? `0 0 20px ${color}40` : 'none',
              }}>
                {done
                  ? <CheckCircle size={18} style={{ color: 'var(--success)' }} />
                  : <Icon size={18} style={{ color }} />
                }
              </div>
              <div>
                <div style={{ fontSize: 11, fontWeight: 700, color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.6px' }}>
                  Step {s.num}
                </div>
                <div style={{ fontSize: 13, fontWeight: 700, color: txtColor }}>{s.label}</div>
              </div>
            </div>

            {/* Connector line */}
            {i < STEPS.length - 1 && (
              <div style={{
                flex: 1, height: 2, margin: '0 16px',
                background: done ? 'var(--success)' : 'var(--border)',
                borderRadius: 1, transition: 'background 0.3s',
              }} />
            )}
          </div>
        );
      })}
    </div>
  );

  /* ── renders per step ───────────────────────────────────────── */
  const renderStep1 = () => (
    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 24 }}>
      {/* Left: Basic fields */}
      <div className="card">
        <div className="card-title" style={{ marginBottom: 20 }}>📋 RFQ Information</div>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 18 }}>
          <div className="form-group">
            <label className="form-label">RFQ Name *</label>
            <input className="form-input" value={form.title} onChange={set('title')}
              placeholder="e.g. Office IT Equipment Q3 2024" required />
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14 }}>
            <div className="form-group">
              <label className="form-label">Category</label>
              <select className="form-input" value={form.category} onChange={set('category')}>
                {CATEGORIES.map(c => <option key={c} value={c}>{c}</option>)}
              </select>
            </div>
            <div className="form-group">
              <label className="form-label">Priority</label>
              <select className="form-input" value={form.priority} onChange={set('priority')}>
                {PRIORITIES.map(p => <option key={p} value={p}>{p}</option>)}
              </select>
            </div>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14 }}>
            <div className="form-group">
              <label className="form-label">Deadline *</label>
              <input className="form-input" type="date" value={form.deadline} onChange={set('deadline')} required />
            </div>
            <div className="form-group">
              <label className="form-label">Budget (₹)</label>
              <input className="form-input" type="number" value={form.budget} onChange={set('budget')} placeholder="Optional" />
            </div>
          </div>
        </div>
      </div>

      {/* Right: Requirements */}
      <div className="card">
        <div className="card-title" style={{ marginBottom: 20 }}>📝 Requirements & Product Details</div>
        <textarea
          className="form-input"
          value={form.requirements}
          onChange={set('requirements')}
          placeholder="Describe the procurement requirements in detail…&#10;&#10;• Specifications&#10;• Quality standards&#10;• Delivery requirements&#10;• Special conditions"
          rows={12}
          style={{ resize: 'vertical', lineHeight: 1.7, fontFamily: 'inherit' }}
        />
        <div style={{ marginTop: 12, fontSize: 12, color: 'var(--text-muted)' }}>
          Tip: Be as detailed as possible to receive accurate vendor quotations.
        </div>
      </div>
    </div>
  );

  const renderStep2 = () => (
    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 24 }}>
      {/* Left: Items List */}
      <div className="card">
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 20 }}>
          <div>
            <div className="card-title">📦 Line Items</div>
            <div style={{ fontSize: 12, color: 'var(--text-muted)', marginTop: 4 }}>
              {items.filter(i => i.name.trim()).length} item(s) added
            </div>
          </div>
          <button
            type="button"
            className="btn btn-secondary btn-sm"
            onClick={() => setItems(p => [...p, { ...emptyItem }])}
          >
            <Plus size={14} /> Add Item
          </button>
        </div>

        <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
          {/* Column Headers */}
          <div style={{
            display: 'grid', gridTemplateColumns: '1fr 90px 100px 36px',
            gap: 10, padding: '0 0 8px', borderBottom: '1px solid var(--border)',
          }}>
            <div style={{ fontSize: 11, fontWeight: 700, color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.6px' }}>Item Name</div>
            <div style={{ fontSize: 11, fontWeight: 700, color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.6px' }}>Qty</div>
            <div style={{ fontSize: 11, fontWeight: 700, color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.6px' }}>Unit</div>
            <div />
          </div>

          {items.map((item, i) => (
            <div key={i} style={{
              display: 'grid', gridTemplateColumns: '1fr 90px 100px 36px',
              gap: 10, alignItems: 'center',
              padding: '8px 0',
              borderBottom: i < items.length - 1 ? '1px solid var(--border)' : 'none',
              animation: 'fadeIn 0.2s ease',
            }}>
              <input
                className="form-input"
                value={item.name}
                onChange={e => updateItem(i, 'name', e.target.value)}
                placeholder={`Item ${i + 1}`}
              />
              <input
                className="form-input"
                type="number"
                value={item.quantity}
                onChange={e => updateItem(i, 'quantity', e.target.value)}
                placeholder="0"
                min="0"
              />
              <select
                className="form-input"
                value={item.unit}
                onChange={e => updateItem(i, 'unit', e.target.value)}
              >
                {UNITS.map(u => <option key={u}>{u}</option>)}
              </select>
              <button
                type="button"
                onClick={() => removeItem(i)}
                disabled={items.length === 1}
                style={{
                  height: 38, width: 36, display: 'flex', alignItems: 'center', justifyContent: 'center',
                  borderRadius: 8, border: '1px solid rgba(239,68,68,0.2)',
                  background: items.length === 1 ? 'var(--bg-elevated)' : 'var(--danger-bg)',
                  color: items.length === 1 ? 'var(--text-muted)' : 'var(--danger)',
                  cursor: items.length === 1 ? 'not-allowed' : 'pointer',
                  transition: 'all 0.15s',
                }}
              >
                <Trash2 size={14} />
              </button>
            </div>
          ))}
        </div>

        {/* Quick-add shortcut */}
        <button
          type="button"
          onClick={() => setItems(p => [...p, { ...emptyItem }])}
          style={{
            width: '100%', marginTop: 14, padding: '10px 0',
            border: '2px dashed var(--border)', borderRadius: 10,
            background: 'transparent', color: 'var(--text-muted)',
            fontSize: 13, cursor: 'pointer', transition: 'all 0.2s',
            display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6,
          }}
          onMouseEnter={e => { e.currentTarget.style.borderColor = 'var(--accent)'; e.currentTarget.style.color = 'var(--accent-light)'; }}
          onMouseLeave={e => { e.currentTarget.style.borderColor = 'var(--border)'; e.currentTarget.style.color = 'var(--text-muted)'; }}
        >
          <Plus size={14} /> Add another item
        </button>
      </div>

      {/* Right: Invite Vendors */}
      <div className="card">
        <div className="card-title" style={{ marginBottom: 6 }}>🏢 Invite Vendors</div>
        <p style={{ fontSize: 12, color: 'var(--text-muted)', marginBottom: 16 }}>
          Select vendors to receive this RFQ ({selectedVendors.length} selected)
        </p>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 8, maxHeight: 340, overflowY: 'auto' }}>
          {activeVendors.map(v => {
            const sel = selectedVendors.includes(v.id);
            return (
              <div key={v.id} onClick={() => toggleVendor(v.id)}
                style={{
                  padding: '12px 14px', borderRadius: 10,
                  border: `2px solid ${sel ? 'var(--accent)' : 'var(--border)'}`,
                  background: sel ? 'var(--accent-glow)' : 'var(--bg-elevated)',
                  cursor: 'pointer', transition: 'all 0.2s',
                  display: 'flex', alignItems: 'center', gap: 10,
                }}
              >
                <div style={{
                  width: 34, height: 34, borderRadius: 8,
                  background: sel ? 'var(--accent)' : 'linear-gradient(135deg, var(--accent), var(--cyan))',
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  fontSize: 12, fontWeight: 700, color: 'white',
                }}>
                  {sel ? <CheckCircle size={16} /> : v.name.slice(0, 2).toUpperCase()}
                </div>
                <div style={{ flex: 1 }}>
                  <div style={{ fontSize: 13, fontWeight: 600, color: sel ? 'var(--accent-light)' : 'var(--text-primary)' }}>
                    {v.name}
                  </div>
                  <div style={{ fontSize: 11, color: 'var(--text-muted)' }}>{v.category}</div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );

  const renderStep3 = () => (
    <div style={{ maxWidth: 700, margin: '0 auto' }}>
      <div className="card">
        <div className="card-title" style={{ marginBottom: 6 }}>📄 Documents & Attachments</div>
        <p style={{ fontSize: 12, color: 'var(--text-muted)', marginBottom: 20 }}>
          Upload specifications, drawings, or RFQ documents
        </p>

        {/* Drag & Drop Area */}
        <div
          onDrop={handleDrop}
          onDragOver={handleDragOver}
          onDragLeave={handleDragLeave}
          onClick={() => fileInputRef.current?.click()}
          style={{
            border: `2px dashed ${isDragging ? 'var(--accent)' : 'var(--border-strong)'}`,
            borderRadius: 14,
            padding: '48px 24px',
            textAlign: 'center',
            cursor: 'pointer',
            background: isDragging ? 'var(--accent-glow)' : 'var(--bg-elevated)',
            transition: 'all 0.25s',
            marginBottom: 20,
          }}
        >
          <input
            ref={fileInputRef}
            type="file"
            multiple
            onChange={e => { if (e.target.files?.length) addFiles(e.target.files); }}
            style={{ display: 'none' }}
          />
          <div style={{
            width: 60, height: 60, borderRadius: 14,
            background: isDragging ? 'var(--accent)' : 'linear-gradient(135deg, var(--accent), var(--cyan))',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            margin: '0 auto 16px', transition: 'all 0.3s',
            boxShadow: isDragging ? '0 0 30px var(--accent-glow)' : 'none',
          }}>
            <Upload size={24} style={{ color: 'white' }} />
          </div>
          <div style={{ fontSize: 15, fontWeight: 700, color: isDragging ? 'var(--accent-light)' : 'var(--text-primary)', marginBottom: 6 }}>
            {isDragging ? 'Drop files here' : 'Drag & Drop files here'}
          </div>
          <div style={{ fontSize: 13, color: 'var(--text-muted)' }}>
            or <span style={{ color: 'var(--accent-light)', fontWeight: 600, textDecoration: 'underline' }}>browse files</span>
          </div>
          <div style={{ fontSize: 11, color: 'var(--text-muted)', marginTop: 8 }}>
            PDF, DOC, XLS, PNG, JPG — Max 10MB per file
          </div>
        </div>

        {/* Uploaded Files List */}
        {attachedFiles.length > 0 && (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
            <div style={{ fontSize: 12, fontWeight: 700, color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.6px', marginBottom: 4 }}>
              Uploaded Files ({attachedFiles.length})
            </div>
            {attachedFiles.map((file, idx) => (
              <div key={idx} style={{
                display: 'flex', alignItems: 'center', gap: 12,
                padding: '10px 14px', borderRadius: 10,
                background: 'var(--bg-elevated)', border: '1px solid var(--border)',
                transition: 'all 0.15s',
              }}>
                <div style={{
                  width: 36, height: 36, borderRadius: 8,
                  background: 'linear-gradient(135deg, var(--accent), var(--cyan))',
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                }}>
                  <FileText size={16} style={{ color: 'white' }} />
                </div>
                <div style={{ flex: 1 }}>
                  <div style={{ fontSize: 13, fontWeight: 600, color: 'var(--text-primary)' }}>{file.name}</div>
                  <div style={{ fontSize: 11, color: 'var(--text-muted)' }}>{formatFileSize(file.size)}</div>
                </div>
                <button
                  type="button"
                  onClick={(e) => { e.stopPropagation(); setAttachedFiles(prev => prev.filter((_, i) => i !== idx)); }}
                  style={{
                    width: 28, height: 28, borderRadius: 6,
                    background: 'var(--danger-bg)', border: '1px solid rgba(239,68,68,0.2)',
                    color: 'var(--danger)', cursor: 'pointer',
                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                  }}
                >
                  <X size={12} />
                </button>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );

  const renderStep4 = () => {
    const validItems = items.filter(i => i.name.trim());
    return (
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 24 }}>
        {/* Summary Left */}
        <div className="card">
          <div className="card-title" style={{ marginBottom: 20 }}>📋 RFQ Summary</div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
            {[
              { label: 'RFQ Name', value: form.title || '—' },
              { label: 'Category', value: form.category },
              { label: 'Priority', value: form.priority },
              { label: 'Deadline', value: form.deadline || '—' },
              { label: 'Budget', value: form.budget ? `₹${Number(form.budget).toLocaleString()}` : 'Not specified' },
            ].map(r => (
              <div key={r.label} style={{ display: 'flex', justifyContent: 'space-between', padding: '10px 0', borderBottom: '1px solid var(--border)' }}>
                <span style={{ fontSize: 13, color: 'var(--text-muted)', fontWeight: 600 }}>{r.label}</span>
                <span style={{ fontSize: 13, fontWeight: 700, color: 'var(--text-primary)' }}>{r.value}</span>
              </div>
            ))}
          </div>

          {form.requirements && (
            <div style={{ marginTop: 16 }}>
              <div style={{ fontSize: 12, fontWeight: 700, color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.6px', marginBottom: 8 }}>Requirements</div>
              <div style={{ padding: '12px 14px', borderRadius: 8, background: 'var(--bg-elevated)', fontSize: 13, color: 'var(--text-secondary)', lineHeight: 1.6, whiteSpace: 'pre-wrap' }}>
                {form.requirements}
              </div>
            </div>
          )}
        </div>

        {/* Summary Right */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
          {/* Items */}
          <div className="card">
            <div className="card-title" style={{ marginBottom: 16 }}>
              📦 Items ({validItems.length})
            </div>
            {validItems.length === 0 ? (
              <div style={{ padding: 20, textAlign: 'center', color: 'var(--text-muted)', fontSize: 13 }}>No items added</div>
            ) : (
              <div className="table-wrap">
                <table>
                  <thead>
                    <tr>
                      <th>#</th>
                      <th>Item</th>
                      <th>Qty</th>
                      <th>Unit</th>
                    </tr>
                  </thead>
                  <tbody>
                    {validItems.map((item, i) => (
                      <tr key={i}>
                        <td style={{ color: 'var(--text-muted)' }}>{i + 1}</td>
                        <td className="td-primary">{item.name}</td>
                        <td>{item.quantity || 0}</td>
                        <td>{item.unit}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>

          {/* Vendors */}
          <div className="card">
            <div className="card-title" style={{ marginBottom: 12 }}>
              🏢 Vendors ({selectedVendors.length})
            </div>
            {selectedVendors.length === 0 ? (
              <div style={{ padding: 16, textAlign: 'center', color: 'var(--text-muted)', fontSize: 13 }}>
                No vendors selected — RFQ will be saved but not sent
              </div>
            ) : (
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8 }}>
                {selectedVendors.map(id => {
                  const v = vendors.find(x => x.id === id);
                  return v ? (
                    <div key={id} style={{
                      padding: '6px 14px', borderRadius: 20,
                      background: 'var(--accent-glow)', border: '1px solid var(--accent)',
                      fontSize: 12, fontWeight: 600, color: 'var(--accent-light)',
                    }}>
                      {v.name}
                    </div>
                  ) : null;
                })}
              </div>
            )}
          </div>

          {/* Attachments */}
          <div className="card">
            <div className="card-title" style={{ marginBottom: 12 }}>
              📄 Documents ({attachedFiles.length})
            </div>
            {attachedFiles.length === 0 ? (
              <div style={{ padding: 16, textAlign: 'center', color: 'var(--text-muted)', fontSize: 13 }}>No documents attached</div>
            ) : (
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8 }}>
                {attachedFiles.map((f, i) => (
                  <div key={i} style={{
                    padding: '6px 12px', borderRadius: 8,
                    background: 'var(--bg-elevated)', border: '1px solid var(--border)',
                    fontSize: 12, color: 'var(--text-secondary)',
                    display: 'flex', alignItems: 'center', gap: 6,
                  }}>
                    <FileText size={12} /> {f.name}
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    );
  };

  /* ── main render ────────────────────────────────────────────── */
  return (
    <div className="animate-fade">
      {/* Header */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 14, marginBottom: 28 }}>
        <button className="btn btn-ghost btn-sm" onClick={() => navigate('/rfq')}>
          <ArrowLeft size={15} /> Back
        </button>
        <div>
          <h1 className="page-title">Create RFQ</h1>
          <p className="page-subtitle">New request for quotation</p>
        </div>
      </div>

      {/* Step Indicator */}
      <StepIndicator />

      {/* Step Content */}
      <form onSubmit={e => e.preventDefault()}>
        {step === 1 && renderStep1()}
        {step === 2 && renderStep2()}
        {step === 3 && renderStep3()}
        {step === 4 && renderStep4()}

        {/* Bottom Navigation */}
        <div style={{
          display: 'flex', justifyContent: 'space-between', alignItems: 'center',
          marginTop: 28, padding: '20px 0',
          borderTop: '1px solid var(--border)',
        }}>
          {/* Left: Save Draft (always visible) */}
          <button
            type="button"
            className="btn btn-ghost"
            onClick={() => handleSubmit(true)}
          >
            <Save size={15} /> Save Draft
          </button>

          {/* Right: Navigation + Submit */}
          <div style={{ display: 'flex', gap: 10 }}>
            {step > 1 && (
              <button type="button" className="btn btn-secondary" onClick={() => setStep(s => s - 1)}>
                <ArrowLeft size={15} /> Previous
              </button>
            )}

            {step < 4 ? (
              <button type="button" className="btn btn-primary" onClick={() => setStep(s => s + 1)}>
                Next <ArrowRight size={15} />
              </button>
            ) : (
              <button
                type="button"
                className="btn btn-success"
                onClick={() => handleSubmit(false)}
                style={{ minWidth: 160, justifyContent: 'center' }}
              >
                <Send size={15} /> Submit RFQ
              </button>
            )}
          </div>
        </div>
      </form>
    </div>
  );
}
