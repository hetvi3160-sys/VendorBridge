import { NavLink, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { useAppData } from '../context/AppDataContext';
import {
  LayoutDashboard, FileText, MessageSquare,
  CheckCircle, ShoppingCart, Receipt, FolderOpen,
  BarChart3, LogOut, Building2, Bell, Users, Activity
} from 'lucide-react';

export default function Sidebar() {
  const { currentUser, logout, can } = useAuth();
  const { approvals, rfqs } = useAppData();
  const navigate = useNavigate();

  const pendingApprovals = approvals.filter(a => a.status === 'pending').length;
  const activeRFQs = rfqs.filter(r => r.status === 'active').length;

  const handleLogout = () => { logout(); navigate('/login'); };

  // Role-based nav — Admin sees everything
  const isAdmin = currentUser?.role === 'admin';
  const isVendor = currentUser?.role === 'vendor';
  const isProcurement = currentUser?.role === 'procurement';
  const isManager = currentUser?.role === 'manager';

  const navSections = [
    // ── Core ────────────────────────────────────────────────────────────────
    {
      label: 'Core',
      items: [
        { to: '/dashboard', icon: LayoutDashboard, label: 'Dashboard' },
      ],
    },

    // ── Procurement ─────────────────────────────────────────────────────────
    ...(!isVendor ? [{
      label: 'Procurement',
      items: [
        { to: '/rfq',             icon: FileText,      label: 'RFQs',           badge: activeRFQs > 0 ? activeRFQs : null },
        { to: '/quotations',      icon: MessageSquare, label: 'Quotations' },
        { to: '/approvals',       icon: CheckCircle,   label: 'Approvals',      badge: pendingApprovals > 0 ? pendingApprovals : null },
        { to: '/purchase-orders', icon: ShoppingCart,  label: 'Purchase Orders' },
      ],
    }] : []),

    // ── Vendor-only ─────────────────────────────────────────────────────────
    ...(isVendor ? [{
      label: 'Vendor Portal',
      items: [
        { to: '/rfq',        icon: FileText,      label: 'Open RFQs',   badge: activeRFQs > 0 ? activeRFQs : null },
        { to: '/quotations', icon: MessageSquare, label: 'My Quotations' },
      ],
    }] : []),

    // ── Finance ─────────────────────────────────────────────────────────────
    ...(!isVendor ? [{
      label: 'Finance',
      items: [
        { to: '/invoices',  icon: Receipt,    label: 'Invoices' },
        { to: '/documents', icon: FolderOpen, label: 'Documents' },
      ],
    }] : []),

    // ── Management ──────────────────────────────────────────────────────────
    ...(isAdmin || isManager ? [{
      label: 'Management',
      items: [
        { to: '/vendors', icon: Building2, label: 'Vendors' },
        { to: '/reports', icon: BarChart3, label: 'Reports & Analytics' },
        { to: '/activity', icon: Activity, label: 'Activity Logs' },
        ...(isAdmin ? [{ to: '/users', icon: Users, label: 'User Management' }] : []),
      ],
    }] : []),

    // ── Analytics for Procurement ────────────────────────────────────────────
    ...(isProcurement ? [{
      label: 'Analytics',
      items: [
        { to: '/reports',  icon: BarChart3, label: 'Reports' },
        { to: '/activity', icon: Activity,  label: 'Activity Logs' },
      ],
    }] : []),
  ];

  const ROLE_COLORS = {
    admin:       { bg: 'rgba(99,102,241,0.15)', color: 'var(--accent-light)' },
    procurement: { bg: 'rgba(6,182,212,0.15)',  color: 'var(--cyan)' },
    vendor:      { bg: 'rgba(16,185,129,0.15)', color: 'var(--success)' },
    manager:     { bg: 'rgba(245,158,11,0.15)', color: 'var(--warning)' },
  };
  const roleMeta = ROLE_COLORS[currentUser?.role] || ROLE_COLORS.admin;

  return (
    <aside className="sidebar">
      <div className="sidebar-logo">
        <div className="sidebar-logo-text">⬡ VendorBridge</div>
        <div className="sidebar-logo-sub">Procurement ERP</div>
      </div>

      <nav className="sidebar-nav">
        {navSections.map(section => (
          <div key={section.label}>
            <div className="nav-section-label">{section.label}</div>
            {section.items.map(item => {
              const Icon = item.icon;
              return (
                <NavLink
                  key={item.to}
                  to={item.to}
                  className={({ isActive }) => `nav-item${isActive ? ' active' : ''}`}
                >
                  <Icon size={17} />
                  {item.label}
                  {item.badge && <span className="nav-badge">{item.badge}</span>}
                </NavLink>
              );
            })}
          </div>
        ))}
      </nav>

      {/* User Footer */}
      <div className="sidebar-user">
        <div className="user-avatar">{currentUser?.avatar || '??'}</div>
        <div className="user-info">
          <div className="user-name">{currentUser?.name}</div>
          <div style={{ fontSize: 10, marginTop: 3, padding: '2px 8px', borderRadius: 20, display: 'inline-flex', fontWeight: 700, textTransform: 'capitalize', letterSpacing: '0.3px', ...roleMeta }}>
            {currentUser?.role === 'procurement' ? 'Procurement Officer' :
             currentUser?.role === 'manager' ? 'Manager / Approver' :
             currentUser?.role}
          </div>
        </div>
        <button className="topbar-btn" onClick={handleLogout} title="Sign Out">
          <LogOut size={15} />
        </button>
      </div>
    </aside>
  );
}
