import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAppData } from '../../context/AppDataContext';
import Badge from '../../components/Badge';
import { formatCurrency, formatDate } from '../../utils/helpers';
import { Search, Receipt } from 'lucide-react';

export default function InvoiceList() {
  const { invoices } = useAppData();
  const navigate = useNavigate();
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');

  const filtered = invoices.filter(inv => {
    const matchSearch = inv.invoiceNumber.toLowerCase().includes(search.toLowerCase()) ||
      inv.vendorName.toLowerCase().includes(search.toLowerCase()) ||
      inv.poNumber.toLowerCase().includes(search.toLowerCase());
    const matchStatus = statusFilter === 'all' || inv.status === statusFilter;
    return matchSearch && matchStatus;
  });

  const totalPending = invoices.filter(i => i.status === 'pending').reduce((s, i) => s + i.total, 0);
  const totalPaid = invoices.filter(i => i.status === 'paid').reduce((s, i) => s + i.total, 0);

  return (
    <div className="animate-fade">
      <div className="page-header">
        <div>
          <h1 className="page-title">Invoices</h1>
          <p className="page-subtitle">{invoices.length} total invoices</p>
        </div>
      </div>

      {/* Stats */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 16, marginBottom: 24 }}>
        {[
          { label: 'Total Invoiced', value: formatCurrency(invoices.reduce((s, i) => s + i.total, 0)), color: 'var(--accent-light)', bg: 'var(--accent-glow)' },
          { label: 'Pending Payment', value: formatCurrency(totalPending), color: 'var(--warning)', bg: 'var(--warning-bg)' },
          { label: 'Paid', value: formatCurrency(totalPaid), color: 'var(--success)', bg: 'var(--success-bg)' },
        ].map(s => (
          <div key={s.label} className="card">
            <div style={{ fontSize: 11, color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.8px', fontWeight: 600, marginBottom: 8 }}>{s.label}</div>
            <div style={{ fontSize: 24, fontWeight: 800, color: s.color }}>{s.value}</div>
          </div>
        ))}
      </div>

      <div className="search-bar">
        <div className="search-input-wrap" style={{ flex: 2 }}>
          <Search size={16} />
          <input className="search-input" placeholder="Search by invoice number, vendor or PO…" value={search} onChange={e => setSearch(e.target.value)} />
        </div>
        <select className="filter-select" value={statusFilter} onChange={e => setStatusFilter(e.target.value)}>
          {['all', 'pending', 'paid', 'overdue', 'cancelled'].map(s => (
            <option key={s} value={s}>{s === 'all' ? 'All Statuses' : s.charAt(0).toUpperCase() + s.slice(1)}</option>
          ))}
        </select>
      </div>

      <div className="table-wrap">
        <table>
          <thead>
            <tr>
              <th>Invoice #</th>
              <th>PO Reference</th>
              <th>Vendor</th>
              <th>Issued Date</th>
              <th>Due Date</th>
              <th>Subtotal</th>
              <th>GST</th>
              <th>Total</th>
              <th>Status</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            {filtered.map(inv => {
              const gst = (inv.cgst || 0) + (inv.sgst || 0) + (inv.igst || 0);
              return (
                <tr key={inv.id} style={{ cursor: 'pointer' }} onClick={() => navigate(`/invoices/${inv.id}`)}>
                  <td>
                    <span style={{ fontFamily: 'monospace', fontSize: 13, color: 'var(--accent-light)', fontWeight: 600 }}>{inv.invoiceNumber}</span>
                  </td>
                  <td style={{ fontFamily: 'monospace', fontSize: 12, color: 'var(--text-muted)' }}>{inv.poNumber}</td>
                  <td className="td-primary">{inv.vendorName}</td>
                  <td>{formatDate(inv.issuedDate)}</td>
                  <td style={{ color: inv.status === 'pending' && new Date(inv.dueDate) < new Date() ? 'var(--danger)' : 'inherit' }}>
                    {formatDate(inv.dueDate)}
                  </td>
                  <td>{formatCurrency(inv.subtotal)}</td>
                  <td>{formatCurrency(gst)}</td>
                  <td style={{ fontWeight: 800, fontSize: 15, color: 'var(--text-primary)' }}>{formatCurrency(inv.total)}</td>
                  <td><Badge status={inv.status} /></td>
                  <td>
                    <button className="btn btn-ghost btn-sm" onClick={e => { e.stopPropagation(); navigate(`/invoices/${inv.id}`); }}>
                      View
                    </button>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {filtered.length === 0 && (
        <div className="empty-state">
          <Receipt size={40} style={{ margin: '0 auto 12px', opacity: 0.3 }} />
          <h3>No invoices found</h3>
          <p>Generate invoices from delivered Purchase Orders</p>
        </div>
      )}
    </div>
  );
}
