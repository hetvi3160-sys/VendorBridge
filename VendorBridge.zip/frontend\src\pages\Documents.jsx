import { useState } from 'react';
import { useAppData } from '../context/AppDataContext';
import { formatCurrency, formatDate } from '../utils/helpers';
import { Search, FolderOpen, Download, Filter } from 'lucide-react';

export default function Documents() {
  const { invoices, purchaseOrders } = useAppData();
  const [search, setSearch] = useState('');
  const [typeFilter, setTypeFilter] = useState('all');

  // Synthesize documents list from invoices and POs
  const documents = [
    ...invoices.map(i => ({ id: `doc-inv-${i.id}`, type: 'Invoice', title: i.invoiceNumber, ref: i.poNumber, vendor: i.vendorName, date: i.issuedDate, size: '42 KB' })),
    ...purchaseOrders.map(p => ({ id: `doc-po-${p.id}`, type: 'Purchase Order', title: p.poNumber, ref: p.rfqId, vendor: p.vendorName, date: p.createdAt, size: '38 KB' })),
  ].sort((a, b) => new Date(b.date) - new Date(a.date));

  const filtered = documents.filter(d => {
    const matchSearch = d.title.toLowerCase().includes(search.toLowerCase()) || d.vendor.toLowerCase().includes(search.toLowerCase());
    const matchType = typeFilter === 'all' || d.type === typeFilter;
    return matchSearch && matchType;
  });

  return (
    <div className="animate-fade">
      <div className="page-header">
        <div>
          <h1 className="page-title">Document Management</h1>
          <p className="page-subtitle">Centralized hub for all procurement documents</p>
        </div>
      </div>

      <div className="search-bar">
        <div className="search-input-wrap" style={{ flex: 2 }}>
          <Search size={16} />
          <input className="search-input" placeholder="Search by document number or vendor…" value={search} onChange={e => setSearch(e.target.value)} />
        </div>
        <select className="filter-select" value={typeFilter} onChange={e => setTypeFilter(e.target.value)}>
          <option value="all">All Document Types</option>
          <option value="Invoice">Invoices</option>
          <option value="Purchase Order">Purchase Orders</option>
        </select>
      </div>

      <div className="table-wrap">
        <table>
          <thead>
            <tr>
              <th>Document</th>
              <th>Type</th>
              <th>Vendor</th>
              <th>Reference</th>
              <th>Date</th>
              <th>Size</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {filtered.map(doc => (
              <tr key={doc.id}>
                <td style={{ fontWeight: 600, color: 'var(--text-primary)' }}>{doc.title}</td>
                <td>
                  <span style={{ padding: '3px 8px', borderRadius: 6, background: 'var(--bg-elevated)', fontSize: 12, border: '1px solid var(--border)' }}>
                    {doc.type}
                  </span>
                </td>
                <td className="td-primary">{doc.vendor}</td>
                <td style={{ fontSize: 12, color: 'var(--text-muted)' }}>{doc.ref}</td>
                <td>{formatDate(doc.date)}</td>
                <td style={{ fontSize: 12, color: 'var(--text-muted)' }}>{doc.size}</td>
                <td>
                  <button className="btn btn-ghost btn-sm">
                    <Download size={14} />
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {filtered.length === 0 && (
        <div className="empty-state">
          <FolderOpen size={40} style={{ margin: '0 auto 12px', opacity: 0.3 }} />
          <h3>No documents found</h3>
        </div>
      )}
    </div>
  );
}
