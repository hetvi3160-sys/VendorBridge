import { useState } from 'react';
import { useAppData } from '../context/AppDataContext';
import ActivityChart from '../components/charts/ActivityChart';
import VendorDonut from '../components/charts/VendorDonut';
import PerformanceRadar from '../components/charts/PerformanceRadar';
import Badge from '../components/Badge';
import { formatCurrency, formatDate, timeAgo } from '../utils/helpers';
import { BarChart3, TrendingUp, DollarSign, Building2, ShoppingCart, FileText, Download, Calendar } from 'lucide-react';

const DATE_RANGES = ['Last 30 Days', 'Last 90 Days', 'Last 6 Months', 'This Year'];

export default function Reports() {
  const { auditLogs, purchaseOrders, vendors, rfqs, invoices, approvals } = useAppData();
  const [dateRange, setDateRange] = useState('Last 90 Days');

  const totalSpend     = purchaseOrders.reduce((s, p) => s + (p.total || 0), 0);
  const activeVendors  = vendors.filter(v => v.status === 'active').length;
  const approvedPOs    = purchaseOrders.filter(p => p.status === 'approved' || p.status === 'delivered').length;
  const pendingApprv   = approvals.filter(a => a.status === 'pending').length;
  const avgPOValue     = purchaseOrders.length ? totalSpend / purchaseOrders.length : 0;
  const totalRFQs      = rfqs.length;

  // Top vendors by spend
  const vendorSpend = purchaseOrders.reduce((acc, po) => {
    acc[po.vendorName] = (acc[po.vendorName] || 0) + (po.total || 0);
    return acc;
  }, {});
  const topVendors = Object.entries(vendorSpend)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 5);

  // PO status breakdown
  const poStatusCount = purchaseOrders.reduce((acc, po) => {
    acc[po.status] = (acc[po.status] || 0) + 1;
    return acc;
  }, {});

  const kpis = [
    { label: 'Total Spend',      value: formatCurrency(totalSpend), icon: <DollarSign size={20} />, color: 'var(--accent)',  sub: `${purchaseOrders.length} purchase orders` },
    { label: 'Active Vendors',   value: activeVendors,              icon: <Building2 size={20} />,  color: 'var(--cyan)',    sub: `${vendors.length} total registered` },
    { label: 'Approved POs',     value: approvedPOs,                icon: <ShoppingCart size={20} />,color: 'var(--success)', sub: `Avg ${formatCurrency(avgPOValue)}` },
    { label: 'Open RFQs',        value: rfqs.filter(r => r.status === 'active').length, icon: <FileText size={20} />, color: 'var(--warning)', sub: `${totalRFQs} total` },
  ];

  return (
    <div className="animate-fade">
      {/* Header */}
      <div className="page-header">
        <div>
          <h1 className="page-title">Reports &amp; Analytics</h1>
          <p className="page-subtitle">Procurement insights, spend analytics and audit trails</p>
        </div>
        <div style={{ display: 'flex', gap: 10, alignItems: 'center' }}>
          {/* Date Range Filter */}
          <div style={{ display: 'flex', gap: 6 }}>
            {DATE_RANGES.map(r => (
              <button
                key={r}
                className={`btn btn-sm ${dateRange === r ? 'btn-primary' : 'btn-ghost'}`}
                onClick={() => setDateRange(r)}
              >
                {r}
              </button>
            ))}
          </div>
          <button className="btn btn-secondary btn-sm">
            <Download size={14} /> Export PDF
          </button>
        </div>
      </div>

      {/* KPI Cards */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 18, marginBottom: 28 }}>
        {kpis.map(k => (
          <div key={k.label} className="card" style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
            <div style={{ width: 48, height: 48, borderRadius: 12, background: `${k.color}18`, color: k.color, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
              {k.icon}
            </div>
            <div>
              <div style={{ fontSize: 11, color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.8px', fontWeight: 600, marginBottom: 4 }}>{k.label}</div>
              <div style={{ fontSize: 22, fontWeight: 800, color: 'var(--text-primary)', lineHeight: 1 }}>{k.value}</div>
              <div style={{ fontSize: 11, color: 'var(--text-muted)', marginTop: 4 }}>{k.sub}</div>
            </div>
          </div>
        ))}
      </div>

      {/* Charts Row 1 */}
      <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr', gap: 20, marginBottom: 20 }}>
        <div className="card">
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
            <div className="card-title">Procurement Spend Over Time</div>
            <span style={{ fontSize: 12, color: 'var(--text-muted)' }}>{dateRange}</span>
          </div>
          <div className="chart-container" style={{ height: 240 }}>
            <ActivityChart type="bar" />
          </div>
        </div>
        <div className="card">
          <div className="card-title" style={{ marginBottom: 16 }}>Vendor Status Distribution</div>
          <div className="chart-container" style={{ height: 240 }}>
            <VendorDonut />
          </div>
        </div>
      </div>

      {/* Charts Row 2 */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 20, marginBottom: 20 }}>
        <div className="card">
          <div className="card-title" style={{ marginBottom: 16 }}>Vendor Performance Radar</div>
          <div className="chart-container" style={{ height: 260 }}>
            <PerformanceRadar />
          </div>
        </div>

        {/* Top Vendors by Spend */}
        <div className="card">
          <div className="card-title" style={{ marginBottom: 16 }}>
            <TrendingUp size={16} style={{ display: 'inline', marginRight: 6 }} />Top Vendors by Spend
          </div>
          {topVendors.length === 0 ? (
            <div style={{ color: 'var(--text-muted)', fontSize: 13, padding: 20, textAlign: 'center' }}>No spend data yet.</div>
          ) : (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
              {topVendors.map(([name, spend], i) => {
                const maxSpend = topVendors[0][1];
                const pct = Math.round((spend / maxSpend) * 100);
                return (
                  <div key={name}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 6 }}>
                      <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                        <div style={{ width: 24, height: 24, borderRadius: 6, background: 'linear-gradient(135deg, var(--accent), var(--cyan))', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 11, fontWeight: 700, color: 'white' }}>
                          {i + 1}
                        </div>
                        <span style={{ fontSize: 13, fontWeight: 600, color: 'var(--text-primary)' }}>{name}</span>
                      </div>
                      <span style={{ fontSize: 13, fontWeight: 700, color: 'var(--accent-light)' }}>{formatCurrency(spend)}</span>
                    </div>
                    <div style={{ height: 6, borderRadius: 3, background: 'var(--bg-elevated)', overflow: 'hidden' }}>
                      <div style={{ height: '100%', width: `${pct}%`, background: `linear-gradient(90deg, var(--accent), var(--cyan))`, borderRadius: 3, transition: 'width 0.5s ease' }} />
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>

      {/* PO Status Breakdown + Audit Log */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 2fr', gap: 20 }}>
        {/* PO Status Breakdown */}
        <div className="card">
          <div className="card-title" style={{ marginBottom: 16 }}>Purchase Order Status</div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
            {Object.entries(poStatusCount).map(([status, count]) => (
              <div key={status} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '10px 14px', borderRadius: 8, background: 'var(--bg-elevated)', border: '1px solid var(--border)' }}>
                <Badge status={status} />
                <span style={{ fontWeight: 700, fontSize: 18, color: 'var(--text-primary)' }}>{count}</span>
              </div>
            ))}
            {Object.keys(poStatusCount).length === 0 && (
              <div style={{ color: 'var(--text-muted)', fontSize: 13, textAlign: 'center', padding: 20 }}>No POs yet.</div>
            )}
          </div>

          {/* Pending approvals indicator */}
          {pendingApprv > 0 && (
            <div style={{ marginTop: 16, padding: '12px 14px', borderRadius: 8, background: 'rgba(245,158,11,0.1)', border: '1px solid rgba(245,158,11,0.3)', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <span style={{ fontSize: 13, color: 'var(--warning)', fontWeight: 600 }}>Pending Approvals</span>
              <span style={{ fontSize: 20, fontWeight: 800, color: 'var(--warning)' }}>{pendingApprv}</span>
            </div>
          )}
        </div>

        {/* Audit Log */}
        <div className="card">
          <div className="card-title" style={{ marginBottom: 16 }}>
            <BarChart3 size={16} style={{ display: 'inline', marginRight: 6 }} />Recent Audit Log
          </div>
          <div style={{ maxHeight: 320, overflowY: 'auto' }}>
            {auditLogs.length === 0 ? (
              <div style={{ color: 'var(--text-muted)', fontSize: 13, textAlign: 'center', padding: 30 }}>No audit logs yet.</div>
            ) : (
              auditLogs.slice(0, 20).map((log, i) => (
                <div key={log.id} style={{ display: 'flex', alignItems: 'flex-start', gap: 12, padding: '12px 0', borderBottom: i < auditLogs.length - 1 ? '1px solid var(--border)' : 'none' }}>
                  <div style={{ width: 34, height: 34, borderRadius: '50%', background: 'linear-gradient(135deg, var(--accent), var(--cyan))', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 12, fontWeight: 700, color: 'white', flexShrink: 0 }}>
                    {log.userName?.slice(0, 2).toUpperCase()}
                  </div>
                  <div style={{ flex: 1 }}>
                    <div style={{ fontSize: 13, color: 'var(--text-primary)' }}>
                      <span style={{ fontWeight: 600 }}>{log.userName}</span>{' '}
                      <span style={{ color: 'var(--text-secondary)' }}>{log.action}</span>{' '}
                      <span style={{ color: 'var(--accent-light)', fontWeight: 500 }}>{log.entityTitle}</span>
                    </div>
                    <div style={{ fontSize: 11, color: 'var(--text-muted)', marginTop: 3 }}>
                      {formatDate(log.timestamp)} · {log.ipAddress || 'N/A'}
                    </div>
                  </div>
                  <span style={{ fontSize: 11, color: 'var(--text-muted)', whiteSpace: 'nowrap' }}>{timeAgo(log.timestamp)}</span>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
