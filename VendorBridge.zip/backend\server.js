const express = require('express');
const cors = require('cors');
const jwt = require('jsonwebtoken');
const { initDB, db } = require('./db');

const app = express();
const PORT = process.env.PORT || 3000;
const JWT_SECRET = process.env.JWT_SECRET || 'vendorbridge_secret_2026';

app.use(cors());
app.use(express.json());

initDB();

// ─── JWT Middleware ──────────────────────────────────────────────────────────
const authenticate = (req, res, next) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];
  if (!token) return res.status(401).json({ error: 'No token provided' });
  jwt.verify(token, JWT_SECRET, (err, decoded) => {
    if (err) return res.status(403).json({ error: 'Invalid or expired token' });
    req.user = decoded;
    next();
  });
};

// ═══════════════════════════════════════════════════════════════════════════════
// AUTH ROUTES
// ═══════════════════════════════════════════════════════════════════════════════

app.post('/api/auth/login', (req, res) => {
  const { email, password } = req.body;
  if (!email || !password) return res.status(400).json({ error: 'Email and password required' });
  try {
    const user = db.prepare('SELECT * FROM users WHERE email = ?').get(email);
    if (!user || user.password !== password) {
      return res.status(401).json({ error: 'Invalid email or password' });
    }
    const token = jwt.sign({ id: user.id, role: user.role, email: user.email }, JWT_SECRET, { expiresIn: '24h' });
    const { password: _, ...safeUser } = user;
    res.json({ token, user: safeUser });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.post('/api/auth/register', (req, res) => {
  const { name, email, password, role } = req.body;
  if (!name || !email || !password || !role) return res.status(400).json({ error: 'All fields required' });
  try {
    const existing = db.prepare('SELECT id FROM users WHERE email = ?').get(email);
    if (existing) return res.status(409).json({ error: 'Email already registered' });
    const id = `u${Date.now()}`;
    const avatar = name.slice(0, 2).toUpperCase();
    const roleLabels = { admin: 'Administration', procurement: 'Procurement', vendor: 'External Vendor', manager: 'Operations Management' };
    db.prepare('INSERT INTO users (id, name, email, password, role, avatar, department) VALUES (?, ?, ?, ?, ?, ?, ?)').run(id, name, email, password, role, avatar, roleLabels[role] || role);
    const token = jwt.sign({ id, role, email }, JWT_SECRET, { expiresIn: '24h' });
    res.status(201).json({ token, user: { id, name, email, role, avatar, department: roleLabels[role] || role } });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.get('/api/auth/me', authenticate, (req, res) => {
  try {
    const user = db.prepare('SELECT id, name, email, role, avatar, department FROM users WHERE id = ?').get(req.user.id);
    if (!user) return res.status(404).json({ error: 'User not found' });
    res.json(user);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// ═══════════════════════════════════════════════════════════════════════════════
// VENDOR ROUTES
// ═══════════════════════════════════════════════════════════════════════════════

app.get('/api/vendors', authenticate, (req, res) => {
  try {
    res.json(db.prepare('SELECT * FROM vendors').all());
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.get('/api/vendors/:id', authenticate, (req, res) => {
  try {
    const vendor = db.prepare('SELECT * FROM vendors WHERE id = ?').get(req.params.id);
    if (!vendor) return res.status(404).json({ error: 'Vendor not found' });
    res.json(vendor);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.post('/api/vendors', authenticate, (req, res) => {
  const v = req.body;
  const id = v.id || `v${Date.now()}`;
  try {
    db.prepare('INSERT INTO vendors (id, name, gstNumber, category, contactPerson, email, phone, status, performanceScore, city, state, bankAccount, joiningDate, totalOrders, totalValue) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)').run(id, v.name, v.gstNumber, v.category, v.contactPerson, v.email, v.phone, v.status || 'pending', v.performanceScore || 0, v.city, v.state, v.bankAccount, v.joiningDate || new Date().toISOString().split('T')[0], 0, 0);
    res.status(201).json({ id, ...v });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.put('/api/vendors/:id', authenticate, (req, res) => {
  const v = req.body;
  try {
    db.prepare('UPDATE vendors SET name=?, gstNumber=?, category=?, contactPerson=?, email=?, phone=?, status=?, performanceScore=?, city=?, state=?, bankAccount=? WHERE id=?').run(v.name, v.gstNumber, v.category, v.contactPerson, v.email, v.phone, v.status, v.performanceScore, v.city, v.state, v.bankAccount, req.params.id);
    res.json({ id: req.params.id, ...v });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// ═══════════════════════════════════════════════════════════════════════════════
// RFQ ROUTES
// ═══════════════════════════════════════════════════════════════════════════════

const enrichRfq = (rfq) => {
  const products = db.prepare('SELECT name, quantity, unit FROM rfq_items WHERE rfqId = ?').all(rfq.id);
  const vendors = db.prepare('SELECT vendorId FROM rfq_vendors WHERE rfqId = ?').all(rfq.id).map(r => r.vendorId);
  return { ...rfq, products, vendors };
};

app.get('/api/rfqs', authenticate, (req, res) => {
  try {
    const rfqs = db.prepare('SELECT * FROM rfqs').all().map(enrichRfq);
    res.json(rfqs);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.get('/api/rfqs/:id', authenticate, (req, res) => {
  try {
    const rfq = db.prepare('SELECT * FROM rfqs WHERE id = ?').get(req.params.id);
    if (!rfq) return res.status(404).json({ error: 'RFQ not found' });
    res.json(enrichRfq(rfq));
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.post('/api/rfqs', authenticate, (req, res) => {
  const { rfqNumber, title, description, deadline, status, budget, products, vendors } = req.body;
  const id = `rfq${Date.now()}`;
  try {
    db.prepare('INSERT INTO rfqs (id, rfqNumber, title, description, deadline, status, createdBy, createdAt, budget) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)').run(id, rfqNumber, title, description, deadline, status || 'draft', req.user.id, new Date().toISOString().split('T')[0], budget || 0);
    if (products) {
      const ins = db.prepare('INSERT INTO rfq_items (rfqId, name, quantity, unit) VALUES (?, ?, ?, ?)');
      for (const p of products) ins.run(id, p.name, p.quantity, p.unit);
    }
    if (vendors) {
      const ins = db.prepare('INSERT INTO rfq_vendors (rfqId, vendorId) VALUES (?, ?)');
      for (const vId of vendors) ins.run(id, vId);
    }
    res.status(201).json(enrichRfq(db.prepare('SELECT * FROM rfqs WHERE id = ?').get(id)));
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.put('/api/rfqs/:id', authenticate, (req, res) => {
  const r = req.body;
  try {
    db.prepare('UPDATE rfqs SET title=?, description=?, deadline=?, status=?, budget=? WHERE id=?').run(r.title, r.description, r.deadline, r.status, r.budget, req.params.id);
    res.json(enrichRfq(db.prepare('SELECT * FROM rfqs WHERE id = ?').get(req.params.id)));
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// ═══════════════════════════════════════════════════════════════════════════════
// QUOTATION ROUTES
// ═══════════════════════════════════════════════════════════════════════════════

const enrichQuotation = (q) => {
  const unitPrices = db.prepare('SELECT product, unitPrice, quantity FROM quotation_items WHERE quotationId = ?').all(q.id);
  return { ...q, unitPrices };
};

app.get('/api/quotations', authenticate, (req, res) => {
  try {
    res.json(db.prepare('SELECT * FROM quotations').all().map(enrichQuotation));
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.post('/api/quotations', authenticate, (req, res) => {
  const { rfqId, vendorId, deliveryDays, totalAmount, status, validity, notes, unitPrices } = req.body;
  const id = `q${Date.now()}`;
  try {
    db.prepare('INSERT INTO quotations (id, rfqId, vendorId, deliveryDays, totalAmount, status, submittedAt, validity, notes) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)').run(id, rfqId, vendorId, deliveryDays, totalAmount, status || 'pending', new Date().toISOString().split('T')[0], validity || 30, notes);
    if (unitPrices) {
      const ins = db.prepare('INSERT INTO quotation_items (quotationId, product, unitPrice, quantity) VALUES (?, ?, ?, ?)');
      for (const up of unitPrices) ins.run(id, up.product, up.unitPrice, up.quantity);
    }
    res.status(201).json(enrichQuotation(db.prepare('SELECT * FROM quotations WHERE id = ?').get(id)));
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.put('/api/quotations/:id', authenticate, (req, res) => {
  const q = req.body;
  try {
    db.prepare('UPDATE quotations SET status=?, notes=? WHERE id=?').run(q.status, q.notes, req.params.id);
    res.json(enrichQuotation(db.prepare('SELECT * FROM quotations WHERE id = ?').get(req.params.id)));
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// ═══════════════════════════════════════════════════════════════════════════════
// APPROVAL ROUTES
// ═══════════════════════════════════════════════════════════════════════════════

app.get('/api/approvals', authenticate, (req, res) => {
  try {
    res.json(db.prepare('SELECT * FROM approvals').all());
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.post('/api/approvals', authenticate, (req, res) => {
  const a = req.body;
  const id = a.id || `ap${Date.now()}`;
  try {
    db.prepare('INSERT INTO approvals (id, type, refId, refTitle, requestedBy, requestedByName, amount, status, remarks, createdAt, resolvedAt, resolvedBy) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)').run(id, a.type, a.refId, a.refTitle, a.requestedBy, a.requestedByName, a.amount, a.status || 'pending', a.remarks, a.createdAt || new Date().toISOString().split('T')[0], null, null);
    res.status(201).json({ id, ...a });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.put('/api/approvals/:id', authenticate, (req, res) => {
  const a = req.body;
  try {
    db.prepare('UPDATE approvals SET status=?, remarks=?, resolvedAt=?, resolvedBy=? WHERE id=?').run(a.status, a.remarks, new Date().toISOString().split('T')[0], req.user.id, req.params.id);
    res.json(db.prepare('SELECT * FROM approvals WHERE id = ?').get(req.params.id));
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// ═══════════════════════════════════════════════════════════════════════════════
// PURCHASE ORDER ROUTES
// ═══════════════════════════════════════════════════════════════════════════════

const enrichPO = (po) => {
  const lineItems = db.prepare('SELECT description, quantity, unitPrice, amount FROM po_line_items WHERE poId = ?').all(po.id);
  return { ...po, lineItems };
};

app.get('/api/purchase-orders', authenticate, (req, res) => {
  try {
    res.json(db.prepare('SELECT * FROM purchase_orders').all().map(enrichPO));
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.get('/api/purchase-orders/:id', authenticate, (req, res) => {
  try {
    const po = db.prepare('SELECT * FROM purchase_orders WHERE id = ?').get(req.params.id);
    if (!po) return res.status(404).json({ error: 'PO not found' });
    res.json(enrichPO(po));
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.post('/api/purchase-orders', authenticate, (req, res) => {
  const po = req.body;
  const id = po.id || `po${Date.now()}`;
  try {
    db.prepare('INSERT INTO purchase_orders (id, poNumber, rfqId, quotationId, vendorId, vendorName, subtotal, cgst, sgst, igst, total, status, deliveryDate, createdAt, createdBy, terms) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)').run(id, po.poNumber, po.rfqId, po.quotationId, po.vendorId, po.vendorName, po.subtotal, po.cgst, po.sgst, po.igst, po.total, po.status || 'confirmed', po.deliveryDate, po.createdAt || new Date().toISOString().split('T')[0], req.user.id, po.terms || 'Net 30');
    if (po.lineItems) {
      const ins = db.prepare('INSERT INTO po_line_items (poId, description, quantity, unitPrice, amount) VALUES (?, ?, ?, ?, ?)');
      for (const item of po.lineItems) ins.run(id, item.description, item.quantity, item.unitPrice, item.amount);
    }
    res.status(201).json(enrichPO(db.prepare('SELECT * FROM purchase_orders WHERE id = ?').get(id)));
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.put('/api/purchase-orders/:id', authenticate, (req, res) => {
  const po = req.body;
  try {
    db.prepare('UPDATE purchase_orders SET status=? WHERE id=?').run(po.status, req.params.id);
    res.json(enrichPO(db.prepare('SELECT * FROM purchase_orders WHERE id = ?').get(req.params.id)));
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// ═══════════════════════════════════════════════════════════════════════════════
// INVOICE ROUTES
// ═══════════════════════════════════════════════════════════════════════════════

const enrichInvoice = (inv) => {
  const lineItems = db.prepare('SELECT description, quantity, unitPrice, amount FROM invoice_line_items WHERE invoiceId = ?').all(inv.id);
  return { ...inv, lineItems };
};

app.get('/api/invoices', authenticate, (req, res) => {
  try {
    res.json(db.prepare('SELECT * FROM invoices').all().map(enrichInvoice));
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.get('/api/invoices/:id', authenticate, (req, res) => {
  try {
    const inv = db.prepare('SELECT * FROM invoices WHERE id = ?').get(req.params.id);
    if (!inv) return res.status(404).json({ error: 'Invoice not found' });
    res.json(enrichInvoice(inv));
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.post('/api/invoices', authenticate, (req, res) => {
  const inv = req.body;
  const id = inv.id || `inv${Date.now()}`;
  try {
    db.prepare('INSERT INTO invoices (id, invoiceNumber, poId, poNumber, vendorId, vendorName, subtotal, cgst, sgst, igst, total, status, dueDate, issuedDate, paidDate) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)').run(id, inv.invoiceNumber, inv.poId, inv.poNumber, inv.vendorId, inv.vendorName, inv.subtotal, inv.cgst, inv.sgst, inv.igst, inv.total, inv.status || 'pending', inv.dueDate, inv.issuedDate || new Date().toISOString().split('T')[0], inv.paidDate);
    if (inv.lineItems) {
      const ins = db.prepare('INSERT INTO invoice_line_items (invoiceId, description, quantity, unitPrice, amount) VALUES (?, ?, ?, ?, ?)');
      for (const item of inv.lineItems) ins.run(id, item.description, item.quantity, item.unitPrice, item.amount);
    }
    res.status(201).json(enrichInvoice(db.prepare('SELECT * FROM invoices WHERE id = ?').get(id)));
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.put('/api/invoices/:id', authenticate, (req, res) => {
  const inv = req.body;
  try {
    db.prepare('UPDATE invoices SET status=?, paidDate=? WHERE id=?').run(inv.status, inv.paidDate, req.params.id);
    res.json(enrichInvoice(db.prepare('SELECT * FROM invoices WHERE id = ?').get(req.params.id)));
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// ═══════════════════════════════════════════════════════════════════════════════
// AUDIT LOG ROUTES
// ═══════════════════════════════════════════════════════════════════════════════

app.get('/api/audit-logs', authenticate, (req, res) => {
  try {
    res.json(db.prepare('SELECT * FROM audit_logs ORDER BY timestamp DESC').all());
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.post('/api/audit-logs', authenticate, (req, res) => {
  const log = req.body;
  const id = `al${Date.now()}`;
  try {
    db.prepare('INSERT INTO audit_logs (id, userId, userName, action, entityType, entityId, entityTitle, timestamp, ipAddress) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)').run(id, log.userId, log.userName, log.action, log.entityType, log.entityId, log.entityTitle, new Date().toISOString(), log.ipAddress || '0.0.0.0');
    res.status(201).json({ id });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// ═══════════════════════════════════════════════════════════════════════════════
// ANALYTICS / DASHBOARD
// ═══════════════════════════════════════════════════════════════════════════════

app.get('/api/analytics/dashboard', authenticate, (req, res) => {
  try {
    const activeVendors = db.prepare("SELECT COUNT(*) as count FROM vendors WHERE status = 'active'").get().count;
    const pendingApprovals = db.prepare("SELECT COUNT(*) as count FROM approvals WHERE status = 'pending'").get().count;
    const activeRfqs = db.prepare("SELECT COUNT(*) as count FROM rfqs WHERE status = 'active'").get().count;
    const totalSpend = db.prepare("SELECT COALESCE(SUM(total), 0) as total FROM purchase_orders").get().total;
    res.json({ activeVendors, pendingApprovals, activeRfqs, totalSpend });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// Health check
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

// ─── Start ───────────────────────────────────────────────────────────────────
app.listen(PORT, () => {
  console.log(`\n  ⬡ VendorBridge API Server`);
  console.log(`  → Running on http://localhost:${PORT}`);
  console.log(`  → Environment: ${process.env.NODE_ENV || 'development'}\n`);
});
