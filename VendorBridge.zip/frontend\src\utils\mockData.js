// ─── Users ───────────────────────────────────────────────────────────────────
export const users = [
  { id: 'u1', name: 'Arjun Mehta',       email: 'admin@vendorbridge.com',       password: 'admin123',   role: 'admin',       avatar: 'AM', department: 'Administration' },
  { id: 'u2', name: 'Priya Sharma',      email: 'procurement@vendorbridge.com', password: 'proc123',    role: 'procurement', avatar: 'PS', department: 'Procurement' },
  { id: 'u3', name: 'Ravi Supplies Co.', email: 'vendor@vendorbridge.com',      password: 'vendor123',  role: 'vendor',      avatar: 'RS', department: 'External Vendor' },
  { id: 'u4', name: 'Sunita Kapoor',     email: 'manager@vendorbridge.com',     password: 'manager123', role: 'manager',     avatar: 'SK', department: 'Operations Management' },
];

// ─── Vendors ─────────────────────────────────────────────────────────────────
export const vendors = [
  { id: 'v1', name: 'Ravi Supplies Co.', gstNumber: '27AABCU9603R1ZV', category: 'Office Supplies', contactPerson: 'Ravi Kumar', email: 'ravi@ravisupplies.com', phone: '+91 98765 43210', status: 'active', performanceScore: 92, city: 'Mumbai', state: 'Maharashtra', bankAccount: 'HDFC-1234567890', joiningDate: '2023-03-15', totalOrders: 47, totalValue: 101800 },
  { id: 'v2', name: 'TechParts India Pvt Ltd', gstNumber: '29AABCT1234R1ZM', category: 'IT Equipment', contactPerson: 'Deepak Nair', email: 'deepak@techparts.in', phone: '+91 91234 56789', status: 'active', performanceScore: 87, city: 'Bengaluru', state: 'Karnataka', bankAccount: 'SBI-9876543210', joiningDate: '2023-06-20', totalOrders: 31, totalValue: 183100 },
  { id: 'v3', name: 'GreenBuild Materials', gstNumber: '24AACFG5678R1ZA', category: 'Construction', contactPerson: 'Anjali Patel', email: 'anjali@greenbuild.com', phone: '+91 87654 32109', status: 'pending', performanceScore: 0, city: 'Ahmedabad', state: 'Gujarat', bankAccount: 'ICICI-1122334455', joiningDate: '2024-01-10', totalOrders: 0, totalValue: 0 },
  { id: 'v4', name: 'SwiftLogix Transport', gstNumber: '06AABCS9900R1ZQ', category: 'Logistics', contactPerson: 'Manish Rao', email: 'manish@swiftlogix.com', phone: '+91 77777 88888', status: 'active', performanceScore: 79, city: 'Gurugram', state: 'Haryana', bankAccount: 'Axis-5566778899', joiningDate: '2022-11-05', totalOrders: 88, totalValue: 61400 },
  { id: 'v5', name: 'PrimePack Packaging', gstNumber: '33AABCP2222R1ZB', category: 'Packaging', contactPerson: 'Sudha Krishnan', email: 'sudha@primepack.com', phone: '+91 66666 55555', status: 'inactive', performanceScore: 61, city: 'Chennai', state: 'Tamil Nadu', bankAccount: 'Kotak-4433221100', joiningDate: '2023-08-22', totalOrders: 15, totalValue: 8600 },
  { id: 'v6', name: 'NovaTech Solutions', gstNumber: '07AABCN8877R1ZN', category: 'IT Equipment', contactPerson: 'Anil Gupta', email: 'anil@novatech.in', phone: '+91 99988 77766', status: 'blacklisted', performanceScore: 22, city: 'Delhi', state: 'Delhi', bankAccount: 'PNB-7788990011', joiningDate: '2022-05-01', totalOrders: 5, totalValue: 3000 },
];

// ─── RFQs ─────────────────────────────────────────────────────────────────────
export const rfqs = [
  { id: 'rfq1', rfqNumber: 'RFQ-2024-0001', title: 'Office Stationery Q2 2024', description: 'Bulk procurement of stationery items for all departments for Q2.', products: [{ name: 'A4 Paper Reams', quantity: 500, unit: 'Ream' }, { name: 'Ball Pens', quantity: 1000, unit: 'Piece' }, { name: 'Staplers', quantity: 50, unit: 'Piece' }], deadline: '2024-07-15', vendors: ['v1', 'v5'], status: 'closed', createdBy: 'u2', createdAt: '2024-06-01', budget: 1800 },
  { id: 'rfq2', rfqNumber: 'RFQ-2024-0002', title: 'Laptop Procurement for Engineering Team', description: '15 high-performance laptops for the engineering team expansion.', products: [{ name: 'Laptop 16GB RAM', quantity: 15, unit: 'Unit' }, { name: 'Laptop Bags', quantity: 15, unit: 'Unit' }], deadline: '2024-07-30', vendors: ['v2', 'v6'], status: 'active', createdBy: 'u2', createdAt: '2024-06-10', budget: 18000 },
  { id: 'rfq3', rfqNumber: 'RFQ-2024-0003', title: 'Q3 Packaging Material Supply', description: 'Packaging boxes, bubble wrap and tape for warehouse operations.', products: [{ name: 'Cardboard Boxes (L)', quantity: 2000, unit: 'Piece' }, { name: 'Bubble Wrap Roll', quantity: 100, unit: 'Roll' }, { name: 'Packing Tape', quantity: 500, unit: 'Roll' }], deadline: '2024-08-10', vendors: ['v5'], status: 'draft', createdBy: 'u2', createdAt: '2024-06-20', budget: 2400 },
  { id: 'rfq4', rfqNumber: 'RFQ-2024-0004', title: 'Office Furniture Upgrade', description: 'Ergonomic chairs and standing desks for new office floor.', products: [{ name: 'Ergonomic Chair', quantity: 30, unit: 'Unit' }, { name: 'Standing Desk', quantity: 10, unit: 'Unit' }], deadline: '2024-08-20', vendors: ['v1', 'v4'], status: 'active', createdBy: 'u1', createdAt: '2024-06-22', budget: 9600 },
];

// ─── Quotations ───────────────────────────────────────────────────────────────
export const quotations = [
  { id: 'q1', rfqId: 'rfq1', vendorId: 'v1', unitPrices: [{ product: 'A4 Paper Reams', unitPrice: 3.4, quantity: 500 }, { product: 'Ball Pens', unitPrice: 0.1, quantity: 1000 }, { product: 'Staplers', unitPrice: 2.65, quantity: 50 }], deliveryDays: 7, totalAmount: 1915, status: 'accepted', submittedAt: '2024-06-05', validity: 30, notes: 'Bulk discount applied. Delivery within 7 working days.' },
  { id: 'q2', rfqId: 'rfq1', vendorId: 'v5', unitPrices: [{ product: 'A4 Paper Reams', unitPrice: 3.55, quantity: 500 }, { product: 'Ball Pens', unitPrice: 0.11, quantity: 1000 }, { product: 'Staplers', unitPrice: 2.5, quantity: 50 }], deliveryDays: 10, totalAmount: 2012, status: 'rejected', submittedAt: '2024-06-06', validity: 30, notes: 'Standard pricing. GST included.' },
  { id: 'q3', rfqId: 'rfq2', vendorId: 'v2', unitPrices: [{ product: 'Laptop 16GB RAM', unitPrice: 1024, quantity: 15 }, { product: 'Laptop Bags', unitPrice: 14.4, quantity: 15 }], deliveryDays: 14, totalAmount: 15576, status: 'pending', submittedAt: '2024-06-15', validity: 21, notes: 'Includes 1 year onsite warranty. Brand: Dell Latitude.' },
  { id: 'q4', rfqId: 'rfq2', vendorId: 'v6', unitPrices: [{ product: 'Laptop 16GB RAM', unitPrice: 940, quantity: 15 }, { product: 'Laptop Bags', unitPrice: 10.8, quantity: 15 }], deliveryDays: 21, totalAmount: 14262, status: 'pending', submittedAt: '2024-06-16', validity: 21, notes: 'Refurbished units available at lower cost.' },
  { id: 'q5', rfqId: 'rfq4', vendorId: 'v1', unitPrices: [{ product: 'Ergonomic Chair', unitPrice: 150, quantity: 30 }, { product: 'Standing Desk', unitPrice: 421, quantity: 10 }], deliveryDays: 21, totalAmount: 8710, status: 'pending', submittedAt: '2024-06-25', validity: 15, notes: 'Premium ergonomic range. Color options available.' },
];

// ─── Approvals ────────────────────────────────────────────────────────────────
export const approvals = [
  { id: 'ap1', type: 'Quotation Acceptance', refId: 'q1', refTitle: 'Ravi Supplies — RFQ-2024-0001', requestedBy: 'u2', requestedByName: 'Priya Sharma', amount: 1915, status: 'approved', remarks: 'Best price, reliable vendor. Approved.', createdAt: '2024-06-07', resolvedAt: '2024-06-08', resolvedBy: 'u1' },
  { id: 'ap2', type: 'New Vendor Registration', refId: 'v3', refTitle: 'GreenBuild Materials — Vendor Onboarding', requestedBy: 'u1', requestedByName: 'Arjun Mehta', amount: 0, status: 'pending', remarks: '', createdAt: '2024-06-18', resolvedAt: null, resolvedBy: null },
  { id: 'ap3', type: 'Purchase Order', refId: 'po1', refTitle: 'PO-2024-0001 — Office Stationery', requestedBy: 'u2', requestedByName: 'Priya Sharma', amount: 1915, status: 'approved', remarks: 'Auto-approved after quotation acceptance.', createdAt: '2024-06-08', resolvedAt: '2024-06-08', resolvedBy: 'u1' },
  { id: 'ap4', type: 'Quotation Acceptance', refId: 'q3', refTitle: 'TechParts India — RFQ-2024-0002', requestedBy: 'u2', requestedByName: 'Priya Sharma', amount: 15576, status: 'pending', remarks: '', createdAt: '2024-06-20', resolvedAt: null, resolvedBy: null },
  { id: 'ap5', type: 'Budget Exception', refId: 'rfq4', refTitle: 'Office Furniture Upgrade — Exceeds Budget', requestedBy: 'u2', requestedByName: 'Priya Sharma', amount: 8710, status: 'rejected', remarks: 'Budget limit exceeded. Revisit vendor options.', createdAt: '2024-06-26', resolvedAt: '2024-06-27', resolvedBy: 'u1' },
];

// ─── Purchase Orders ──────────────────────────────────────────────────────────
export const purchaseOrders = [
  { id: 'po1', poNumber: 'PO-2024-0001', rfqId: 'rfq1', quotationId: 'q1', vendorId: 'v1', vendorName: 'Ravi Supplies Co.', lineItems: [{ description: 'A4 Paper Reams', quantity: 500, unitPrice: 3.4, amount: 1700 }, { description: 'Ball Pens', quantity: 1000, unitPrice: 0.1, amount: 100 }, { description: 'Staplers', quantity: 50, unitPrice: 2.65, amount: 132.5 }], subtotal: 1932.5, cgst: 173.9, sgst: 173.9, igst: 0, total: 2280.3, status: 'delivered', deliveryDate: '2024-06-20', createdAt: '2024-06-09', createdBy: 'u2', terms: 'Net 30' },
  { id: 'po2', poNumber: 'PO-2024-0002', rfqId: 'rfq2', quotationId: 'q3', vendorId: 'v2', vendorName: 'TechParts India Pvt Ltd', lineItems: [{ description: 'Laptop 16GB RAM', quantity: 15, unitPrice: 1024, amount: 15360 }, { description: 'Laptop Bags', quantity: 15, unitPrice: 14.4, amount: 216 }], subtotal: 15576, cgst: 0, sgst: 0, igst: 2803.68, total: 18379.68, status: 'confirmed', deliveryDate: '2024-07-30', createdAt: '2024-06-21', createdBy: 'u2', terms: 'Net 45' },
];

// ─── Invoices ─────────────────────────────────────────────────────────────────
export const invoices = [
  { id: 'inv1', invoiceNumber: 'INV-2024-0001', poId: 'po1', poNumber: 'PO-2024-0001', vendorId: 'v1', vendorName: 'Ravi Supplies Co.', lineItems: [{ description: 'A4 Paper Reams', quantity: 500, unitPrice: 3.4, amount: 1700 }, { description: 'Ball Pens', quantity: 1000, unitPrice: 0.1, amount: 100 }, { description: 'Staplers', quantity: 50, unitPrice: 2.65, amount: 132.5 }], subtotal: 1932.5, cgst: 173.9, sgst: 173.9, igst: 0, total: 2280.3, status: 'paid', dueDate: '2024-07-09', issuedDate: '2024-06-21', paidDate: '2024-07-05' },
  { id: 'inv2', invoiceNumber: 'INV-2024-0002', poId: 'po2', poNumber: 'PO-2024-0002', vendorId: 'v2', vendorName: 'TechParts India Pvt Ltd', lineItems: [{ description: 'Laptop 16GB RAM', quantity: 15, unitPrice: 1024, amount: 15360 }, { description: 'Laptop Bags', quantity: 15, unitPrice: 14.4, amount: 216 }], subtotal: 15576, cgst: 0, sgst: 0, igst: 2803.68, total: 18379.68, status: 'pending', dueDate: '2024-08-05', issuedDate: '2024-07-01', paidDate: null },
];

// ─── Chart / Analytics Data ───────────────────────────────────────────────────
export const monthlySpend = [
  { month: 'Jan', spend: 3855, orders: 4 },
  { month: 'Feb', spend: 5783, orders: 6 },
  { month: 'Mar', spend: 9036, orders: 9 },
  { month: 'Apr', spend: 7469, orders: 7 },
  { month: 'May', spend: 10722, orders: 11 },
  { month: 'Jun', spend: 20638, orders: 14 },
];

export const vendorStatusData = [
  { name: 'Active', value: 3, color: '#10b981' },
  { name: 'Pending', value: 1, color: '#f59e0b' },
  { name: 'Inactive', value: 1, color: '#6b7280' },
  { name: 'Blacklisted', value: 1, color: '#ef4444' },
];

export const vendorPerformance = [
  { vendor: 'Ravi Supplies Co.', delivery: 95, quality: 90, price: 85, responsiveness: 92, compliance: 88 },
  { vendor: 'TechParts India', delivery: 80, quality: 92, price: 75, responsiveness: 85, compliance: 90 },
  { vendor: 'SwiftLogix Transport', delivery: 88, quality: 72, price: 90, responsiveness: 70, compliance: 75 },
];

// ─── Audit Logs ───────────────────────────────────────────────────────────────
export const auditLogs = [
  { id: 'al1', userId: 'u2', userName: 'Priya Sharma', action: 'Created RFQ', entityType: 'RFQ', entityId: 'rfq1', entityTitle: 'Office Stationery Q2 2024', timestamp: '2024-06-01T09:00:00', ipAddress: '192.168.1.10' },
  { id: 'al2', userId: 'u1', userName: 'Arjun Mehta', action: 'Approved Quotation', entityType: 'Approval', entityId: 'ap1', entityTitle: 'Ravi Supplies — RFQ-2024-0001', timestamp: '2024-06-08T11:30:00', ipAddress: '192.168.1.1' },
  { id: 'al3', userId: 'u2', userName: 'Priya Sharma', action: 'Generated Purchase Order', entityType: 'PurchaseOrder', entityId: 'po1', entityTitle: 'PO-2024-0001', timestamp: '2024-06-09T10:00:00', ipAddress: '192.168.1.10' },
  { id: 'al4', userId: 'u3', userName: 'Ravi Supplies Co.', action: 'Submitted Quotation', entityType: 'Quotation', entityId: 'q1', entityTitle: 'RFQ-2024-0001 Quotation', timestamp: '2024-06-05T14:00:00', ipAddress: '10.0.0.5' },
  { id: 'al5', userId: 'u2', userName: 'Priya Sharma', action: 'Created RFQ', entityType: 'RFQ', entityId: 'rfq2', entityTitle: 'Laptop Procurement for Engineering Team', timestamp: '2024-06-10T09:30:00', ipAddress: '192.168.1.10' },
  { id: 'al6', userId: 'u1', userName: 'Arjun Mehta', action: 'Registered Vendor', entityType: 'Vendor', entityId: 'v3', entityTitle: 'GreenBuild Materials', timestamp: '2024-06-18T15:00:00', ipAddress: '192.168.1.1' },
  { id: 'al7', userId: 'u2', userName: 'Priya Sharma', action: 'Generated Invoice', entityType: 'Invoice', entityId: 'inv1', entityTitle: 'INV-2024-0001', timestamp: '2024-06-21T11:00:00', ipAddress: '192.168.1.10' },
  { id: 'al8', userId: 'u1', userName: 'Arjun Mehta', action: 'Rejected Approval', entityType: 'Approval', entityId: 'ap5', entityTitle: 'Office Furniture Budget Exception', timestamp: '2024-06-27T09:00:00', ipAddress: '192.168.1.1' },
];
